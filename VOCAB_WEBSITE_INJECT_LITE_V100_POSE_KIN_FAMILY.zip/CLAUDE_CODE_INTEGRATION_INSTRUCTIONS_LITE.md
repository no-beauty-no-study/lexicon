# Claude Code Integration - Lite Vocabulary Package V84

Use these files directly:

- `VOCAB_READING_WORDS_LITE.js`: reading clickable words and `reading_to_learning_head`.
- `VOCAB_WORD_CONTENT_REGISTRY_LITE.js`: the one place to read word zh, phrases, and examples.
- `VOCAB_FAMILY_SHARED_CLUSTERS_LITE.js`: shared family clusters. Family is suffix/POS variation and is shared for display.
- `VOCAB_KIN_CLEAN_LITE.js`: cleaned kin clusters. Kin is not shared like family.
- `VOCAB_KIN_HEAD_BRIDGE_LITE.js`: word -> kin cluster ids.
- `VOCAB_GROUP_CLEAN_LITE.js`: synonym/group content.
- `VOCAB_WORD_ENTRY_POLICY_LITE.js`: tells the UI which words open big network cards.

Runtime flow:

1. User clicks a reading word.
2. Show small card from `VOCAB_WORD_CONTENT_REGISTRY_LITE.cards[word]`.
3. If user opens the large card, route through `VOCAB_READING_WORDS_LITE.reading_to_learning_head[word].learning_head`.
4. Large card content:
   - current/head word content from registry
   - family: find clusters containing current word; show other words in same family cluster
   - kin: use `VOCAB_KIN_HEAD_BRIDGE_LITE.head_to_kin_clusters[currentWord]`; show words in those clusters except current word
   - group: show synonym/group rows, excluding words already shown in family or kin
5. Family is shared: if family cluster is `a b c d`, current `d` displays `a b c`.
6. Kin is not shared as family. Clicking a kin word opens that word as the new current word and recomputes its own family/kin/group.
7. If a family word is in `VOCAB_WORD_ENTRY_POLICY_LITE.big_card_words`, it can open a full card. If it is only in `family_only_words`, keep it visible in family but open only a small lookup card or leave it unlinked.
8. Never show singleton fake kin as learning content.

Display rule:

For related family/kin/group words, do not duplicate huge text. Look up that word in the registry and show one representative phrase by default. Full phrases/examples appear only when that word is opened as the current card.
## V85 Head -> Family Kin Navigation

Also load `VOCAB_HEAD_TO_FAMILY_KIN_NAV_LITE.js`.

This file solves the important case:

`head -> family word -> family word's own kin`

Example:

`state` can show `static` in family, and through `static` it can expose `ecstatic / eustatic / geostatic / antistatic` as a deeper learn-more route.

Do not treat this as shared kin. The large card for `state` may preview this route, but if the user clicks `static`, then `static` becomes the current word and its own kin cluster is used.

UI recommendation:

- On a head card, after Family, add a small "family kin" subsection when `VOCAB_HEAD_TO_FAMILY_KIN_NAV_LITE.head_to_family_kin[current].family_kin_routes` is non-empty.
- Display route as: `static -> ecstatic, eustatic, geostatic, antistatic`.
- For each displayed word, fetch one phrase from `VOCAB_WORD_CONTENT_REGISTRY_LITE.cards[word]`.
- If a route word is not entry-enabled in `VOCAB_WORD_ENTRY_POLICY_LITE.big_card_words`, show it as a small lookup only.
## V86 Multi-Suffix Family

Family clusters are now rebuilt with recursive suffix chains, not one suffix only.

Example:

`except -> exception -> exceptional -> exceptionality / exceptionalism / exceptionable / exceptive`

Family display is shared: every word in one family cluster can show the other family words. Kin is still not shared.
## V87 Same-POS Kin + Family Closure

Same-POS kin clusters are shared through `VOCAB_KIN_HEAD_BRIDGE_LITE`: if `static / geostatic / eustatic / ecstatic / antistatic` are in one kin cluster, opening any one of them should show the others as kin.

Family is still a separate shared cluster. A kin word can have its own family, for example:

`geostatic -> geostatics / geostationary`

So the UI flow can be:

`state -> static -> geostatic -> geostatics / geostationary`

Do not collapse this into one giant card. Use kin to move sideways, family to move suffix/POS forms.
## V88 Global Kin-Word Family Closure

Every word that appears in a kin cluster was audited for suffix/POS family relatives.

If reliable relatives were already in the registry, they were merged into the family cluster. Remaining singleton family clusters are preserved but indicate no reliable existing suffix/POS relative was found.

Same-POS kin remains shared through the kin bridge: opening any member of a kin cluster shows the other members as kin.
## V90 Suffix-Closure Family

Family is not one suffix only.

If a word can repeatedly remove or normalize suffixes until it reaches the same base/head, it belongs to that same shared family.

Example:

`exceptionable -> exception -> except`

Therefore `exceptionable / exception / exceptional / exceptionality / except` share one family cluster.
## V95 Kin Word Source Head Family

Load `VOCAB_KIN_WORD_SOURCE_HEAD_FAMILY_LITE.js`.

Hard rule:

If a word has kin, it must have a source head path.

Use:

`VOCAB_KIN_WORD_SOURCE_HEAD_FAMILY_LITE.kin_word_source_head_family[word]`

The head is shown in the Head area. The Family area should show `display_family_without_head`.

If status is `violates_kin_requires_head_family`, do not show a complete big card for that word; it needs family completion.
## V97 Family Monogamy

Use the V97 family file as the source of truth.

Hard rule:

One word belongs to exactly one family cluster.

Overwide families were split. If a word appears in multiple old families, only the best single owner remains.
## V98 Strict Kin

This is the submittable strict kin package.

Visible kin clusters all satisfy:

`kin word -> source_head -> source_head_family`

Clusters that do not satisfy this were removed from visible kin and listed in `STRICT_KIN_SUBMITTABLE_AUDIT_V98.json`. Their word cards/content are not deleted.