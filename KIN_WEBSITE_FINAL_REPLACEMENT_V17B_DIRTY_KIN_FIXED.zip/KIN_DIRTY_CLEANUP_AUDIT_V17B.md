# KIN DIRTY CLEANUP AUDIT V17B

- uncovered_big_cards: **153**

## condense
```json
{
  "ids": [
    "kin_clean_condense_dense_density"
  ],
  "internal": [
    "condense",
    "dense",
    "density",
    "condenser"
  ],
  "external": [
    "condensation",
    "densify",
    "condensate"
  ],
  "family_members": [
    "condensation",
    "density"
  ],
  "phrases": [
    "condense information",
    "condense into liquid",
    "condensed version",
    "condense water vapour",
    "condensed matter physics",
    "condensed policy summary",
    "condensing social change"
  ]
}
```

## dirty check
```json
{
  "condense_kin_has_condensed": false,
  "condense_has_respond": false,
  "condense_has_sponsor": false,
  "condense_has_despondent": false
}
```