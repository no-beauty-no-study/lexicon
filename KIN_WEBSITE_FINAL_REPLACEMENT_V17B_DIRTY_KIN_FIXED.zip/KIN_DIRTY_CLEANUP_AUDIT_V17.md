# KIN DIRTY CLEANUP AUDIT V17

- moved_inflection_family_members: **2957**
- surface_only_cards: **176**
- no_big_cards: **201**
- uncovered_big_cards: **154**

## condense
```json
{
  "family_members": [
    "condensation",
    "density"
  ],
  "phrases": [
    "condense information",
    "condense into liquid",
    "condensed version",
    "condense water vapour",
    "condensed matter physics",
    "condensed policy summary",
    "condensing social change"
  ],
  "kin_internal": [
    "condense",
    "dense",
    "density"
  ],
  "kin_external": [
    "condensation",
    "densify",
    "condensate",
    "condenser"
  ]
}
```

## dirty check
```json
{
  "condense_family_has_condensed": false,
  "condense_kin_has_condensed": false,
  "condense_has_respond": false
}
```