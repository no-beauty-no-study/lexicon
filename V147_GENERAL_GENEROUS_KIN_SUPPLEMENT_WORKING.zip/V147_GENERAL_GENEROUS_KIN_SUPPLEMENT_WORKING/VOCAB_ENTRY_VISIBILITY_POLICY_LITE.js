window.VOCAB_ENTRY_VISIBILITY_POLICY_LITE = {
    "metadata":  {
                     "name":  "VOCAB_ENTRY_VISIBILITY_POLICY_LITE",
                     "rule":  "Simple bridge heads keep cards/family/kin/navigation, but exact raw reading entries are disabled. Derivatives and compounds remain clickable."
                 },
    "simple_bridge_heads_no_reading_entry":  [
                                                 "a",
                                                 "after",
                                                 "again",
                                                 "ago",
                                                 "all",
                                                 "also",
                                                 "an",
                                                 "and",
                                                 "any",
                                                 "as",
                                                 "at",
                                                 "back",
                                                 "bad",
                                                 "be",
                                                 "because",
                                                 "before",
                                                 "big",
                                                 "but",
                                                 "by",
                                                 "can",
                                                 "come",
                                                 "day",
                                                 "do",
                                                 "dog",
                                                 "down",
                                                 "each",
                                                 "end",
                                                 "even",
                                                 "eye",
                                                 "far",
                                                 "few",
                                                 "find",
                                                 "first",
                                                 "for",
                                                 "from",
                                                 "get",
                                                 "give",
                                                 "go",
                                                 "good",
                                                 "great",
                                                 "had",
                                                 "hand",
                                                 "have",
                                                 "he",
                                                 "head",
                                                 "help",
                                                 "her",
                                                 "here",
                                                 "him",
                                                 "his",
                                                 "home",
                                                 "house",
                                                 "how",
                                                 "i",
                                                 "if",
                                                 "in",
                                                 "into",
                                                 "it",
                                                 "its",
                                                 "just",
                                                 "keep",
                                                 "kind",
                                                 "know",
                                                 "land",
                                                 "last",
                                                 "left",
                                                 "life",
                                                 "like",
                                                 "little",
                                                 "long",
                                                 "look",
                                                 "lot",
                                                 "make",
                                                 "man",
                                                 "many",
                                                 "may",
                                                 "me",
                                                 "more",
                                                 "most",
                                                 "much",
                                                 "my",
                                                 "new",
                                                 "no",
                                                 "not",
                                                 "now",
                                                 "of",
                                                 "off",
                                                 "old",
                                                 "on",
                                                 "one",
                                                 "only",
                                                 "or",
                                                 "other",
                                                 "our",
                                                 "out",
                                                 "over",
                                                 "own",
                                                 "part",
                                                 "people",
                                                 "phone",
                                                 "place",
                                                 "poor",
                                                 "put",
                                                 "right",
                                                 "same",
                                                 "say",
                                                 "see",
                                                 "she",
                                                 "side",
                                                 "small",
                                                 "so",
                                                 "some",
                                                 "speak",
                                                 "still",
                                                 "sun",
                                                 "take",
                                                 "than",
                                                 "that",
                                                 "the",
                                                 "their",
                                                 "them",
                                                 "then",
                                                 "there",
                                                 "they",
                                                 "thing",
                                                 "think",
                                                 "this",
                                                 "time",
                                                 "to",
                                                 "too",
                                                 "two",
                                                 "under",
                                                 "up",
                                                 "us",
                                                 "use",
                                                 "very",
                                                 "want",
                                                 "was",
                                                 "water",
                                                 "way",
                                                 "we",
                                                 "well",
                                                 "what",
                                                 "when",
                                                 "where",
                                                 "which",
                                                 "who",
                                                 "will",
                                                 "with",
                                                 "woman",
                                                 "word",
                                                 "work",
                                                 "world",
                                                 "would",
                                                 "year",
                                                 "you",
                                                 "young"
                                             ],
    "removed_reading_entries":  [
                                    {
                                        "word":  "come",
                                        "learning_head":  "come",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "dog",
                                        "learning_head":  "dogwood",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "great",
                                        "learning_head":  "great",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "hand",
                                        "learning_head":  "hand",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "home",
                                        "learning_head":  "home",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "kind",
                                        "learning_head":  "kind",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "land",
                                        "learning_head":  "land",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "long",
                                        "learning_head":  "longhaul",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "own",
                                        "learning_head":  "own",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "part",
                                        "learning_head":  "part",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "phone",
                                        "learning_head":  "phone",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "place",
                                        "learning_head":  "place",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "poor",
                                        "learning_head":  "poor",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "right",
                                        "learning_head":  "right",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "same",
                                        "learning_head":  "same",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "side",
                                        "learning_head":  "side",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "speak",
                                        "learning_head":  "speak",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "sun",
                                        "learning_head":  "sunspot",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "use",
                                        "learning_head":  "use",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "water",
                                        "learning_head":  "water",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "way",
                                        "learning_head":  "wayside",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "well",
                                        "learning_head":  "wellhead",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "be",
                                        "learning_head":  "be",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "out",
                                        "learning_head":  "out",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "just",
                                        "learning_head":  "justify",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "go",
                                        "learning_head":  "go",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "time",
                                        "learning_head":  "time",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "make",
                                        "learning_head":  "make",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "work",
                                        "learning_head":  "work",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "world",
                                        "learning_head":  "world",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "life",
                                        "learning_head":  "life",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    },
                                    {
                                        "word":  "under",
                                        "learning_head":  "under",
                                        "reason":  "simple_bridge_head_exact_word_no_reading_entry"
                                    }
                                ],
    "counts":  {
                   "old_reading_routes":  11466,
                   "new_reading_routes":  11434,
                   "removed_reading_routes":  32,
                   "old_reading_words":  11459,
                   "new_reading_words":  11427
               }
};