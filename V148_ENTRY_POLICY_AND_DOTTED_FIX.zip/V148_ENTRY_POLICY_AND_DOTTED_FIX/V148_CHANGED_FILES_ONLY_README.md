# V148 Entry Policy And Dotted Fix

- changed: VOCAB_READING_WORDS_LITE.json/js
- changed: VOCAB_ENTRY_VISIBILITY_POLICY_LITE.json/js
- changed: VOCAB_WORD_ENTRY_POLICY_LITE.json/js
- changed: HEAD_TO_READING_CARD_DOTTED_REVIEW_V2.md
- film / forty: removed as exact low-value reading big-card entries; kept small_only fallback.
- golden / gold-plated: route to gold.
- returnable: re·turn·able; irrevocable: ir·re·voc·able.
