# V24 Prefix-DNA Core

- curated prefix-DNA clusters: 27
- clusters added: 27
- clusters updated: 0
- card attachments: 159

Policy: meaningful prefix swap + shared visible root is kin; -tion/-ment etc are family/half-step learning support.
