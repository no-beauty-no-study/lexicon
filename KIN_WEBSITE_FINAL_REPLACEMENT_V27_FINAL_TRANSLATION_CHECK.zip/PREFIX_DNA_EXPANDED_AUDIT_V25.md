# V25 Prefix-DNA Expanded

- curated high-confidence clusters: 27
- added: 27
- updated: 0
- card attachments: 115
- pruned weak V24 items: absolute / delay / opportunity

Policy: kin = meaningful prefix/root swap + shared visible DNA; family = suffix/POS half-word gain.
