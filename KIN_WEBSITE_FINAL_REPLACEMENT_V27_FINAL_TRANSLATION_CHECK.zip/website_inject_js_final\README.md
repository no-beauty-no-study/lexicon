﻿# Website Inject JS Final

Load order:

1. VOCAB_WORD_MASTER_FINAL.js
2. VOCAB_FAMILY_CONTENT_MASTER_FINAL.js
3. VOCAB_FAMILY_HEAD_MAP_FINAL.js
4. VOCAB_KIN_CLUSTER_MASTER_FINAL.js
5. VOCAB_PROPER_SMALL_CARDS_FINAL.js
6. VOCAB_RUNTIME_HELPERS.js

Use:

- `VocabRuntime.getSmallCard(word)` for reading click popup.
- `VocabRuntime.getBigCard(word)` after clicking the small card.
- `VocabRuntime.isClickableWord(word)` to decide whether family / kin / group words can open another card.

Small card:
- clicked word own zh / phrases / examples.
- proper/place/special words use `VOCAB_PROPER_SMALL_CARDS_FINAL` if not in word master.

Big card:
- focus remains clicked word.
- family comes from its family head.
- kin comes from family head / shared kin clusters.
- family / kin / group internal words are clickable if they exist in word master.
