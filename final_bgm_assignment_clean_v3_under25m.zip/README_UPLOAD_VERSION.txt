This is the under-25MB upload version.
Audio compressed to mono 64kbps / 32kHz for web BGM use.
File names and assignment map are preserved.
