(function () {
  function norm(word) {
    return String(word || '').trim().toLowerCase();
  }

  function propsToMap(obj, keyField) {
    const map = new Map();
    if (!obj) return map;
    if (Array.isArray(obj)) {
      for (const item of obj) if (item && item[keyField]) map.set(norm(item[keyField]), item);
    } else {
      for (const [k, v] of Object.entries(obj)) map.set(norm(k), v);
    }
    return map;
  }

  const wordMaster = window.VOCAB_WORD_MASTER_FINAL || {};
  const kinMaster = window.VOCAB_KIN_CLUSTER_MASTER_FINAL || {};
  const familyMaster = window.VOCAB_FAMILY_CONTENT_MASTER_FINAL || {};
  const properMaster = window.VOCAB_PROPER_SMALL_CARDS_FINAL || {};

  const wordCards = wordMaster.cards || {};
  const wordCardMap = propsToMap(wordCards, 'word');
  const wordToFamilyHead = window.VOCAB_FAMILY_HEAD_MAP_FINAL || familyMaster.word_to_family_head || {};
  const familyByHead = propsToMap(familyMaster.families || [], 'family_head');
  const kinById = propsToMap(kinMaster.kin_clusters || [], 'cluster_id');
  const properSmallByWord = propsToMap(properMaster.small_cards || [], 'word');

  function surfaceCandidates(word) {
    const key = norm(word);
    const out = [key];
    if (key.endsWith('ies') && key.length > 4) out.push(key.slice(0, -3) + 'y');
    if (key.endsWith('es') && key.length > 3) out.push(key.slice(0, -2));
    if (key.endsWith('s') && key.length > 3) out.push(key.slice(0, -1));
    return [...new Set(out.filter(Boolean))];
  }

  function getWordCard(word) {
    for (const key of surfaceCandidates(word)) {
      const mapped = norm(wordToFamilyHead[key] || key);
      const card = wordCardMap.get(key) || wordCards[key] || wordCardMap.get(mapped) || wordCards[mapped];
      if (card) return card;
    }
    return null;
  }

  function getDisplayWordCard(word) {
    const card = getWordCard(word);
    if (card && card.redirect_to_word) return getWordCard(card.redirect_to_word) || card;
    return card;
  }

  function getProperSmallCard(word) {
    return properSmallByWord.get(norm(word)) || null;
  }

  function getFamilyHead(word) {
    for (const key of surfaceCandidates(word)) {
      const mapped = wordToFamilyHead[key] || wordToFamilyHead[norm(key)];
      if (mapped) return norm(mapped);
    }
    const card = getWordCard(word);
    if (card && card.family_head) return norm(card.family_head);
    return norm(word);
  }

  function isClickableWord(word) {
    return !!getWordCard(word);
  }

  function getSmallCard(word) {
    const card = getWordCard(word);
    if (card) {
      return {
        type: 'word',
        word: card.word || word,
        canonical_word: card.redirect_to_word || card.canonical_word || card.family_head || card.word || word,
        zh: card.zh || '',
        phrases: card.phrases || [],
        examples: card.examples || [],
        clickableForBigCard: !card.small_only
      };
    }
    const proper = getProperSmallCard(word);
    if (proper) {
      return {
        type: 'proper_or_special',
        word: proper.word || word,
        zh: proper.zh || '',
        phrases: proper.phrases || [],
        examples: proper.examples || [],
        clickableForBigCard: false
      };
    }
    return null;
  }

  function clickableKinWord(word) {
    const card = getWordCard(word);
    if (!card) return null;
    return {
      word: card.word || word,
      zh: card.zh || '',
      phrases: card.phrases || [],
      examples: card.examples || [],
      clickable: true
    };
  }

  function memberWord(member) {
    return norm(typeof member === 'string' ? member : member && member.word);
  }

  function normalizeFamilyMember(member) {
    if (typeof member === 'string') return { word: member, clickable: isClickableWord(member) };
    return { ...member, clickable: isClickableWord(member && member.word) };
  }

  function getBigCard(word) {
    const rawFocus = getWordCard(word);
    if (!rawFocus) return null;
    const focus = rawFocus.redirect_to_word ? (getWordCard(rawFocus.redirect_to_word) || rawFocus) : rawFocus;

    const requestedKey = norm(word);
    const focusKey = norm(focus.word || rawFocus.redirect_to_word || word);
    const familyHead = getFamilyHead(rawFocus.redirect_to_word || focus.word || word);
    const family = familyByHead.get(familyHead) || null;

    let familyMembers = family ? (family.family_members || []) : (focus.family_members || []);
    familyMembers = [...familyMembers].sort((a, b) => {
      const aw = memberWord(a);
      const bw = memberWord(b);
      if (aw === requestedKey) return -1;
      if (bw === requestedKey) return 1;
      if (aw === focusKey) return -1;
      if (bw === focusKey) return 1;
      if (aw === familyHead) return -1;
      if (bw === familyHead) return 1;
      return aw.localeCompare(bw);
    }).map(normalizeFamilyMember);

    const familyWordSet = new Set(familyMembers.map(memberWord).filter(Boolean));
    familyWordSet.add(focusKey);
    familyWordSet.add(familyHead);

    const kinIds = new Set([...(focus.kin_cluster_ids || [])]);
    if (family && family.shared_kin_cluster_ids) {
      const ids = Array.isArray(family.shared_kin_cluster_ids) ? family.shared_kin_cluster_ids : [family.shared_kin_cluster_ids];
      for (const id of ids) kinIds.add(id);
    }
    const headCard = getWordCard(familyHead);
    if (headCard && headCard.kin_cluster_ids) {
      for (const id of headCard.kin_cluster_ids) kinIds.add(id);
    }

    const kinClusters = [...kinIds]
      .map(id => kinById.get(norm(id)) || kinById.get(id))
      .filter(Boolean)
      .map(cluster => {
        const internal = (cluster.internal_words || [])
          .filter(w => !familyWordSet.has(norm(w)))
          .map(w => clickableKinWord(w) || { word: w, clickable: false });
        const external = (cluster.external_words || [])
          .filter(e => !familyWordSet.has(norm(e && e.word)))
          .map(e => ({ ...e, clickable: isClickableWord(e.word) }));
        return { ...cluster, internal_words: internal, external_words: external };
      })
      .filter(cluster => cluster.internal_words.length || cluster.external_words.length);

    let group = focus.group || [];
    if (group && !Array.isArray(group)) group = [group];
    group = group.map(g => ({ ...g, clickable: isClickableWord(g.word) }));

    return {
      focus_word: focus.word || word,
      requested_word: rawFocus.word || word,
      family_head: familyHead,
      word: focus.word || word,
      zh: focus.zh || '',
      phrases: focus.phrases || [],
      examples: focus.examples || [],
      family_members: familyMembers,
      group,
      kin_clusters: kinClusters
    };
  }

  window.VocabRuntime = {
    getWordCard,
    getSmallCard,
    getBigCard,
    getFamilyHead,
    isClickableWord,
    indexes: { wordCardMap, familyByHead, kinById, properSmallByWord }
  };
})();
