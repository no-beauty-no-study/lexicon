window.VOCAB_GROUP_CLEAN_LITE = {
    "metadata":  {
                     "name":  "VOCAB_GROUP_CLEAN_LITE",
                     "rule":  "Relationship-only group map. Use content registry for phrases."
                 },
    "groups":  {
                   "acceptable":  [
                                      "valid"
                                  ],
                   "accommodation":  [
                                         "lodging"
                                     ],
                   "acculturate":  [
                                       "subculture"
                                   ],
                   "accumulation":  [
                                        "buildup"
                                    ],
                   "acknowledge":  [
                                       "recognise"
                                   ],
                   "acquaintance":  [
                                        "contact"
                                    ],
                   "activist":  [
                                    "campaigner"
                                ],
                   "adjudicate":  [
                                      "judge"
                                  ],
                   "aerodynamic":  [
                                       "streamlined"
                                   ],
                   "affordable":  [
                                      "low-cost"
                                  ],
                   "agree":  [
                                 "consent"
                             ],
                   "algorithmic":  [
                                       "computational"
                                   ],
                   "allocation":  [
                                      "distribution"
                                  ],
                   "animation":  [
                                     "cartoon"
                                 ],
                   "anode":  [
                                 "positiveelectrode"
                             ],
                   "anthropology":  [
                                        "humanstudies"
                                    ],
                   "antibiotic":  [
                                      "antimicrobial"
                                  ],
                   "antibody":  [
                                    "immuneprotein"
                                ],
                   "anticipate":  [
                                      "expect"
                                  ],
                   "anticipation":  [
                                        "expectation"
                                    ],
                   "anticipatory":  [
                                        "predictive"
                                    ],
                   "antifreeze":  [
                                      "coolant"
                                  ],
                   "antigen":  [
                                   "immunetrigger"
                               ],
                   "antiquated":  [
                                      "outdated"
                                  ],
                   "antiquatedness":  [
                                          "outdatedness"
                                      ],
                   "antique":  [
                                   "ancient"
                               ],
                   "antiquity":  [
                                     "ancienttimes"
                                 ],
                   "antithesis":  [
                                      "opposite"
                                  ],
                   "anxiety":  [
                                   "worry"
                               ],
                   "anxious":  [
                                   "worried"
                               ],
                   "anxiousness":  [
                                       "worry"
                                   ],
                   "apartheid":  [
                                     "segregation"
                                 ],
                   "apathetic":  [
                                     "indifferent"
                                 ],
                   "apathic":  [
                                   "indifferent"
                               ],
                   "apathy":  [
                                  "indifference"
                              ],
                   "aphasia":  [
                                   "speechloss"
                               ],
                   "apologise":  [
                                     "saysorry"
                                 ],
                   "apology":  [
                                   "regretstatement"
                               ],
                   "apparatus":  [
                                     "equipment"
                                 ],
                   "apparency":  [
                                     "visibility"
                                 ],
                   "apparent":  [
                                    "obvious"
                                ],
                   "appearance":  [
                                      "look"
                                  ],
                   "applause":  [
                                    "praise"
                                ],
                   "application":  [
                                       "use"
                                   ],
                   "apply":  [
                                 "use"
                             ],
                   "appoint":  [
                                   "assign"
                               ],
                   "appointee":  [
                                     "nominee"
                                 ],
                   "appointment":  [
                                       "assignment"
                                   ],
                   "apprehend":  [
                                     "arrest"
                                 ],
                   "apprehensible":  [
                                         "understandable"
                                     ],
                   "apprehension":  [
                                        "anxiety"
                                    ],
                   "apprehensive":  [
                                        "uneasy"
                                    ],
                   "apprehensiveness":  [
                                            "uneasiness"
                                        ],
                   "approach":  [
                                    "method"
                                ],
                   "appropriate":  [
                                       "suitable"
                                   ],
                   "appropriateness":  [
                                           "suitability"
                                       ],
                   "approve":  [
                                   "endorse"
                               ],
                   "approximate":  [
                                       "rough"
                                   ],
                   "approximation":  [
                                         "estimate"
                                     ],
                   "apt":  [
                               "suitable"
                           ],
                   "aptitude":  [
                                    "talent"
                                ],
                   "aptness":  [
                                   "suitability"
                               ],
                   "aqua":  [
                                "water"
                            ],
                   "aquaculture":  [
                                       "fishfarming"
                                   ],
                   "aquaponics":  [
                                      "fish-plantfarming"
                                  ],
                   "aquarium":  [
                                    "fishtank"
                                ],
                   "aquatic":  [
                                   "water-based"
                               ],
                   "aqueduct":  [
                                    "waterchannel"
                                ],
                   "aquifer":  [
                                   "waterlayer"
                               ],
                   "aquiferous":  [
                                      "water-bearing"
                                  ],
                   "arability":  [
                                     "farmability"
                                 ],
                   "arable":  [
                                  "farmable"
                              ],
                   "arbiter":  [
                                   "judge"
                               ],
                   "arbitrariness":  [
                                         "randomness"
                                     ],
                   "arbitrary":  [
                                     "random"
                                 ],
                   "arbitrate":  [
                                     "mediate"
                                 ],
                   "arbitration":  [
                                       "mediation"
                                   ],
                   "arch":  [
                                "curve"
                            ],
                   "archaeological":  [
                                          "ancient-material"
                                      ],
                   "archaeology":  [
                                       "ancientstudy"
                                   ],
                   "archaic":  [
                                   "ancient"
                               ],
                   "archetype":  [
                                     "prototype"
                                 ],
                   "archipelago":  [
                                       "islandchain"
                                   ],
                   "architect":  [
                                     "designer"
                                 ],
                   "architectural":  [
                                         "building-related"
                                     ],
                   "architecture":  [
                                        "buildingdesign"
                                    ],
                   "archive":  [
                                   "recordcollection"
                               ],
                   "argue":  [
                                 "claim"
                             ],
                   "argument":  [
                                    "claim"
                                ],
                   "arise":  [
                                 "emerge"
                             ],
                   "aristocracy":  [
                                       "nobility"
                                   ],
                   "aristocrat":  [
                                      "noble"
                                  ],
                   "aristocratic":  [
                                        "noble"
                                    ],
                   "army":  [
                                "militaryforce"
                            ],
                   "arousal":  [
                                   "stimulation"
                               ],
                   "arouse":  [
                                  "stimulate"
                              ],
                   "arrangement":  [
                                       "organisation"
                                   ],
                   "array":  [
                                 "range"
                             ],
                   "arrival":  [
                                   "coming"
                               ],
                   "art":  [
                               "craft"
                           ],
                   "artefact":  [
                                    "object"
                                ],
                   "article":  [
                                   "piece"
                               ],
                   "articulate":  [
                                      "express"
                                  ],
                   "articulation":  [
                                        "expression"
                                    ],
                   "artifact":  [
                                    "object"
                                ],
                   "artifactual":  [
                                       "object-based"
                                   ],
                   "artifice":  [
                                    "trick"
                                ],
                   "artificial":  [
                                      "synthetic"
                                  ],
                   "artificiality":  [
                                         "syntheticness"
                                     ],
                   "artisan":  [
                                   "craftsperson"
                               ],
                   "artistry":  [
                                    "art"
                                ],
                   "ascend":  [
                                  "rise"
                              ],
                   "ascent":  [
                                  "rise"
                              ],
                   "ascertain":  [
                                     "determine"
                                 ],
                   "assassinate":  [
                                       "murder"
                                   ],
                   "assassination":  [
                                         "murder"
                                     ],
                   "assemble":  [
                                    "gather"
                                ],
                   "assembler":  [
                                     "builder"
                                 ],
                   "assembly":  [
                                    "gathering"
                                ],
                   "assent":  [
                                  "agreement"
                              ],
                   "assert":  [
                                  "claim"
                              ],
                   "assertion":  [
                                     "claim"
                                 ],
                   "assertive":  [
                                     "confident"
                                 ],
                   "assess":  [
                                  "evaluate"
                              ],
                   "assessment":  [
                                      "evaluation"
                                  ],
                   "assessor":  [
                                    "evaluator"
                                ],
                   "assimilate":  [
                                      "integrate"
                                  ],
                   "assimilation":  [
                                        "integration"
                                    ],
                   "assimilative":  [
                                        "integrative"
                                    ],
                   "assist":  [
                                  "help"
                              ],
                   "assume":  [
                                  "presume"
                              ],
                   "assumption":  [
                                      "presumption"
                                  ],
                   "assure":  [
                                  "guarantee"
                              ],
                   "asteroid":  [
                                    "minorplanet"
                                ],
                   "asteroidal":  [
                                      "asteroid-like"
                                  ],
                   "astringent":  [
                                      "harsh"
                                  ],
                   "astrolabe":  [
                                     "navigationdevice"
                                 ],
                   "astronaut":  [
                                     "spacetraveller"
                                 ],
                   "astronautics":  [
                                        "spacescience"
                                    ],
                   "astronomical":  [
                                        "space-related"
                                    ],
                   "asymmetric":  [
                                      "uneven"
                                  ],
                   "athletic":  [
                                    "sporting"
                                ],
                   "atmosphere":  [
                                      "air"
                                  ],
                   "atmospheric":  [
                                       "air-related"
                                   ],
                   "atrocity":  [
                                    "cruelact"
                                ],
                   "attach":  [
                                  "connect"
                              ],
                   "attend":  [
                                  "join"
                              ],
                   "attendance":  [
                                      "presence"
                                  ],
                   "attendant":  [
                                     "assistant"
                                 ],
                   "attention":  [
                                     "focus"
                                 ],
                   "attentional":  [
                                       "focus-related"
                                   ],
                   "attentive":  [
                                     "focused"
                                 ],
                   "attenuate":  [
                                     "weaken"
                                 ],
                   "attenuation":  [
                                       "weakening"
                                   ],
                   "attest":  [
                                  "confirm"
                              ],
                   "attire":  [
                                  "clothing"
                              ],
                   "attitude":  [
                                    "stance"
                                ],
                   "attract":  [
                                   "draw"
                               ],
                   "attribute":  [
                                     "ascribe"
                                 ],
                   "attribution":  [
                                       "ascription"
                                   ],
                   "audible":  [
                                   "hearable"
                               ],
                   "audience":  [
                                    "viewers"
                                ],
                   "audit":  [
                                 "inspection"
                             ],
                   "aurora":  [
                                  "polarlight"
                              ],
                   "authentic":  [
                                     "genuine"
                                 ],
                   "authenticate":  [
                                        "verify"
                                    ],
                   "authenticity":  [
                                        "genuineness"
                                    ],
                   "author":  [
                                  "writer"
                              ],
                   "authorise":  [
                                     "permit"
                                 ],
                   "authoritarian":  [
                                         "dictatorial"
                                     ],
                   "authoritative":  [
                                         "reliable"
                                     ],
                   "authority":  [
                                     "power"
                                 ],
                   "authorize":  [
                                     "permit"
                                 ],
                   "autobiography":  [
                                         "memoir"
                                     ],
                   "automate":  [
                                    "mechanise"
                                ],
                   "automatic":  [
                                     "self-operating"
                                 ],
                   "automation":  [
                                      "mechanisation"
                                  ],
                   "automobile":  [
                                      "car"
                                  ],
                   "autonomous":  [
                                      "independent"
                                  ],
                   "autonomy":  [
                                    "independence"
                                ],
                   "availability":  [
                                        "accessibility"
                                    ],
                   "available":  [
                                     "accessible"
                                 ],
                   "avant-garde":  [
                                       "experimental"
                                   ],
                   "avert":  [
                                 "prevent"
                             ],
                   "avertable":  [
                                     "preventable"
                                 ],
                   "aviation":  [
                                    "flight"
                                ],
                   "aviator":  [
                                   "pilot"
                               ],
                   "avoid":  [
                                 "evade"
                             ],
                   "avoidable":  [
                                     "preventable"
                                 ],
                   "axiom":  [
                                 "principle"
                             ],
                   "axiomatic":  [
                                     "self-evident"
                                 ],
                   "axis":  [
                                "line"
                            ],
                   "bacillus":  [
                                    "rodbacterium"
                                ],
                   "background":  [
                                      "context"
                                  ],
                   "bacteriologist":  [
                                          "microbiologist"
                                      ],
                   "bacterium":  [
                                     "microbe"
                                 ],
                   "balance":  [
                                   "equilibrium"
                               ],
                   "baleen":  [
                                  "whalebone"
                              ],
                   "bamboo":  [
                                  "cane"
                              ],
                   "ban":  [
                               "prohibit"
                           ],
                   "bandwidth":  [
                                     "capacity"
                                 ],
                   "baobab":  [
                                  "tree"
                              ],
                   "bar":  [
                               "barrier"
                           ],
                   "bargaining":  [
                                      "negotiation"
                                  ],
                   "barometer":  [
                                     "indicator"
                                 ],
                   "barometric":  [
                                      "pressure-related"
                                  ],
                   "barren":  [
                                  "infertile"
                              ],
                   "barrenness":  [
                                      "infertility"
                                  ],
                   "barricade":  [
                                     "blockade"
                                 ],
                   "barrier":  [
                                   "obstacle"
                               ],
                   "barter":  [
                                  "trade"
                              ],
                   "base":  [
                                "foundation"
                            ],
                   "baseline":  [
                                    "referencepoint"
                                ],
                   "basement":  [
                                    "cellar"
                                ],
                   "basic":  [
                                 "fundamental"
                             ],
                   "basin":  [
                                 "depression"
                             ],
                   "basinal":  [
                                   "basin-related"
                               ],
                   "basis":  [
                                 "foundation"
                             ],
                   "battery":  [
                                   "cell"
                               ],
                   "beak":  [
                                "bill"
                            ],
                   "bean":  [
                                "legume"
                            ],
                   "bear":  [
                                "carry"
                            ],
                   "beaver":  [
                                  "rodent"
                              ],
                   "bed":  [
                               "foundation"
                           ],
                   "bedrock":  [
                                   "foundation"
                               ],
                   "behaviorism":  [
                                       "behaviourism"
                                   ],
                   "behaviorist":  [
                                       "behaviourist"
                                   ],
                   "behavioural":  [
                                       "conduct-related"
                                   ],
                   "behaviourism":  [
                                        "learningtheory"
                                    ],
                   "behaviourist":  [
                                        "psychologist"
                                    ],
                   "behind":  [
                                  "after"
                              ],
                   "being":  [
                                 "existence"
                             ],
                   "belief":  [
                                  "conviction"
                              ],
                   "benchmark":  [
                                     "standard"
                                 ],
                   "beneficial":  [
                                      "helpful"
                                  ],
                   "benefit":  [
                                   "advantage"
                               ],
                   "benevolence":  [
                                       "kindness"
                                   ],
                   "benevolent":  [
                                      "kind"
                                  ],
                   "besiege":  [
                                   "surrounded"
                               ],
                   "bewilder":  [
                                    "confuse"
                                ],
                   "bewilderment":  [
                                        "confusion"
                                    ],
                   "bewitch":  [
                                   "enchant"
                               ],
                   "bias":  [
                                "prejudice"
                            ],
                   "biasedly":  [
                                    "prejudicially"
                                ],
                   "biblical":  [
                                    "scriptural"
                                ],
                   "bicycle":  [
                                   "bike"
                               ],
                   "bide":  [
                                "wait"
                            ],
                   "bilingual":  [
                                     "two-language"
                                 ],
                   "bilingualism":  [
                                        "two-languageability"
                                    ],
                   "bill":  [
                                "invoice"
                            ],
                   "binarize":  [
                                    "makebinary"
                                ],
                   "binary":  [
                                  "two-part"
                              ],
                   "bind":  [
                                "tie"
                            ],
                   "biochemistry":  [
                                        "chemicalbiology"
                                    ],
                   "biodiverse":  [
                                      "species-rich"
                                  ],
                   "biodiversity":  [
                                        "speciesvariety"
                                    ],
                   "biological":  [
                                      "living"
                                  ],
                   "biologist":  [
                                     "biology",
                                     "lifescientist"
                                 ],
                   "biology":  [
                                   "lifescience"
                               ],
                   "biome":  [
                                 "ecosystem"
                             ],
                   "biomedical":  [
                                      "medical-biological"
                                  ],
                   "biometric":  [
                                     "identification-based"
                                 ],
                   "biosphere":  [
                                     "livingworld"
                                 ],
                   "bipedal":  [
                                   "two-legged"
                               ],
                   "birth":  [
                                 "origin"
                             ],
                   "bisexual":  [
                                    "queer"
                                ],
                   "bison":  [
                                 "buffalo"
                             ],
                   "bivouac":  [
                                   "camp"
                               ],
                   "blast":  [
                                 "explosion"
                             ],
                   "bleached":  [
                                    "whiten"
                                ],
                   "bleaching":  [
                                     "whiten"
                                 ],
                   "blizzard":  [
                                    "snowstorm"
                                ],
                   "blue":  [
                                "azure"
                            ],
                   "blueprint":  [
                                     "plan"
                                 ],
                   "bodhi":  [
                                 "enlightenment"
                             ],
                   "bolster":  [
                                   "support"
                               ],
                   "bolsterpillow":  [
                                         "cushion"
                                     ],
                   "bombardment":  [
                                       "attack"
                                   ],
                   "bond":  [
                                "connection"
                            ],
                   "bonobo":  [
                                  "ape"
                              ],
                   "bookmark":  [
                                    "marker"
                                ],
                   "booster":  [
                                   "supporter"
                               ],
                   "botanical":  [
                                     "plant-related"
                                 ],
                   "botany":  [
                                  "plantscience"
                              ],
                   "bottleneck":  [
                                      "constraint"
                                  ],
                   "boundary":  [
                                    "border"
                                ],
                   "bounty":  [
                                  "reward"
                              ],
                   "brain":  [
                                 "mind"
                             ],
                   "brainregion":  [
                                       "neuralarea"
                                   ],
                   "brainstorm":  [
                                      "ideate"
                                  ],
                   "brainstormer":  [
                                        "ideagenerator"
                                    ],
                   "brainwave":  [
                                     "idea"
                                 ],
                   "breach":  [
                                  "violation"
                              ],
                   "breadth":  [
                                   "scope"
                               ],
                   "break":  [
                                 "rupture"
                             ],
                   "breakdown":  [
                                     "collapse"
                                 ],
                   "breakthrough":  [
                                        "advance"
                                    ],
                   "breath":  [
                                  "respiration"
                              ],
                   "breathable":  [
                                      "ventilated"
                                  ],
                   "breathless":  [
                                      "panting"
                                  ],
                   "brick":  [
                                 "block"
                             ],
                   "bridge":  [
                                  "connect"
                              ],
                   "brief":  [
                                 "short"
                             ],
                   "broad":  [
                                 "wide"
                             ],
                   "broadband":  [
                                     "high-speedinternet"
                                 ],
                   "broadcast":  [
                                     "transmit"
                                 ],
                   "broadcaster":  [
                                       "announcer"
                                   ],
                   "broaden":  [
                                   "expand"
                               ],
                   "broadway":  [
                                    "theatredistrict"
                                ],
                   "brood":  [
                                 "offspring"
                             ],
                   "brush":  [
                                 "sweep"
                             ],
                   "bubble":  [
                                  "sphere"
                              ],
                   "bubonic":  [
                                   "plague-related"
                               ],
                   "buffalo":  [
                                   "bison"
                               ],
                   "buffer":  [
                                  "cushion"
                              ],
                   "builtenvironment":  [
                                            "constructedspace"
                                        ],
                   "bulb":  [
                                "globe"
                            ],
                   "bunk":  [
                                "bed"
                            ],
                   "bunker":  [
                                  "shelter"
                              ],
                   "buoyancy":  [
                                    "floatability"
                                ],
                   "bureaucracy":  [
                                       "administration"
                                   ],
                   "bureaucratic":  [
                                        "administrative"
                                    ],
                   "burgeon":  [
                                   "flourish"
                               ],
                   "burger":  [
                                  "sandwich"
                              ],
                   "burning":  [
                                   "flaming"
                               ],
                   "burrow":  [
                                  "tunnel"
                              ],
                   "bursary":  [
                                   "scholarship"
                               ],
                   "bushido":  [
                                   "warriorcode"
                               ],
                   "business":  [
                                    "commerce"
                                ],
                   "butterfly":  [
                                     "insect"
                                 ],
                   "buttress":  [
                                    "support"
                                ],
                   "buttresswall":  [
                                        "supportingwall"
                                    ],
                   "bypass":  [
                                  "avoid"
                              ],
                   "by-product":  [
                                      "sideeffect"
                                  ],
                   "cache":  [
                                 "store"
                             ],
                   "cadaver":  [
                                   "corpse"
                               ],
                   "cage":  [
                                "enclosure"
                            ],
                   "calcium":  [
                                   "mineral"
                               ],
                   "calculate":  [
                                     "compute"
                                 ],
                   "calculation":  [
                                       "computation"
                                   ],
                   "calculus":  [
                                    "advancedmathematics"
                                ],
                   "calibrate":  [
                                     "adjust"
                                 ],
                   "calibration":  [
                                       "adjustment"
                                   ],
                   "caliphate":  [
                                     "islamicstate"
                                 ],
                   "calligraphy":  [
                                       "handwritingart"
                                   ],
                   "caloric":  [
                                   "heat-related"
                               ],
                   "calorie":  [
                                   "energyunit"
                               ],
                   "calve":  [
                                 "split"
                             ],
                   "camel":  [
                                 "desertanimal"
                             ],
                   "camera":  [
                                  "imagingdevice"
                              ],
                   "camouflage":  [
                                      "disguise"
                                  ],
                   "campaign":  [
                                    "drive"
                                ],
                   "canal":  [
                                 "waterway"
                             ],
                   "candle":  [
                                  "waxlight"
                              ],
                   "cane":  [
                                "reed"
                            ],
                   "canoe":  [
                                 "smallboat"
                             ],
                   "canonical":  [
                                     "standard"
                                 ],
                   "canopy":  [
                                  "cover"
                              ],
                   "cantata":  [
                                   "choralwork"
                               ],
                   "canyon":  [
                                  "gorge"
                              ],
                   "capable":  [
                                   "competent"
                               ],
                   "capacity":  [
                                    "ability"
                                ],
                   "capital":  [
                                   "wealth"
                               ],
                   "capitalism":  [
                                      "marketeconomy"
                                  ],
                   "capitalist":  [
                                      "investor"
                                  ],
                   "caption":  [
                                   "label"
                               ],
                   "captive":  [
                                   "prisoner"
                               ],
                   "capture":  [
                                   "seize"
                               ],
                   "caravan":  [
                                   "convoy"
                               ],
                   "carbon":  [
                                  "element"
                              ],
                   "carbonate":  [
                                     "carboncompound"
                                 ],
                   "carbonic":  [
                                    "carbon-related"
                                ],
                   "carboniferous":  [
                                         "coal-bearing"
                                     ],
                   "carcass":  [
                                   "corpse"
                               ],
                   "cardiovascular":  [
                                          "heart-related"
                                      ],
                   "care":  [
                                "concern"
                            ],
                   "caregiver":  [
                                     "carer"
                                 ],
                   "cargo":  [
                                 "freight"
                             ],
                   "caricature":  [
                                      "parody"
                                  ],
                   "carnivore":  [
                                     "meat-eater"
                                 ],
                   "carnivorous":  [
                                       "meat-eating"
                                   ],
                   "cartographic":  [
                                        "map-related"
                                    ],
                   "cartography":  [
                                       "mapmaking"
                                   ],
                   "cashflow":  [
                                    "liquidity"
                                ],
                   "casual":  [
                                  "informal"
                              ],
                   "casualness":  [
                                      "informality"
                                  ],
                   "catalogue":  [
                                     "inventory"
                                 ],
                   "catalyse":  [
                                    "trigger"
                                ],
                   "catalyst":  [
                                    "trigger"
                                ],
                   "catalytic":  [
                                     "triggering"
                                 ],
                   "catastrophe":  [
                                       "disaster"
                                   ],
                   "catastrophic":  [
                                        "disastrous"
                                    ],
                   "catching":  [
                                    "contagious"
                                ],
                   "catchment":  [
                                     "drainagearea"
                                 ],
                   "categorical":  [
                                       "absolute"
                                   ],
                   "category":  [
                                    "class"
                                ],
                   "cater":  [
                                 "provide"
                             ],
                   "caterer":  [
                                   "foodprovider"
                               ],
                   "caterpillar":  [
                                       "larva"
                                   ],
                   "cathedral":  [
                                     "church"
                                 ],
                   "cathedralic":  [
                                       "church-like"
                                   ],
                   "cathode":  [
                                   "negativeelectrode"
                               ],
                   "cattle":  [
                                  "livestock"
                              ],
                   "causal":  [
                                  "cause-related"
                              ],
                   "causality":  [
                                     "causation"
                                 ],
                   "cause":  [
                                 "reason"
                             ],
                   "causeway":  [
                                    "raisedroad"
                                ],
                   "caution":  [
                                   "warning"
                               ],
                   "cautionary":  [
                                      "warning"
                                  ],
                   "cautious":  [
                                    "careful"
                                ],
                   "cautiousness":  [
                                        "carefulness"
                                    ],
                   "cavalry":  [
                                   "mountedtroops"
                               ],
                   "cease":  [
                                 "stop"
                             ],
                   "ceaseless":  [
                                     "continuous"
                                 ],
                   "celebrate":  [
                                     "honour"
                                 ],
                   "celebration":  [
                                       "festivity"
                                   ],
                   "celebratory":  [
                                       "festive"
                                   ],
                   "celebrity":  [
                                     "famousperson"
                                 ],
                   "celerity":  [
                                    "speed"
                                ],
                   "celestial":  [
                                     "heavenly"
                                 ],
                   "cell":  [
                                "unit"
                            ],
                   "censor":  [
                                  "suppress"
                              ],
                   "censorship":  [
                                      "suppression"
                                  ],
                   "center":  [
                                  "centre"
                              ],
                   "central":  [
                                   "core"
                               ],
                   "ceramic":  [
                                   "pottery"
                               ],
                   "ceremonial":  [
                                      "ritual"
                                  ],
                   "ceremony":  [
                                    "ritual"
                                ],
                   "certain":  [
                                   "sure"
                               ],
                   "certificate":  [
                                       "document"
                                   ],
                   "certification":  [
                                         "approval"
                                     ],
                   "certify":  [
                                   "verify"
                               ],
                   "cervical":  [
                                    "neck-related"
                                ],
                   "cessation":  [
                                     "stoppage"
                                 ],
                   "chain":  [
                                 "series"
                             ],
                   "challenge":  [
                                     "difficulty"
                                 ],
                   "challengingly":  [
                                         "difficult"
                                     ],
                   "chameleon":  [
                                     "lizard"
                                 ],
                   "champion":  [
                                    "advocate"
                                ],
                   "championship":  [
                                        "tournament"
                                    ],
                   "chance":  [
                                  "opportunity"
                              ],
                   "chancellor":  [
                                      "official"
                                  ],
                   "chaos":  [
                                 "disorder"
                             ],
                   "chaostheory":  [
                                       "complexitytheory"
                                   ],
                   "chaotic":  [
                                   "disordered"
                               ],
                   "chaoticness":  [
                                       "disorder"
                                   ],
                   "chapel":  [
                                  "smallchurch"
                              ],
                   "character":  [
                                     "trait"
                                 ],
                   "characteristic":  [
                                          "feature"
                                      ],
                   "characterize":  [
                                        "describe"
                                    ],
                   "charge":  [
                                  "loaded"
                              ],
                   "charisma":  [
                                    "charm"
                                ],
                   "chart":  [
                                 "graph"
                             ],
                   "charter":  [
                                   "constitution"
                               ],
                   "chase":  [
                                 "pursue"
                             ],
                   "chemical":  [
                                    "substance"
                                ],
                   "chemist":  [
                                   "chemicalscientist"
                               ],
                   "chest":  [
                                 "torso"
                             ],
                   "chiaroscuro":  [
                                       "light-darkcontrast"
                                   ],
                   "chief":  [
                                 "leader"
                             ],
                   "chiefdom":  [
                                    "tribalstate"
                                ],
                   "child":  [
                                 "minor"
                             ],
                   "childhood":  [
                                     "earlylife"
                                 ],
                   "chimpanzee":  [
                                      "ape"
                                  ],
                   "chinampa":  [
                                    "floatinggarden"
                                ],
                   "chivalric":  [
                                     "knightly"
                                 ],
                   "chivalry":  [
                                    "knighthood"
                                ],
                   "chlorofluorocarbon":  [
                                              "cfc"
                                          ],
                   "chlorophyll":  [
                                       "greenpigment"
                                   ],
                   "chocolate":  [
                                     "cocoaproduct"
                                 ],
                   "chokehold":  [
                                     "grip"
                                 ],
                   "choreography":  [
                                        "movementdesign"
                                    ],
                   "christen":  [
                                    "name"
                                ],
                   "chromatic":  [
                                     "colour-related"
                                 ],
                   "chronic":  [
                                   "long-term"
                               ],
                   "chronicle":  [
                                     "record"
                                 ],
                   "chronological":  [
                                         "time-ordered"
                                     ],
                   "chronology":  [
                                      "timeline"
                                  ],
                   "chronometer":  [
                                       "timekeeper"
                                   ],
                   "cinct":  [
                                 "girdled"
                             ],
                   "cipher":  [
                                  "code"
                              ],
                   "circle":  [
                                  "ring"
                              ],
                   "circuit":  [
                                   "loop"
                               ],
                   "circulate":  [
                                     "spread"
                                 ],
                   "circulation":  [
                                       "flow"
                                   ],
                   "circumference":  [
                                         "perimeter"
                                     ],
                   "circumnavigate":  [
                                          "sailaround"
                                      ],
                   "circumnavigation":  [
                                            "globalvoyage"
                                        ],
                   "circumpolar":  [
                                       "polar-region"
                                   ],
                   "circumstance":  [
                                        "condition"
                                    ],
                   "circumvent":  [
                                      "bypass"
                                  ],
                   "circumvention":  [
                                         "avoidance"
                                     ],
                   "citable":  [
                                   "quotable"
                               ],
                   "citadel":  [
                                   "fortress"
                               ],
                   "citation":  [
                                    "reference"
                                ],
                   "cite":  [
                                "quote"
                            ],
                   "cityscape":  [
                                     "urbanscene"
                                 ],
                   "civil":  [
                                 "civic"
                             ],
                   "civilisation":  [
                                        "society"
                                    ],
                   "civilization":  [
                                        "society"
                                    ],
                   "civilized":  [
                                     "cultured"
                                 ],
                   "claim":  [
                                 "assertion"
                             ],
                   "claimant":  [
                                    "applicant"
                                ],
                   "clan":  [
                                "tribe"
                            ],
                   "clarification":  [
                                         "explanation"
                                     ],
                   "clarify":  [
                                   "explain"
                               ],
                   "clarinet":  [
                                    "woodwind"
                                ],
                   "clarity":  [
                                   "clearness"
                               ],
                   "clash":  [
                                 "conflict"
                             ],
                   "clasp":  [
                                 "grip"
                             ],
                   "class":  [
                                 "category"
                             ],
                   "classical":  [
                                     "traditional"
                                 ],
                   "classification":  [
                                          "categorisation"
                                      ],
                   "classify":  [
                                    "categorise"
                                ],
                   "classmate":  [
                                     "schoolmate"
                                 ],
                   "clause":  [
                                  "provision"
                              ],
                   "clay":  [
                                "mud"
                            ],
                   "clear":  [
                                 "obvious"
                             ],
                   "clearance":  [
                                     "permission"
                                 ],
                   "clever":  [
                                  "smart"
                              ],
                   "cleverness":  [
                                      "intelligence"
                                  ],
                   "click":  [
                                 "press"
                             ],
                   "climactic":  [
                                     "decisive"
                                 ],
                   "climate":  [
                                   "weatherpattern"
                               ],
                   "climatic":  [
                                    "climate-related"
                                ],
                   "climax":  [
                                  "peak"
                              ],
                   "climb":  [
                                 "ascend"
                             ],
                   "clinical":  [
                                    "medical"
                                ],
                   "clipper":  [
                                   "fastship"
                               ],
                   "clone":  [
                                 "copy"
                             ],
                   "close":  [
                                 "near"
                             ],
                   "closure":  [
                                   "ending"
                               ],
                   "clothing":  [
                                    "garment"
                                ],
                   "cloud":  [
                                 "mist"
                             ],
                   "cloudcomputing":  [
                                          "onlinecomputing"
                                      ],
                   "cloudless":  [
                                     "clear"
                                 ],
                   "cluster":  [
                                   "group"
                               ],
                   "coal":  [
                                "fossilfuel"
                            ],
                   "coalesce":  [
                                    "merge"
                                ],
                   "coalescence":  [
                                       "merger"
                                   ],
                   "coalition":  [
                                     "alliance"
                                 ],
                   "coastal":  [
                                   "shoreline"
                               ],
                   "coastline":  [
                                     "shoreline"
                                 ],
                   "cocoa":  [
                                 "cacao"
                             ],
                   "cocoon":  [
                                  "case"
                              ],
                   "code":  [
                                "system"
                            ],
                   "codification":  [
                                        "systematisation"
                                    ],
                   "codify":  [
                                  "formalise"
                              ],
                   "coefficient":  [
                                       "factor"
                                   ],
                   "coefficiental":  [
                                         "factor-related"
                                     ],
                   "cognition":  [
                                     "thinking"
                                 ],
                   "cognitive":  [
                                     "mental"
                                 ],
                   "cohere":  [
                                  "connect"
                              ],
                   "coherence":  [
                                     "consistency"
                                 ],
                   "coherent":  [
                                    "consistent"
                                ],
                   "cohesion":  [
                                    "unity"
                                ],
                   "cohesive":  [
                                    "unified"
                                ],
                   "cohort":  [
                                  "group"
                              ],
                   "coincide":  [
                                    "overlap"
                                ],
                   "coincidence":  [
                                       "overlap"
                                   ],
                   "coincident":  [
                                      "simultaneous"
                                  ],
                   "coincidental":  [
                                        "accidental"
                                    ],
                   "collaborate":  [
                                       "cooperate"
                                   ],
                   "collaboration":  [
                                         "cooperation"
                                     ],
                   "collaborative":  [
                                         "cooperative"
                                     ],
                   "collaborator":  [
                                        "partner"
                                    ],
                   "collapse":  [
                                    "breakdown"
                                ],
                   "collect":  [
                                   "gather"
                               ],
                   "collection":  [
                                      "set"
                                  ],
                   "collective":  [
                                      "shared"
                                  ],
                   "collectivism":  [
                                        "grouporientation"
                                    ],
                   "collectivist":  [
                                        "group-oriented"
                                    ],
                   "collectivity":  [
                                        "groupness"
                                    ],
                   "collide":  [
                                   "crash"
                               ],
                   "collision":  [
                                     "crash"
                                 ],
                   "colloquial":  [
                                      "informal"
                                  ],
                   "colonial":  [
                                    "imperial"
                                ],
                   "colonisation":  [
                                        "settlement"
                                    ],
                   "colonise":  [
                                    "settle"
                                ],
                   "colonization":  [
                                        "settlement"
                                    ],
                   "colonize":  [
                                    "settle"
                                ],
                   "colony":  [
                                  "settlement"
                              ],
                   "colossal":  [
                                    "huge"
                                ],
                   "column":  [
                                  "pillar"
                              ],
                   "combinable":  [
                                      "mergeable"
                                  ],
                   "combination":  [
                                       "mixture"
                                   ],
                   "combine":  [
                                   "merge"
                               ],
                   "combust":  [
                                   "burn"
                               ],
                   "combustion":  [
                                      "burning"
                                  ],
                   "come":  [
                                "arrive"
                            ],
                   "comet":  [
                                 "icybody"
                             ],
                   "cometary":  [
                                    "comet-like"
                                ],
                   "command":  [
                                   "order"
                               ],
                   "commemorate":  [
                                       "honour"
                                   ],
                   "commemoration":  [
                                         "remembrance"
                                     ],
                   "commemorative":  [
                                         "memorial"
                                     ],
                   "commence":  [
                                    "begin"
                                ],
                   "commencement":  [
                                        "beginning"
                                    ],
                   "commendable":  [
                                       "praiseworthy"
                                   ],
                   "commendably":  [
                                       "admirably"
                                   ],
                   "commendation":  [
                                        "praise"
                                    ],
                   "comment":  [
                                   "remark"
                               ],
                   "commentary":  [
                                      "analysis"
                                  ],
                   "commerce":  [
                                    "trade"
                                ],
                   "commercial":  [
                                      "business-related"
                                  ],
                   "commission":  [
                                      "committee"
                                  ],
                   "commodify":  [
                                     "commercialise"
                                 ],
                   "commodity":  [
                                     "goods"
                                 ],
                   "common":  [
                                  "shared"
                              ],
                   "commonality":  [
                                       "similarity"
                                   ],
                   "commonness":  [
                                      "ordinariness"
                                  ],
                   "communal":  [
                                    "shared"
                                ],
                   "communicate":  [
                                       "convey"
                                   ],
                   "communication":  [
                                         "exchange"
                                     ],
                   "communicative":  [
                                         "expressive"
                                     ],
                   "communist":  [
                                     "marxist"
                                 ],
                   "community":  [
                                     "group"
                                 ],
                   "commute":  [
                                   "travel"
                               ],
                   "commuter":  [
                                    "traveller"
                                ],
                   "compact":  [
                                   "dense"
                               ],
                   "companion":  [
                                     "partner"
                                 ],
                   "comparable":  [
                                      "similar"
                                  ],
                   "comparably":  [
                                      "similarly"
                                  ],
                   "compare":  [
                                   "contrast"
                               ],
                   "comparison":  [
                                      "contrast"
                                  ],
                   "compass":  [
                                   "guide"
                               ],
                   "compassion":  [
                                      "sympathy"
                                  ],
                   "compassionate":  [
                                         "sympathetic"
                                     ],
                   "compassionless":  [
                                          "unsympathetic"
                                      ],
                   "compatibility":  [
                                         "fit"
                                     ],
                   "compatible":  [
                                      "consistent"
                                  ],
                   "compatibly":  [
                                      "consistently"
                                  ],
                   "compel":  [
                                  "force"
                              ],
                   "compensate":  [
                                      "reimburse"
                                  ],
                   "compensation":  [
                                        "reimbursement"
                                    ],
                   "compensatory":  [
                                        "offsetting"
                                    ],
                   "compete":  [
                                   "contend"
                               ],
                   "competition":  [
                                       "compete",
                                       "rivalry"
                                   ],
                   "compilation":  [
                                       "collection"
                                   ],
                   "compile":  [
                                   "assemble"
                               ],
                   "compiler":  [
                                    "assembler"
                                ],
                   "complement":  [
                                      "supplement"
                                  ],
                   "complementary":  [
                                         "supplementary"
                                     ],
                   "complete":  [
                                    "finish"
                                ],
                   "complex":  [
                                   "complicated"
                               ],
                   "complexity":  [
                                      "complication"
                                  ],
                   "compliance":  [
                                      "obedience"
                                  ],
                   "complicate":  [
                                      "confuse"
                                  ],
                   "complication":  [
                                        "difficulty"
                                    ],
                   "comply":  [
                                  "obey"
                              ],
                   "component":  [
                                     "part"
                                 ],
                   "compose":  [
                                   "form"
                               ],
                   "composer":  [
                                    "creator"
                                ],
                   "composite":  [
                                     "combined"
                                 ],
                   "composition":  [
                                       "makeup"
                                   ],
                   "composure":  [
                                     "calmness"
                                 ],
                   "compound":  [
                                    "mixture"
                                ],
                   "comprehend":  [
                                      "understand"
                                  ],
                   "comprehensible":  [
                                          "understandable"
                                      ],
                   "comprehension":  [
                                         "understanding"
                                     ],
                   "comprehensive":  [
                                         "complete"
                                     ],
                   "comprehensiveness":  [
                                             "thoroughness"
                                         ],
                   "compress":  [
                                    "condense"
                                ],
                   "compression":  [
                                       "condensation"
                                   ],
                   "compressive":  [
                                       "pressing"
                                   ],
                   "comprise":  [
                                    "include"
                                ],
                   "compromise":  [
                                      "settlement"
                                  ],
                   "compulsion":  [
                                      "pressure"
                                  ],
                   "compulsive":  [
                                      "obsessive"
                                  ],
                   "compulsory":  [
                                      "mandatory"
                                  ],
                   "computation":  [
                                       "calculation"
                                   ],
                   "computational":  [
                                         "calculation-based"
                                     ],
                   "computer":  [
                                    "machine"
                                ],
                   "computing":  [
                                     "computation"
                                 ],
                   "conceal":  [
                                   "hide"
                               ],
                   "concede":  [
                                   "admit"
                               ],
                   "conceit":  [
                                   "vanity"
                               ],
                   "conceivable":  [
                                       "imaginable"
                                   ],
                   "conceive":  [
                                    "imagine"
                                ],
                   "concentration":  [
                                         "focus"
                                     ],
                   "concentric":  [
                                      "centered"
                                  ],
                   "concept":  [
                                   "idea"
                               ],
                   "conception":  [
                                      "understanding"
                                  ],
                   "conceptual":  [
                                      "theoretical"
                                  ],
                   "conceptualization":  [
                                             "formulation"
                                         ],
                   "conceptualize":  [
                                         "formulate"
                                     ],
                   "concern":  [
                                   "worry"
                               ],
                   "concession":  [
                                      "compromise"
                                  ],
                   "concise":  [
                                   "brief"
                               ],
                   "conciseness":  [
                                       "brevity"
                                   ],
                   "concision":  [
                                     "brevity"
                                 ],
                   "conclude":  [
                                    "infer"
                                ],
                   "conclusion":  [
                                      "inference"
                                  ],
                   "conclusive":  [
                                      "decisive"
                                  ],
                   "concrete":  [
                                    "specific"
                                ],
                   "concreteness":  [
                                        "specificity"
                                    ],
                   "concur":  [
                                  "agree"
                              ],
                   "concurrence":  [
                                       "agreement"
                                   ],
                   "concurrent":  [
                                      "simultaneous"
                                  ],
                   "condense":  [
                                    "compress"
                                ],
                   "condenser":  [
                                     "cooler"
                                 ],
                   "condition":  [
                                     "state"
                                 ],
                   "conduct":  [
                                   "perform"
                               ],
                   "conductive":  [
                                      "transmitting"
                                  ],
                   "conductivity":  [
                                        "transmission"
                                    ],
                   "conductor":  [
                                     "transmitter"
                                 ],
                   "confederacy":  [
                                       "alliance"
                                   ],
                   "conference":  [
                                      "meeting"
                                  ],
                   "confession":  [
                                      "admission"
                                  ],
                   "confine":  [
                                   "restrict"
                               ],
                   "confinement":  [
                                       "restriction"
                                   ],
                   "confirm":  [
                                   "verify"
                               ],
                   "confirmation":  [
                                        "verification"
                                    ],
                   "confirmatory":  [
                                        "verifying"
                                    ],
                   "conflict":  [
                                    "clash"
                                ],
                   "conform":  [
                                   "comply"
                               ],
                   "conformity":  [
                                      "compliance"
                                  ],
                   "confront":  [
                                    "face"
                                ],
                   "confrontation":  [
                                         "clash"
                                     ],
                   "confrontational":  [
                                           "aggressive"
                                       ],
                   "confuse":  [
                                   "bewilder"
                               ],
                   "confute":  [
                                   "refute"
                               ],
                   "congest":  [
                                   "clog"
                               ],
                   "congestion":  [
                                      "overcrowding"
                                  ],
                   "congestive":  [
                                      "clogging"
                                  ],
                   "congregate":  [
                                      "gather"
                                  ],
                   "congregation":  [
                                        "assembly"
                                    ],
                   "congress":  [
                                    "assembly"
                                ],
                   "congruence":  [
                                      "alignment"
                                  ],
                   "congruent":  [
                                     "consistent"
                                 ],
                   "coniferous":  [
                                      "cone-bearing"
                                  ],
                   "conjectural":  [
                                       "speculative"
                                   ],
                   "conjecture":  [
                                      "guess"
                                  ],
                   "connect":  [
                                   "link"
                               ],
                   "connection":  [
                                      "link"
                                  ],
                   "connectivity":  [
                                        "connectedness"
                                    ],
                   "conquer":  [
                                   "defeat"
                               ],
                   "conqueror":  [
                                     "victor"
                                 ],
                   "conquest":  [
                                    "takeover"
                                ],
                   "conquistador":  [
                                        "conqueror"
                                    ],
                   "conscience":  [
                                      "moralsense"
                                  ],
                   "conscious":  [
                                     "aware"
                                 ],
                   "consecutive":  [
                                       "successive"
                                   ],
                   "consensual":  [
                                      "agreed"
                                  ],
                   "consensus":  [
                                     "agreement"
                                 ],
                   "consent":  [
                                   "permission"
                               ],
                   "consequence":  [
                                       "result"
                                   ],
                   "consequentialist":  [
                                            "outcome-based"
                                        ],
                   "conservation":  [
                                        "preservation"
                                    ],
                   "conservationist":  [
                                           "environmentalist"
                                       ],
                   "conservatoire":  [
                                         "musicschool"
                                     ],
                   "consider":  [
                                    "examine"
                                ],
                   "considerable":  [
                                        "substantial"
                                    ],
                   "considerably":  [
                                        "substantially"
                                    ],
                   "considerate":  [
                                       "thoughtful"
                                   ],
                   "consideration":  [
                                         "thought"
                                     ],
                   "consist":  [
                                   "comprise"
                               ],
                   "consistency":  [
                                       "coherence"
                                   ],
                   "consistent":  [
                                      "coherent"
                                  ],
                   "consolation":  [
                                       "comfort"
                                   ],
                   "consolatory":  [
                                       "comforting"
                                   ],
                   "consolidate":  [
                                       "strengthen"
                                   ],
                   "conspicuous":  [
                                       "noticeable"
                                   ],
                   "conspicuousness":  [
                                           "visibility"
                                       ],
                   "constant":  [
                                    "continuous"
                                ],
                   "constellated":  [
                                        "clustered"
                                    ],
                   "constellation":  [
                                         "cluster"
                                     ],
                   "constitute":  [
                                      "form"
                                  ],
                   "constitution":  [
                                        "charter"
                                    ],
                   "constitutional":  [
                                          "legal-fundamental"
                                      ],
                   "constrain":  [
                                     "restrict"
                                 ],
                   "constraint":  [
                                      "restriction"
                                  ],
                   "constrict":  [
                                     "tighten"
                                 ],
                   "construable":  [
                                       "interpretable"
                                   ],
                   "construal":  [
                                     "interpretation"
                                 ],
                   "construct":  [
                                     "build"
                                 ],
                   "construction":  [
                                        "building"
                                    ],
                   "constructivism":  [
                                          "constructionism"
                                      ],
                   "constructivist":  [
                                          "constructionist"
                                      ],
                   "construe":  [
                                    "interpret"
                                ],
                   "consult":  [
                                   "advise"
                               ],
                   "consume":  [
                                   "useup"
                               ],
                   "consumer":  [
                                    "buyer"
                                ],
                   "consumerism":  [
                                       "materialism"
                                   ],
                   "consumption":  [
                                       "use"
                                   ],
                   "contact":  [
                                   "touch"
                               ],
                   "contagion":  [
                                     "infection"
                                 ],
                   "contain":  [
                                   "include"
                               ],
                   "container":  [
                                     "vessel"
                                 ],
                   "containment":  [
                                       "control"
                                   ],
                   "contaminant":  [
                                       "pollutant"
                                   ],
                   "contaminate":  [
                                       "pollute"
                                   ],
                   "contamination":  [
                                         "pollution"
                                     ],
                   "contemplate":  [
                                       "consider"
                                   ],
                   "contemplation":  [
                                         "reflection"
                                     ],
                   "contemplative":  [
                                         "reflective"
                                     ],
                   "contemporaneity":  [
                                           "modernity"
                                       ],
                   "contemporary":  [
                                        "current"
                                    ],
                   "content":  [
                                   "material"
                               ],
                   "context":  [
                                   "setting"
                               ],
                   "contextual":  [
                                      "situational"
                                  ],
                   "contiguous":  [
                                      "adjacent"
                                  ],
                   "continent":  [
                                     "landmass"
                                 ],
                   "continental":  [
                                       "mainland"
                                   ],
                   "continue":  [
                                    "persist"
                                ],
                   "continuity":  [
                                      "persistence"
                                  ],
                   "continuous":  [
                                      "unbroken"
                                  ],
                   "contort":  [
                                   "twist"
                               ],
                   "contract":  [
                                    "agreement"
                                ],
                   "contradict":  [
                                      "oppose"
                                  ],
                   "contradiction":  [
                                         "inconsistency"
                                     ],
                   "contradictory":  [
                                         "inconsistent"
                                     ],
                   "contribute":  [
                                      "add"
                                  ],
                   "contribution":  [
                                        "input"
                                    ],
                   "contributor":  [
                                       "participant"
                                   ],
                   "contributory":  [
                                        "contribute",
                                        "causal"
                                    ],
                   "control":  [
                                   "regulation"
                               ],
                   "controversy":  [
                                       "dispute"
                                   ],
                   "convection":  [
                                      "heattransfer"
                                  ],
                   "convective":  [
                                      "flow-based"
                                  ],
                   "convene":  [
                                   "assemble"
                               ],
                   "convener":  [
                                    "organiser"
                                ],
                   "convention":  [
                                      "custom"
                                  ],
                   "conventional":  [
                                        "traditional"
                                    ],
                   "converge":  [
                                    "meet"
                                ],
                   "convergence":  [
                                       "merging"
                                   ],
                   "convergent":  [
                                      "merging"
                                  ],
                   "conversational":  [
                                          "informal"
                                      ],
                   "converse":  [
                                    "opposite"
                                ],
                   "convert":  [
                                   "transform"
                               ],
                   "convey":  [
                                  "communicate"
                              ],
                   "conveyance":  [
                                      "transport"
                                  ],
                   "conveyor":  [
                                    "carrier"
                                ],
                   "convict":  [
                                   "prisoner"
                               ],
                   "convoy":  [
                                  "caravan"
                              ],
                   "convulse":  [
                                    "shake"
                                ],
                   "cooperate":  [
                                     "collaborate"
                                 ],
                   "cooperation":  [
                                       "collaboration"
                                   ],
                   "cooperative":  [
                                       "collaborative"
                                   ],
                   "coordinate":  [
                                      "organise"
                                  ],
                   "coordination":  [
                                        "organisation"
                                    ],
                   "coordinator":  [
                                       "organiser"
                                   ],
                   "copy":  [
                                "duplicate"
                            ],
                   "coral":  [
                                 "reeforganism"
                             ],
                   "coralline":  [
                                     "coral-like"
                                 ],
                   "cord":  [
                                "rope"
                            ],
                   "cordial":  [
                                   "friendly"
                               ],
                   "core":  [
                                "center"
                            ],
                   "coreless":  [
                                    "centerless"
                                ],
                   "corporal":  [
                                    "bodily"
                                ],
                   "corporate":  [
                                     "company-related"
                                 ],
                   "corporation":  [
                                       "company"
                                   ],
                   "correct":  [
                                   "accurate"
                               ],
                   "correlate":  [
                                     "associate"
                                 ],
                   "correlation":  [
                                       "association"
                                   ],
                   "correspond":  [
                                      "match"
                                  ],
                   "correspondence":  [
                                          "match"
                                      ],
                   "correspondingly":  [
                                           "matching"
                                       ],
                   "corroborate":  [
                                       "confirm"
                                   ],
                   "corroboration":  [
                                         "confirmation"
                                     ],
                   "corrode":  [
                                   "erode"
                               ],
                   "corrosive":  [
                                     "erosive"
                                 ],
                   "cortex":  [
                                  "outerlayer"
                              ],
                   "cortical":  [
                                    "cortex-related"
                                ],
                   "cosmetic":  [
                                    "appearance-related"
                                ],
                   "cosmological":  [
                                        "universe-related"
                                    ],
                   "cosmology":  [
                                     "universestudy"
                                 ],
                   "cosmonaut":  [
                                     "astronaut"
                                 ],
                   "cosmos":  [
                                  "universe"
                              ],
                   "cotton":  [
                                  "fiber"
                              ],
                   "council":  [
                                   "committee"
                               ],
                   "count":  [
                                 "calculate"
                             ],
                   "counter":  [
                                   "opposite"
                               ],
                   "counteract":  [
                                      "offset"
                                  ],
                   "counterargument":  [
                                           "objection"
                                       ],
                   "counterbalance":  [
                                          "offset"
                                      ],
                   "counterfeit":  [
                                       "fake"
                                   ],
                   "counterfeiter":  [
                                         "forger"
                                     ],
                   "counterpart":  [
                                       "equivalent"
                                   ],
                   "counterpoint":  [
                                        "contrast"
                                    ],
                   "courage":  [
                                   "bravery"
                               ],
                   "court":  [
                                 "tribunal"
                             ],
                   "cover":  [
                                 "protect"
                             ],
                   "coverage":  [
                                    "reporting"
                                ],
                   "craft":  [
                                 "skill"
                             ],
                   "create":  [
                                  "produce"
                              ],
                   "creation":  [
                                    "production"
                                ],
                   "creative":  [
                                    "inventive"
                                ],
                   "creativity":  [
                                      "inventiveness"
                                  ],
                   "creator":  [
                                   "maker"
                               ],
                   "creature":  [
                                    "being"
                                ],
                   "credential":  [
                                      "qualification"
                                  ],
                   "credibility":  [
                                       "trustworthiness"
                                   ],
                   "credible":  [
                                    "believable"
                                ],
                   "credibly":  [
                                    "believably"
                                ],
                   "credit":  [
                                  "recognition"
                              ],
                   "cricket":  [
                                   "insect"
                               ],
                   "crime":  [
                                 "offence"
                             ],
                   "criminal":  [
                                    "offender"
                                ],
                   "criminalize":  [
                                       "prohibit"
                                   ],
                   "crisscross":  [
                                      "intersect"
                                  ],
                   "criteria":  [
                                    "standards"
                                ],
                   "criterion":  [
                                     "standard"
                                 ],
                   "crocodile":  [
                                     "reptile"
                                 ],
                   "crop":  [
                                "harvest"
                            ],
                   "cropscience":  [
                                       "agronomy"
                                   ],
                   "cross":  [
                                 "intersect"
                             ],
                   "crossbreed":  [
                                      "hybridise"
                                  ],
                   "crowd":  [
                                 "throng"
                             ],
                   "crowdfunding":  [
                                        "publicfunding"
                                    ],
                   "crucial":  [
                                   "vital"
                               ],
                   "cruciality":  [
                                      "importance"
                                  ],
                   "crucible":  [
                                    "test"
                                ],
                   "crucifix":  [
                                    "cross"
                                ],
                   "crust":  [
                                 "outerlayer"
                             ],
                   "crustacean":  [
                                      "shellfish"
                                  ],
                   "crustaceous":  [
                                       "shell-like"
                                   ],
                   "crustal":  [
                                   "crust-related"
                               ],
                   "crypt":  [
                                 "tomb"
                             ],
                   "cryptographic":  [
                                         "encryption-related"
                                     ],
                   "cryptography":  [
                                        "encryption"
                                    ],
                   "crystal":  [
                                   "mineral"
                               ],
                   "crystalline":  [
                                       "crystal-like"
                                   ],
                   "crystallographic":  [
                                            "crystal-based"
                                        ],
                   "culminate":  [
                                     "peak"
                                 ],
                   "culmination":  [
                                       "climax"
                                   ],
                   "cult":  [
                                "sect"
                            ],
                   "cultivable":  [
                                      "farmable"
                                  ],
                   "cultivate":  [
                                     "develop"
                                 ],
                   "cultivation":  [
                                       "farming"
                                   ],
                   "cultivator":  [
                                      "farmer"
                                  ],
                   "cultural":  [
                                    "social"
                                ],
                   "culture":  [
                                   "civilisation"
                               ],
                   "cumber":  [
                                  "burden"
                              ],
                   "cumbersome":  [
                                      "awkward"
                                  ],
                   "cumbersomeness":  [
                                          "awkwardness"
                                      ],
                   "cumulative":  [
                                      "accumulated"
                                  ],
                   "cumulus":  [
                                   "cloudmass"
                               ],
                   "curable":  [
                                   "treatable"
                               ],
                   "curation":  [
                                    "selection"
                                ],
                   "curator":  [
                                   "keeper"
                               ],
                   "curb":  [
                                "limit"
                            ],
                   "cure":  [
                                "heal"
                            ],
                   "curiosity":  [
                                     "interest"
                                 ],
                   "currency":  [
                                    "money"
                                ],
                   "current":  [
                                   "flow"
                               ],
                   "curricular":  [
                                      "course-related"
                                  ],
                   "curriculum":  [
                                      "courseplan"
                                  ],
                   "curtail":  [
                                   "reduce"
                               ],
                   "curtailment":  [
                                       "reduction"
                                   ],
                   "cyanobacterium":  [
                                          "blue-greenbacterium"
                                      ],
                   "cybernetic":  [
                                      "control-system"
                                  ],
                   "cycle":  [
                                 "loop"
                             ],
                   "cyclic":  [
                                  "periodic"
                              ],
                   "cyclone":  [
                                   "storm"
                               ],
                   "cyclonic":  [
                                    "storm-related"
                                ],
                   "danger":  [
                                  "risk"
                              ],
                   "dangerous":  [
                                     "risky"
                                 ],
                   "dark":  [
                                "dim"
                            ],
                   "dart":  [
                                "arrow"
                            ],
                   "date":  [
                                "time"
                            ],
                   "debatable":  [
                                     "questionable"
                                 ],
                   "debate":  [
                                  "discussion"
                              ],
                   "debater":  [
                                   "discussant"
                               ],
                   "debris":  [
                                  "wreckage"
                              ],
                   "debt":  [
                                "liability"
                            ],
                   "debtcapacity":  [
                                        "borrowinglimit"
                                    ],
                   "debtfinancing":  [
                                         "borrowing"
                                     ],
                   "debunk":  [
                                  "disprove"
                              ],
                   "debunker":  [
                                    "myth-buster"
                                ],
                   "deceit":  [
                                  "deception"
                              ],
                   "deceitful":  [
                                     "dishonest"
                                 ],
                   "deceitfulness":  [
                                         "dishonesty"
                                     ],
                   "deceive":  [
                                   "mislead"
                               ],
                   "decelerate":  [
                                      "slowdown"
                                  ],
                   "decentralization":  [
                                            "devolution"
                                        ],
                   "decentralize":  [
                                        "distributepower"
                                    ],
                   "deception":  [
                                     "fraud"
                                 ],
                   "deceptive":  [
                                     "misleading"
                                 ],
                   "decide":  [
                                  "determine"
                              ],
                   "decimate":  [
                                    "devastate"
                                ],
                   "decipher":  [
                                    "decode"
                                ],
                   "decipherable":  [
                                        "readable"
                                    ],
                   "decipherment":  [
                                        "decoding"
                                    ],
                   "decision":  [
                                    "choice"
                                ],
                   "decisive":  [
                                    "conclusive"
                                ],
                   "decisiveness":  [
                                        "firmness"
                                    ],
                   "declaration":  [
                                       "statement"
                                   ],
                   "declare":  [
                                   "announce"
                               ],
                   "decline":  [
                                   "decrease"
                               ],
                   "decode":  [
                                  "decipher"
                              ],
                   "decoder":  [
                                   "interpreter"
                               ],
                   "decompose":  [
                                     "breakdown"
                                 ],
                   "deconstructivism":  [
                                            "fragmentation"
                                        ],
                   "deconstructivist":  [
                                            "postmodern"
                                        ],
                   "decoration":  [
                                      "ornament"
                                  ],
                   "decorative":  [
                                      "ornamental"
                                  ],
                   "decree":  [
                                  "order"
                              ],
                   "decriminalize":  [
                                         "legalise"
                                     ],
                   "dedicate":  [
                                    "devote"
                                ],
                   "deduce":  [
                                  "infer"
                              ],
                   "deduction":  [
                                     "inference"
                                 ],
                   "deductive":  [
                                     "inferential"
                                 ],
                   "deem":  [
                                "consider"
                            ],
                   "deep":  [
                                "profound"
                            ],
                   "deepen":  [
                                  "intensify"
                              ],
                   "deer":  [
                                "ungulate"
                            ],
                   "defect":  [
                                  "flaw"
                              ],
                   "defective":  [
                                     "faulty"
                                 ],
                   "defectiveness":  [
                                         "faultiness"
                                     ],
                   "defence":  [
                                   "protection"
                               ],
                   "defend":  [
                                  "protect"
                              ],
                   "defendant":  [
                                     "accused"
                                 ],
                   "defense":  [
                                   "protection"
                               ],
                   "defensible":  [
                                      "justifiable"
                                  ],
                   "defensive":  [
                                     "protective"
                                 ],
                   "defiance":  [
                                    "resistance"
                                ],
                   "deficiency":  [
                                      "shortage"
                                  ],
                   "deficient":  [
                                     "insufficient"
                                 ],
                   "deficit":  [
                                   "shortfall"
                               ],
                   "defies":  [
                                  "resist"
                              ],
                   "definable":  [
                                     "describable"
                                 ],
                   "define":  [
                                  "specify"
                              ],
                   "definition":  [
                                      "meaning"
                                  ],
                   "definitive":  [
                                      "final"
                                  ],
                   "deforest":  [
                                    "clearforest"
                                ],
                   "deforestation":  [
                                         "forestclearing"
                                     ],
                   "deform":  [
                                  "distort"
                              ],
                   "deformation":  [
                                       "distortion"
                                   ],
                   "deformity":  [
                                     "abnormality"
                                 ],
                   "defunct":  [
                                   "obsolete"
                               ],
                   "defy":  [
                                "resist"
                            ],
                   "degradation":  [
                                       "deterioration"
                                   ],
                   "degrade":  [
                                   "deteriorate"
                               ],
                   "delay":  [
                                 "postpone"
                             ],
                   "deliberate":  [
                                      "intentional"
                                  ],
                   "deliberative":  [
                                        "consultative"
                                    ],
                   "delicate":  [
                                    "fragile"
                                ],
                   "delineate":  [
                                     "outline"
                                 ],
                   "delineation":  [
                                       "outline"
                                   ],
                   "delineative":  [
                                       "descriptive"
                                   ],
                   "deliver":  [
                                   "provide"
                               ],
                   "delta":  [
                                 "rivermouth"
                             ],
                   "deltaic":  [
                                   "delta-related"
                               ],
                   "demand":  [
                                  "requirement"
                              ],
                   "democracy":  [
                                     "self-government"
                                 ],
                   "democratic":  [
                                      "representative"
                                  ],
                   "demographic":  [
                                       "population-related"
                                   ],
                   "demography":  [
                                      "populationstudy"
                                  ],
                   "demolish":  [
                                    "destroy"
                                ],
                   "demonstrate":  [
                                       "show"
                                   ],
                   "demonstration":  [
                                         "display"
                                     ],
                   "demonstrative":  [
                                         "expressive"
                                     ],
                   "denotation":  [
                                      "literalmeaning"
                                  ],
                   "denotative":  [
                                      "literal"
                                  ],
                   "denote":  [
                                  "indicate"
                              ],
                   "denounce":  [
                                    "condemn"
                                ],
                   "dense":  [
                                 "compact"
                             ],
                   "density":  [
                                   "compactness"
                               ],
                   "dental":  [
                                  "tooth-related"
                              ],
                   "depart":  [
                                  "leave"
                              ],
                   "depend":  [
                                  "rely"
                              ],
                   "dependable":  [
                                      "reliable"
                                  ],
                   "dependency":  [
                                      "reliance"
                                  ],
                   "depict":  [
                                  "portray"
                              ],
                   "depiction":  [
                                     "portrayal"
                                 ],
                   "depictive":  [
                                     "representational"
                                 ],
                   "deplete":  [
                                   "exhaust"
                               ],
                   "depletion":  [
                                     "exhaustion"
                                 ],
                   "deploy":  [
                                  "use"
                              ],
                   "deployment":  [
                                      "use"
                                  ],
                   "deposit":  [
                                   "sediment"
                               ],
                   "depress":  [
                                   "lower"
                               ],
                   "depression":  [
                                      "downturn"
                                  ],
                   "deprive":  [
                                   "deny"
                               ],
                   "derivation":  [
                                      "origin"
                                  ],
                   "derivative":  [
                                      "derivedform"
                                  ],
                   "derive":  [
                                  "obtain"
                              ],
                   "desalinate":  [
                                      "removesalt"
                                  ],
                   "desalination":  [
                                        "saltremoval"
                                    ],
                   "descend":  [
                                   "godown"
                               ],
                   "descent":  [
                                   "decline"
                               ],
                   "description":  [
                                       "account"
                                   ],
                   "descriptive":  [
                                       "explanatory"
                                   ],
                   "desert":  [
                                  "wilderness"
                              ],
                   "desertification":  [
                                           "landdegradation"
                                       ],
                   "desertify":  [
                                     "turnbarren"
                                 ],
                   "design":  [
                                  "plan"
                              ],
                   "designate":  [
                                     "appoint"
                                 ],
                   "designation":  [
                                       "label"
                                   ],
                   "designator":  [
                                      "marker"
                                  ],
                   "desolate":  [
                                    "bleak"
                                ],
                   "desolation":  [
                                      "devastation"
                                  ],
                   "despoil":  [
                                   "plunder"
                               ],
                   "despondent":  [
                                      "hopeless"
                                  ],
                   "destruction":  [
                                       "devastation"
                                   ],
                   "detach":  [
                                  "separate"
                              ],
                   "detachable":  [
                                      "removable"
                                  ],
                   "detachment":  [
                                      "separation"
                                  ],
                   "detail":  [
                                  "specific"
                              ],
                   "detailedly":  [
                                      "specific"
                                  ],
                   "detect":  [
                                  "identify"
                              ],
                   "detectable":  [
                                      "noticeable"
                                  ],
                   "detection":  [
                                     "identification"
                                 ],
                   "detector":  [
                                    "sensor"
                                ],
                   "deter":  [
                                 "discourage"
                             ],
                   "deteriorate":  [
                                       "worsen"
                                   ],
                   "deterioration":  [
                                         "decline"
                                     ],
                   "determine":  [
                                     "decide"
                                 ],
                   "deterrence":  [
                                      "prevention"
                                  ],
                   "deterrent":  [
                                     "discouragement"
                                 ],
                   "detest":  [
                                  "hate"
                              ],
                   "detestable":  [
                                      "hateful"
                                  ],
                   "detestation":  [
                                       "hatred"
                                   ],
                   "detriment":  [
                                     "harm"
                                 ],
                   "detrimental":  [
                                       "harmful"
                                   ],
                   "detrimentalness":  [
                                           "harmfulness"
                                       ],
                   "devalue":  [
                                   "depreciate"
                               ],
                   "devastation":  [
                                       "destruction"
                                   ],
                   "develop":  [
                                   "grow"
                               ],
                   "developmental":  [
                                         "growth-related"
                                     ],
                   "deviant":  [
                                   "abnormal"
                               ],
                   "deviate":  [
                                   "depart"
                               ],
                   "deviation":  [
                                     "departure"
                                 ],
                   "device":  [
                                  "tool"
                              ],
                   "devise":  [
                                  "design"
                              ],
                   "devoid":  [
                                  "lacking"
                              ],
                   "devour":  [
                                  "consume"
                              ],
                   "diagnose":  [
                                    "identify"
                                ],
                   "diagnosis":  [
                                     "identification"
                                 ],
                   "dialect":  [
                                   "vernacular"
                               ],
                   "dialectal":  [
                                     "vernacular"
                                 ],
                   "dialectic":  [
                                     "dialogue"
                                 ],
                   "dialectical":  [
                                       "interactive"
                                   ],
                   "dialogue":  [
                                    "conversation"
                                ],
                   "dictate":  [
                                   "command"
                               ],
                   "dictionary":  [
                                      "lexicon"
                                  ],
                   "diet":  [
                                "nutrition"
                            ],
                   "dietary":  [
                                   "nutritional"
                               ],
                   "differ":  [
                                  "vary"
                              ],
                   "difference":  [
                                      "distinction"
                                  ],
                   "different":  [
                                     "distinct"
                                 ],
                   "differential":  [
                                        "variable"
                                    ],
                   "differentiate":  [
                                         "distinguish"
                                     ],
                   "differentiation":  [
                                           "distinction"
                                       ],
                   "diffuse":  [
                                   "spread"
                               ],
                   "diffusion":  [
                                     "spread"
                                 ],
                   "dig":  [
                               "excavate"
                           ],
                   "digest":  [
                                  "absorb"
                              ],
                   "digestion":  [
                                     "absorption"
                                 ],
                   "digestive":  [
                                     "stomach-related"
                                 ],
                   "digit":  [
                                 "number"
                             ],
                   "digital":  [
                                   "electronic"
                               ],
                   "digitization":  [
                                        "digitalconversion"
                                    ],
                   "digitize":  [
                                    "convertdigitally"
                                ],
                   "dignity":  [
                                   "worth"
                               ],
                   "dilemma":  [
                                   "predicament"
                               ],
                   "dilemmatic":  [
                                      "problematic"
                                  ],
                   "dimension":  [
                                     "aspect"
                                 ],
                   "diminish":  [
                                    "reduce"
                                ],
                   "diminution":  [
                                      "reduction"
                                  ],
                   "dinosaur":  [
                                    "prehistoricreptile"
                                ],
                   "diploma":  [
                                   "certificate"
                               ],
                   "direct":  [
                                  "guide"
                              ],
                   "direction":  [
                                     "orientation"
                                 ],
                   "director":  [
                                    "manager"
                                ],
                   "disable":  [
                                   "deactivate"
                               ],
                   "disburse":  [
                                    "payout"
                                ],
                   "discern":  [
                                   "perceive"
                               ],
                   "discernible":  [
                                       "detectable"
                                   ],
                   "discernment":  [
                                       "judgment"
                                   ],
                   "discharge":  [
                                     "release"
                                 ],
                   "disciple":  [
                                    "follower"
                                ],
                   "disciplinary":  [
                                        "field-related"
                                    ],
                   "discipline":  [
                                      "field"
                                  ],
                   "disclose":  [
                                    "reveal"
                                ],
                   "disclosure":  [
                                      "revelation"
                                  ],
                   "discourage":  [
                                      "deter"
                                  ],
                   "discourse":  [
                                     "discussion"
                                 ],
                   "discovered":  [
                                      "found"
                                  ],
                   "discrepancy":  [
                                       "difference"
                                   ],
                   "discrepant":  [
                                      "inconsistent"
                                  ],
                   "discriminate":  [
                                        "differentiate"
                                    ],
                   "discrimination":  [
                                          "bias"
                                      ],
                   "discriminatory":  [
                                          "biased"
                                      ],
                   "discursive":  [
                                      "argumentative"
                                  ],
                   "disembowelment":  [
                                          "evisceration"
                                      ],
                   "disenfranchisement":  [
                                              "exclusion"
                                          ],
                   "disentangle":  [
                                       "clarify"
                                   ],
                   "dish":  [
                                "plate"
                            ],
                   "disincentive":  [
                                        "deterrent"
                                    ],
                   "disincentivize":  [
                                          "discourage"
                                      ],
                   "disintegrate":  [
                                        "breakapart"
                                    ],
                   "disintegration":  [
                                          "breakdown"
                                      ],
                   "disinter":  [
                                    "unearth"
                                ],
                   "dismantle":  [
                                     "takeapart"
                                 ],
                   "dismiss":  [
                                   "reject"
                               ],
                   "dismissal":  [
                                     "rejection"
                                 ],
                   "dismissive":  [
                                      "contemptuous"
                                  ],
                   "disorder":  [
                                    "chaos"
                                ],
                   "disorderliness":  [
                                          "chaos"
                                      ],
                   "dispatch":  [
                                    "send"
                                ],
                   "dispensable":  [
                                       "unnecessary"
                                   ],
                   "dispense":  [
                                    "distribute"
                                ],
                   "dispersal":  [
                                     "spread"
                                 ],
                   "disperse":  [
                                    "scatter"
                                ],
                   "dispersion":  [
                                      "spread"
                                  ],
                   "displace":  [
                                    "move"
                                ],
                   "displacement":  [
                                        "relocation"
                                    ],
                   "display":  [
                                   "show"
                               ],
                   "displayable":  [
                                       "showable"
                                   ],
                   "dispose":  [
                                   "arrange"
                               ],
                   "disposition":  [
                                       "tendency"
                                   ],
                   "disproof":  [
                                    "refutation"
                                ],
                   "disprovable":  [
                                       "refutable"
                                   ],
                   "disprove":  [
                                    "refute"
                                ],
                   "dispute":  [
                                   "conflict"
                               ],
                   "disregard":  [
                                     "ignore"
                                 ],
                   "disrupt":  [
                                   "disturb"
                               ],
                   "disruption":  [
                                      "disturbance"
                                  ],
                   "disruptive":  [
                                      "disturbing"
                                  ],
                   "dissect":  [
                                   "analyze"
                               ],
                   "dissection":  [
                                      "analysis"
                                  ],
                   "disseminate":  [
                                       "spread"
                                   ],
                   "dissemination":  [
                                         "spread"
                                     ],
                   "disseminator":  [
                                        "spreader"
                                    ],
                   "dissipate":  [
                                     "disperse"
                                 ],
                   "dissolve":  [
                                    "disappear"
                                ],
                   "distance":  [
                                    "space"
                                ],
                   "distinct":  [
                                    "different"
                                ],
                   "distinction":  [
                                       "difference"
                                   ],
                   "distinctive":  [
                                       "characteristic"
                                   ],
                   "distinguish":  [
                                       "differentiate"
                                   ],
                   "distinguishable":  [
                                           "recognisable"
                                       ],
                   "distort":  [
                                   "warp"
                               ],
                   "distortion":  [
                                      "warping"
                                  ],
                   "distract":  [
                                    "divert"
                                ],
                   "distraction":  [
                                       "diversion"
                                   ],
                   "distribute":  [
                                      "allocate"
                                  ],
                   "distribution":  [
                                        "allocation"
                                    ],
                   "distributor":  [
                                       "supplier"
                                   ],
                   "district":  [
                                    "area"
                                ],
                   "diverge":  [
                                   "separate"
                               ],
                   "divergence":  [
                                      "separation"
                                  ],
                   "divergent":  [
                                     "different"
                                 ],
                   "diverse":  [
                                   "varied"
                               ],
                   "diversification":  [
                                           "varietyincrease"
                                       ],
                   "diversify":  [
                                     "vary"
                                 ],
                   "diversion":  [
                                     "distraction"
                                 ],
                   "diversity":  [
                                     "variety"
                                 ],
                   "divert":  [
                                  "redirect"
                              ],
                   "divide":  [
                                  "split"
                              ],
                   "division":  [
                                    "split"
                                ],
                   "doctoral":  [
                                    "phd-level"
                                ],
                   "document":  [
                                    "record"
                                ],
                   "domestic":  [
                                    "household"
                                ],
                   "domesticate":  [
                                       "tame"
                                   ],
                   "domestication":  [
                                         "taming"
                                     ],
                   "dominance":  [
                                     "control"
                                 ],
                   "dominant":  [
                                    "leading"
                                ],
                   "dominate":  [
                                    "control"
                                ],
                   "domination":  [
                                      "control"
                                  ],
                   "dominion":  [
                                    "rule"
                                ],
                   "dopamine":  [
                                    "rewardchemical"
                                ],
                   "dopaminergic":  [
                                        "dopamine-related"
                                    ],
                   "dormancy":  [
                                    "inactivity"
                                ],
                   "dormant":  [
                                   "inactive"
                               ],
                   "dormitory":  [
                                     "residencehall"
                                 ],
                   "doubt":  [
                                 "uncertainty"
                             ],
                   "doubtful":  [
                                    "uncertain"
                                ],
                   "downturn":  [
                                    "decline"
                                ],
                   "draft":  [
                                 "version"
                             ],
                   "drafter":  [
                                   "writer"
                               ],
                   "dragon":  [
                                  "mythicbeast"
                              ],
                   "drainagebasin":  [
                                         "catchment"
                                     ],
                   "dramatic":  [
                                    "striking"
                                ],
                   "dramatist":  [
                                     "playwright"
                                 ],
                   "drastic":  [
                                   "severe"
                               ],
                   "drasticness":  [
                                       "severity"
                                   ],
                   "draw":  [
                                "pull"
                            ],
                   "drift":  [
                                 "float"
                             ],
                   "drive":  [
                                 "motivate"
                             ],
                   "drone":  [
                                 "unmannedaircraft"
                             ],
                   "drought":  [
                                   "dryspell"
                               ],
                   "drug":  [
                                "medicine"
                            ],
                   "drumlin":  [
                                   "glacialhill"
                               ],
                   "dry":  [
                               "arid"
                           ],
                   "dubiety":  [
                                   "doubt"
                               ],
                   "dubious":  [
                                   "questionable"
                               ],
                   "dubiousness":  [
                                       "uncertainty"
                                   ],
                   "duct":  [
                                "channel"
                            ],
                   "ductile":  [
                                   "malleable"
                               ],
                   "ductility":  [
                                     "malleability"
                                 ],
                   "due":  [
                               "owed"
                           ],
                   "dueness":  [
                                   "appropriateness"
                               ],
                   "dune":  [
                                "sandhill"
                            ],
                   "dung":  [
                                "manure"
                            ],
                   "duo":  [
                               "pair"
                           ],
                   "duplex":  [
                                  "double"
                              ],
                   "duplicate":  [
                                     "copy"
                                 ],
                   "duplicitous":  [
                                       "deceitful"
                                   ],
                   "duplicity":  [
                                     "deceit"
                                 ],
                   "durability":  [
                                      "lastingness"
                                  ],
                   "durable":  [
                                   "long-lasting"
                               ],
                   "durably":  [
                                   "lastingly"
                               ],
                   "duration":  [
                                    "length"
                                ],
                   "durational":  [
                                      "time-related"
                                  ],
                   "dust":  [
                                "powder"
                            ],
                   "duty":  [
                                "responsibility"
                            ],
                   "dwell":  [
                                 "live"
                             ],
                   "dwindle":  [
                                   "decrease"
                               ],
                   "dwindlement":  [
                                       "reduction"
                                   ],
                   "dye":  [
                               "colourant"
                           ],
                   "dynamo":  [
                                  "generator"
                              ],
                   "dynastic":  [
                                    "royal"
                                ],
                   "dynasty":  [
                                   "rulingfamily"
                               ],
                   "eager":  [
                                 "keen"
                             ],
                   "eagerness":  [
                                     "keenness"
                                 ],
                   "earn":  [
                                "gain"
                            ],
                   "earnest":  [
                                   "serious"
                               ],
                   "earnestness":  [
                                       "seriousness"
                                   ],
                   "earnings":  [
                                    "income"
                                ],
                   "earring":  [
                                   "earornament"
                               ],
                   "earthquake":  [
                                      "tremor"
                                  ],
                   "eccentric":  [
                                     "unusual"
                                 ],
                   "eccentricity":  [
                                        "oddness"
                                    ],
                   "echo":  [
                                "repeat"
                            ],
                   "ecological":  [
                                      "environmental"
                                  ],
                   "ecologist":  [
                                     "environmentalscientist"
                                 ],
                   "economic":  [
                                    "financial"
                                ],
                   "economist":  [
                                     "economicexpert"
                                 ],
                   "economy":  [
                                   "financialsystem"
                               ],
                   "ecosystem":  [
                                     "environmentalsystem"
                                 ],
                   "ecosystemic":  [
                                       "system-ecological"
                                   ],
                   "edict":  [
                                 "decree"
                             ],
                   "editing":  [
                                   "revision"
                               ],
                   "editor":  [
                                  "reviser"
                              ],
                   "editorial":  [
                                     "commentary"
                                 ],
                   "educate":  [
                                   "teach"
                               ],
                   "educational":  [
                                       "instructional"
                                   ],
                   "effect":  [
                                  "impact"
                              ],
                   "effective":  [
                                     "efficient"
                                 ],
                   "effectiveness":  [
                                         "efficacy"
                                     ],
                   "efficiency":  [
                                      "productivity"
                                  ],
                   "efficient":  [
                                     "productive"
                                 ],
                   "effluence":  [
                                     "outflow"
                                 ],
                   "effluent":  [
                                    "wastewater"
                                ],
                   "egalitarian":  [
                                       "equalitarian"
                                   ],
                   "egalitarianism":  [
                                          "equalitarianism"
                                      ],
                   "ego":  [
                               "self"
                           ],
                   "eject":  [
                                 "expel"
                             ],
                   "elaborate":  [
                                     "detailed"
                                 ],
                   "elaboration":  [
                                       "explanation"
                                   ],
                   "elastic":  [
                                   "stretchable"
                               ],
                   "elasticity":  [
                                      "stretchability"
                                  ],
                   "elect":  [
                                 "choose"
                             ],
                   "election":  [
                                    "vote"
                                ],
                   "electric":  [
                                    "powered"
                                ],
                   "electricity":  [
                                       "power"
                                   ],
                   "electrocute":  [
                                       "shock"
                                   ],
                   "electrode":  [
                                     "conductor"
                                 ],
                   "electroencephalogram":  [
                                                "brainwaverecord"
                                            ],
                   "electromagnetic":  [
                                           "field-related"
                                       ],
                   "electronic":  [
                                      "digital"
                                  ],
                   "element":  [
                                   "component"
                               ],
                   "elephant":  [
                                    "largemammal"
                                ],
                   "elevate":  [
                                   "raise"
                               ],
                   "elevation":  [
                                     "height"
                                 ],
                   "elevator":  [
                                    "lift"
                                ],
                   "elicit":  [
                                  "drawout"
                              ],
                   "elicitation":  [
                                       "drawingout"
                                   ],
                   "eligibility":  [
                                       "qualification"
                                   ],
                   "eligible":  [
                                    "qualified"
                                ],
                   "eligibly":  [
                                    "qualifiedly"
                                ],
                   "eliminate":  [
                                     "remove"
                                 ],
                   "elimination":  [
                                       "removal"
                                   ],
                   "elite":  [
                                 "privilegedgroup"
                             ],
                   "elitism":  [
                                   "privilege"
                               ],
                   "elk":  [
                               "deer"
                           ],
                   "eloquence":  [
                                     "fluency"
                                 ],
                   "eloquent":  [
                                    "fluent"
                                ],
                   "elucidate":  [
                                     "clarify"
                                 ],
                   "elucidation":  [
                                       "clarification"
                                   ],
                   "elucidative":  [
                                       "clarifying"
                                   ],
                   "elusive":  [
                                   "hard-to-grasp"
                               ],
                   "emancipate":  [
                                      "liberate"
                                  ],
                   "embarrass":  [
                                     "humiliate"
                                 ],
                   "emblematic":  [
                                      "symbolic"
                                  ],
                   "emerge":  [
                                  "appear"
                              ],
                   "emergence":  [
                                     "appearance"
                                 ],
                   "emergency":  [
                                     "crisis"
                                 ],
                   "emergent":  [
                                    "emerging"
                                ],
                   "emigration":  [
                                      "out-migration"
                                  ],
                   "eminent":  [
                                   "distinguished"
                               ],
                   "emission":  [
                                    "discharge"
                                ],
                   "emit":  [
                                "release"
                            ],
                   "emotion":  [
                                   "feeling"
                               ],
                   "emotional":  [
                                     "affective"
                                 ],
                   "empathetic":  [
                                      "compassionate"
                                  ],
                   "empathize":  [
                                     "understandfeelings"
                                 ],
                   "empathy":  [
                                   "compassion"
                               ],
                   "emperor":  [
                                   "ruler"
                               ],
                   "emphasis":  [
                                    "stress"
                                ],
                   "emphasize":  [
                                     "stress"
                                 ],
                   "emphatic":  [
                                    "forceful"
                                ],
                   "empire":  [
                                  "imperialstate"
                              ],
                   "empirical":  [
                                     "evidence-based"
                                 ],
                   "empiricism":  [
                                      "evidence-basedphilosophy"
                                  ],
                   "empiricist":  [
                                      "evidence-basedthinker"
                                  ],
                   "employ":  [
                                  "hire"
                              ],
                   "employer":  [
                                    "boss"
                                ],
                   "employment":  [
                                      "work"
                                  ],
                   "empower":  [
                                   "enable"
                               ],
                   "empowerment":  [
                                       "enablement"
                                   ],
                   "enable":  [
                                  "allow"
                              ],
                   "enabler":  [
                                   "facilitator"
                               ],
                   "encipher":  [
                                    "encrypt"
                                ],
                   "encircle":  [
                                    "surround"
                                ],
                   "enclose":  [
                                   "surround"
                               ],
                   "enclosure":  [
                                     "surroundingbarrier"
                                 ],
                   "encode":  [
                                  "convertintocode"
                              ],
                   "encompass":  [
                                     "include"
                                 ],
                   "encounter":  [
                                     "meet"
                                 ],
                   "encourage":  [
                                     "support"
                                 ],
                   "encouragement":  [
                                         "support"
                                     ],
                   "encrypt":  [
                                   "encode"
                               ],
                   "encryption":  [
                                      "coding"
                                  ],
                   "encumber":  [
                                    "burden"
                                ],
                   "endanger":  [
                                    "threaten"
                                ],
                   "endangerment":  [
                                        "threat"
                                    ],
                   "endemic":  [
                                   "native"
                               ],
                   "endocrine":  [
                                     "hormone-related"
                                 ],
                   "endowment":  [
                                     "fund"
                                 ],
                   "endue":  [
                                 "provide"
                             ],
                   "endurable":  [
                                     "bearable"
                                 ],
                   "endurance":  [
                                     "stamina"
                                 ],
                   "endure":  [
                                  "withstand"
                              ],
                   "energetic":  [
                                     "vigorous"
                                 ],
                   "energy":  [
                                  "power"
                              ],
                   "energyintake":  [
                                        "calorieintake"
                                    ],
                   "enforce":  [
                                   "implement"
                               ],
                   "enforceable":  [
                                       "binding"
                                   ],
                   "enforcement":  [
                                       "implementation"
                                   ],
                   "engage":  [
                                  "involve"
                              ],
                   "engagement":  [
                                      "participation"
                                  ],
                   "engineer":  [
                                    "designer"
                                ],
                   "engross":  [
                                   "absorb"
                               ],
                   "enhance":  [
                                   "improve"
                               ],
                   "enhancement":  [
                                       "improvement"
                                   ],
                   "enlightenment":  [
                                         "awakening"
                                     ],
                   "enormity":  [
                                    "immensity"
                                ],
                   "enormous":  [
                                    "huge"
                                ],
                   "enormousness":  [
                                        "hugeness"
                                    ],
                   "ensemble":  [
                                    "group"
                                ],
                   "ensue":  [
                                 "follow"
                             ],
                   "ensure":  [
                                  "guarantee"
                              ],
                   "ensurement":  [
                                      "guarantee"
                                  ],
                   "entail":  [
                                  "involve"
                              ],
                   "entailment":  [
                                      "implication"
                                  ],
                   "enterprise":  [
                                      "business"
                                  ],
                   "entire":  [
                                  "whole"
                              ],
                   "entireness":  [
                                      "wholeness"
                                  ],
                   "entirety":  [
                                    "whole"
                                ],
                   "entrepreneur":  [
                                        "businessfounder"
                                    ],
                   "entrepreneurship":  [
                                            "businesscreation"
                                        ],
                   "enumerate":  [
                                     "list"
                                 ],
                   "environment":  [
                                       "surroundings"
                                   ],
                   "environmental":  [
                                         "ecological"
                                     ],
                   "environmentalism":  [
                                            "greenpolitics"
                                        ],
                   "enzymatic":  [
                                     "enzyme-related"
                                 ],
                   "enzyme":  [
                                  "biologicalcatalyst"
                              ],
                   "epidemic":  [
                                    "outbreak"
                                ],
                   "epistemic":  [
                                     "knowledge-related"
                                 ],
                   "epistemology":  [
                                        "theoryofknowledge"
                                    ],
                   "equal":  [
                                 "same"
                             ],
                   "equality":  [
                                    "fairness"
                                ],
                   "equate":  [
                                  "identifyasequal"
                              ],
                   "equation":  [
                                    "formula"
                                ],
                   "equator":  [
                                   "middleline"
                               ],
                   "equatorial":  [
                                      "equator-related"
                                  ],
                   "equilibrate":  [
                                       "balance"
                                   ],
                   "equilibrium":  [
                                       "balance"
                                   ],
                   "equitable":  [
                                     "fair"
                                 ],
                   "equitably":  [
                                     "fairly"
                                 ],
                   "equity":  [
                                  "fairness"
                              ],
                   "equivalence":  [
                                       "equality"
                                   ],
                   "equivalent":  [
                                      "equal"
                                  ],
                   "equivocal":  [
                                     "ambiguous"
                                 ],
                   "equivocation":  [
                                        "ambiguity"
                                    ],
                   "eradicable":  [
                                      "eliminable"
                                  ],
                   "eradicate":  [
                                     "eliminate"
                                 ],
                   "eradication":  [
                                       "elimination"
                                   ],
                   "erode":  [
                                 "wearaway"
                             ],
                   "erosion":  [
                                   "wearingaway"
                               ],
                   "erratic":  [
                                   "irregular"
                               ],
                   "erraticism":  [
                                      "irregularity"
                                  ],
                   "erupt":  [
                                 "burst"
                             ],
                   "eruption":  [
                                    "outburst"
                                ],
                   "essence":  [
                                   "core"
                               ],
                   "essential":  [
                                     "necessary"
                                 ],
                   "establish":  [
                                     "found"
                                 ],
                   "establishment":  [
                                         "institution"
                                     ],
                   "estate":  [
                                  "property"
                              ],
                   "esthetician":  [
                                       "beautyspecialist"
                                   ],
                   "estimate":  [
                                    "approximation"
                                ],
                   "estimation":  [
                                      "assessment"
                                  ],
                   "estimator":  [
                                     "assessor"
                                 ],
                   "estuary":  [
                                   "rivermouth"
                               ],
                   "eternal":  [
                                   "everlasting"
                               ],
                   "ethical":  [
                                   "moral"
                               ],
                   "ethics":  [
                                  "morality"
                              ],
                   "ethnic":  [
                                  "cultural-group"
                              ],
                   "ethnocentric":  [
                                        "culture-biased"
                                    ],
                   "ethnocentrism":  [
                                         "culturalbias"
                                     ],
                   "ethnographic":  [
                                        "fieldwork-based"
                                    ],
                   "ethnography":  [
                                       "fieldworkstudy"
                                   ],
                   "etymological":  [
                                        "word-origin"
                                    ],
                   "etymology":  [
                                     "wordorigin"
                                 ],
                   "euphoric":  [
                                    "elated"
                                ],
                   "eutrophic":  [
                                     "nutrient-rich"
                                 ],
                   "eutrophication":  [
                                          "nutrientpollution"
                                      ],
                   "evacuate":  [
                                    "remove"
                                ],
                   "evacuation":  [
                                      "removal"
                                  ],
                   "evade":  [
                                 "avoid"
                             ],
                   "evaluate":  [
                                    "assess"
                                ],
                   "evaluation":  [
                                      "assessment"
                                  ],
                   "evaluator":  [
                                     "assessor"
                                 ],
                   "evaporate":  [
                                     "vaporise"
                                 ],
                   "evaporation":  [
                                       "vaporisation"
                                   ],
                   "event":  [
                                 "occurrence"
                             ],
                   "eventual":  [
                                    "ultimate"
                                ],
                   "eventuality":  [
                                       "possibility"
                                   ],
                   "evidence":  [
                                    "proof"
                                ],
                   "evident":  [
                                   "obvious"
                               ],
                   "evitable":  [
                                    "avoidable"
                                ],
                   "evocation":  [
                                     "suggestion"
                                 ],
                   "evocative":  [
                                     "suggestive"
                                 ],
                   "evoke":  [
                                 "arouse"
                             ],
                   "evolution":  [
                                     "development"
                                 ],
                   "evolutionary":  [
                                        "developmental"
                                    ],
                   "evolve":  [
                                  "develop"
                              ],
                   "exacerbate":  [
                                      "worsen"
                                  ],
                   "exacerbation":  [
                                        "worsening"
                                    ],
                   "exact":  [
                                 "precise"
                             ],
                   "exactness":  [
                                     "precision"
                                 ],
                   "exaggerate":  [
                                      "overstate"
                                  ],
                   "exaggeration":  [
                                        "overstatement"
                                    ],
                   "exam":  [
                                "test"
                            ],
                   "examinable":  [
                                      "examine"
                                  ],
                   "examination":  [
                                       "inspection"
                                   ],
                   "examine":  [
                                   "inspect"
                               ],
                   "examiner":  [
                                    "inspector"
                                ],
                   "example":  [
                                   "case"
                               ],
                   "excavate":  [
                                    "dig"
                                ],
                   "excavation":  [
                                      "digging"
                                  ],
                   "exceed":  [
                                  "surpass"
                              ],
                   "except":  [
                                  "exclude"
                              ],
                   "exception":  [
                                     "exclusion"
                                 ],
                   "exceptional":  [
                                       "extraordinary"
                                   ],
                   "excess":  [
                                  "surplus"
                              ],
                   "excessive":  [
                                     "toomuch"
                                 ],
                   "excessiveness":  [
                                         "overuse"
                                     ],
                   "exchange":  [
                                    "trade"
                                ],
                   "exclude":  [
                                   "leaveout"
                               ],
                   "exclusion":  [
                                     "omission"
                                 ],
                   "exclusive":  [
                                     "restricted"
                                 ],
                   "execute":  [
                                   "carryout"
                               ],
                   "execution":  [
                                     "implementation"
                                 ],
                   "executive":  [
                                     "managerial"
                                 ],
                   "exhale":  [
                                  "breatheout"
                              ],
                   "exhaust":  [
                                   "deplete"
                               ],
                   "exhaustion":  [
                                      "fatigue"
                                  ],
                   "exhaustive":  [
                                      "comprehensive"
                                  ],
                   "exhibit":  [
                                   "display"
                               ],
                   "exhibition":  [
                                      "display"
                                  ],
                   "exhibitor":  [
                                     "presenter"
                                 ],
                   "exoplanet":  [
                                     "extrasolarplanet"
                                 ],
                   "expand":  [
                                  "enlarge"
                              ],
                   "expanse":  [
                                   "widearea"
                               ],
                   "expansion":  [
                                     "growth"
                                 ],
                   "expansive":  [
                                     "broad"
                                 ],
                   "expedite":  [
                                    "speedup"
                                ],
                   "expedition":  [
                                      "journey"
                                  ],
                   "expeditious":  [
                                       "swift"
                                   ],
                   "expel":  [
                                 "eject"
                             ],
                   "expendable":  [
                                      "dispensable"
                                  ],
                   "expenditure":  [
                                       "spending"
                                   ],
                   "expensive":  [
                                     "costly"
                                 ],
                   "experimental":  [
                                        "trial"
                                    ],
                   "experimentalist":  [
                                           "experimenter"
                                       ],
                   "experimentation":  [
                                           "testing"
                                       ],
                   "explicit":  [
                                    "clear"
                                ],
                   "explicitness":  [
                                        "clarity"
                                    ],
                   "exploit":  [
                                   "use"
                               ],
                   "exploitation":  [
                                        "abuse"
                                    ],
                   "exploitative":  [
                                        "abusive"
                                    ],
                   "explosion":  [
                                     "blast"
                                 ],
                   "explosive":  [
                                     "volatile"
                                 ],
                   "exponential":  [
                                       "rapidlyincreasing"
                                   ],
                   "expose":  [
                                  "reveal"
                              ],
                   "exposure":  [
                                    "visibility"
                                ],
                   "express":  [
                                   "convey"
                               ],
                   "expression":  [
                                      "statement"
                                  ],
                   "expressionism":  [
                                         "emotionalstyle"
                                     ],
                   "expressive":  [
                                      "communicative"
                                  ],
                   "extend":  [
                                  "expand"
                              ],
                   "extendable":  [
                                      "expandable"
                                  ],
                   "extension":  [
                                     "expansion"
                                 ],
                   "extensive":  [
                                     "wide-ranging"
                                 ],
                   "extent":  [
                                  "degree"
                              ],
                   "exterior":  [
                                    "outside"
                                ],
                   "exterminate":  [
                                       "eradicate"
                                   ],
                   "external":  [
                                    "outside"
                                ],
                   "externality":  [
                                       "sideeffect"
                                   ],
                   "externalize":  [
                                       "projectoutward"
                                   ],
                   "extinct":  [
                                   "dead"
                               ],
                   "extinction":  [
                                      "disappearance"
                                  ],
                   "extinguish":  [
                                      "putout"
                                  ],
                   "extract":  [
                                   "remove"
                               ],
                   "extraction":  [
                                      "removal"
                                  ],
                   "extraordinariness":  [
                                             "exceptionality"
                                         ],
                   "extraordinary":  [
                                         "exceptional"
                                     ],
                   "extremism":  [
                                     "radicalism"
                                 ],
                   "extremity":  [
                                     "endpoint"
                                 ],
                   "extrinsic":  [
                                     "external"
                                 ],
                   "extrovert":  [
                                     "outgoingperson"
                                 ],
                   "fabric":  [
                                  "textile"
                              ],
                   "fabricate":  [
                                     "invent"
                                 ],
                   "fabrication":  [
                                       "invention"
                                   ],
                   "fabricator":  [
                                      "maker"
                                  ],
                   "facade":  [
                                  "front"
                              ],
                   "facile":  [
                                  "simplistic"
                              ],
                   "facilitate":  [
                                      "enable"
                                  ],
                   "facilitation":  [
                                        "enablement"
                                    ],
                   "facilitator":  [
                                       "enabler"
                                   ],
                   "facility":  [
                                    "amenity"
                                ],
                   "facsimile":  [
                                     "copy"
                                 ],
                   "fact":  [
                                "truth"
                            ],
                   "factory":  [
                                   "plant"
                               ],
                   "factual":  [
                                   "true"
                               ],
                   "factuality":  [
                                      "truthfulness"
                                  ],
                   "fade":  [
                                "disappear"
                            ],
                   "faint":  [
                                 "weak"
                             ],
                   "fair":  [
                                "just"
                            ],
                   "fairness":  [
                                    "justice"
                                ],
                   "fallacious":  [
                                      "false"
                                  ],
                   "fallacy":  [
                                   "mistake"
                               ],
                   "falter":  [
                                  "hesitate"
                              ],
                   "falteringly":  [
                                       "hesitantly"
                                   ],
                   "famine":  [
                                  "starvation"
                              ],
                   "farm":  [
                                "cultivate"
                            ],
                   "fashion":  [
                                   "style"
                               ],
                   "fashionable":  [
                                       "stylish"
                                   ],
                   "fashionably":  [
                                       "stylishly"
                                   ],
                   "fatigue":  [
                                   "tiredness"
                               ],
                   "fault":  [
                                 "flaw"
                             ],
                   "faultline":  [
                                     "fractureline"
                                 ],
                   "fauna":  [
                                 "animals"
                             ],
                   "favourable":  [
                                      "beneficial"
                                  ],
                   "feasibility":  [
                                       "practicality"
                                   ],
                   "feasible":  [
                                    "practical"
                                ],
                   "feasibly":  [
                                    "practically"
                                ],
                   "federal":  [
                                   "national"
                               ],
                   "federate":  [
                                    "unite"
                                ],
                   "feedback":  [
                                    "response"
                                ],
                   "fence":  [
                                 "barrier"
                             ],
                   "ferment":  [
                                   "change"
                               ],
                   "fermentation":  [
                                        "biochemicalchange"
                                    ],
                   "ferry":  [
                                 "boat"
                             ],
                   "fertile":  [
                                   "productive"
                               ],
                   "fertilise":  [
                                     "enrich"
                                 ],
                   "fertility":  [
                                     "productiveness"
                                 ],
                   "fertilization":  [
                                         "enrichment"
                                     ],
                   "fertilizer":  [
                                      "nutrient"
                                  ],
                   "feudal":  [
                                  "medieval"
                              ],
                   "feudalism":  [
                                     "medievalsystem"
                                 ],
                   "fibre":  [
                                 "strand"
                             ],
                   "fiction":  [
                                   "story"
                               ],
                   "fictional":  [
                                     "imaginary"
                                 ],
                   "fictitious":  [
                                      "false"
                                  ],
                   "fictive":  [
                                   "imagined"
                               ],
                   "fidelity":  [
                                    "accuracy"
                                ],
                   "filament":  [
                                    "thread"
                                ],
                   "fill":  [
                                "occupy"
                            ],
                   "filter":  [
                                  "screen"
                              ],
                   "final":  [
                                 "last"
                             ],
                   "finalization":  [
                                        "completion"
                                    ],
                   "finalize":  [
                                    "complete"
                                ],
                   "finance":  [
                                   "fund"
                               ],
                   "financial":  [
                                     "finance",
                                     "economic"
                                 ],
                   "finch":  [
                                 "smallbird"
                             ],
                   "fine":  [
                                "delicate"
                            ],
                   "finger":  [
                                  "digit"
                              ],
                   "fire":  [
                                "flame"
                            ],
                   "firearm":  [
                                   "gun"
                               ],
                   "firm":  [
                                "company"
                            ],
                   "fiscalpolicy":  [
                                        "budgetpolicy"
                                    ],
                   "fish":  [
                                "aquaticanimal"
                            ],
                   "fishfarming":  [
                                       "aquaculture"
                                   ],
                   "fission":  [
                                   "splitting"
                               ],
                   "fissure":  [
                                   "crack"
                               ],
                   "fjord":  [
                                 "seainlet"
                             ],
                   "flagellant":  [
                                      "self-punisher"
                                  ],
                   "flamenco":  [
                                    "dancemusic"
                                ],
                   "flavouring":  [
                                      "seasoning"
                                  ],
                   "flaw":  [
                                "defect"
                            ],
                   "flawedness":  [
                                      "defectiveness"
                                  ],
                   "flawless":  [
                                    "perfect"
                                ],
                   "flee":  [
                                "escape"
                            ],
                   "fleet":  [
                                 "navy"
                             ],
                   "flex":  [
                                "bend"
                            ],
                   "flexibility":  [
                                       "adaptability"
                                   ],
                   "flexible":  [
                                    "adaptable"
                                ],
                   "flexibly":  [
                                    "adaptably"
                                ],
                   "flicker":  [
                                   "flash"
                               ],
                   "flight":  [
                                  "journey"
                              ],
                   "flightless":  [
                                      "nonflying"
                                  ],
                   "floe":  [
                                "icesheet"
                            ],
                   "flooding":  [
                                    "inundation"
                                ],
                   "flora":  [
                                 "plants"
                             ],
                   "flourish":  [
                                    "thrive"
                                ],
                   "flourishment":  [
                                        "prosperity"
                                    ],
                   "flow":  [
                                "movement"
                            ],
                   "fluctuate":  [
                                     "vary"
                                 ],
                   "fluctuation":  [
                                       "variation"
                                   ],
                   "fluent":  [
                                  "smooth"
                              ],
                   "fluid":  [
                                 "liquid"
                             ],
                   "fluidity":  [
                                    "flexibility"
                                ],
                   "focus":  [
                                 "concentration"
                             ],
                   "foliage":  [
                                   "leaves"
                               ],
                   "folklore":  [
                                    "tradition"
                                ],
                   "folkloric":  [
                                     "traditional"
                                 ],
                   "following":  [
                                     "subsequent"
                                 ],
                   "footage":  [
                                   "video"
                               ],
                   "football":  [
                                    "soccer"
                                ],
                   "force":  [
                                 "power"
                             ],
                   "forecast":  [
                                    "prediction"
                                ],
                   "forefront":  [
                                     "frontline"
                                 ],
                   "foresee":  [
                                   "predict"
                               ],
                   "foreseeable":  [
                                       "predictable"
                                   ],
                   "foresight":  [
                                     "anticipation"
                                 ],
                   "forest":  [
                                  "woodland"
                              ],
                   "forgive":  [
                                   "pardon"
                               ],
                   "form":  [
                                "shape"
                            ],
                   "formal":  [
                                  "official"
                              ],
                   "formidability":  [
                                         "impressiveness"
                                     ],
                   "formidable":  [
                                      "daunting"
                                  ],
                   "formidably":  [
                                      "dauntingly"
                                  ],
                   "formula":  [
                                   "equation"
                               ],
                   "formulate":  [
                                     "devise"
                                 ],
                   "formulation":  [
                                       "wording"
                                   ],
                   "forthcoming":  [
                                       "upcoming"
                                   ],
                   "fossil":  [
                                  "remnant"
                              ],
                   "fossilise":  [
                                     "preserveasfossil"
                                 ],
                   "fossilization":  [
                                         "fossilpreservation"
                                     ],
                   "fossilize":  [
                                     "preserveasfossil"
                                 ],
                   "found":  [
                                 "establish"
                             ],
                   "foundation":  [
                                      "basis"
                                  ],
                   "foundational":  [
                                        "basic"
                                    ],
                   "founder":  [
                                   "originator"
                               ],
                   "fraction":  [
                                    "portion"
                                ],
                   "fracture":  [
                                    "break"
                                ],
                   "fragile":  [
                                   "delicate"
                               ],
                   "fragility":  [
                                     "weakness"
                                 ],
                   "fragment":  [
                                    "piece"
                                ],
                   "frame":  [
                                 "structure"
                             ],
                   "framework":  [
                                     "structure"
                                 ],
                   "franchise":  [
                                     "license"
                                 ],
                   "franchisee":  [
                                      "licensee"
                                  ],
                   "fraud":  [
                                 "deception"
                             ],
                   "fraudster":  [
                                     "swindler"
                                 ],
                   "fraudulent":  [
                                      "deceptive"
                                  ],
                   "free":  [
                                "liberate"
                            ],
                   "freedom":  [
                                   "liberty"
                               ],
                   "freelance":  [
                                     "independent"
                                 ],
                   "freeze":  [
                                  "solidify"
                              ],
                   "freight":  [
                                   "cargo"
                               ],
                   "frequency":  [
                                     "rate"
                                 ],
                   "frequent":  [
                                    "regular"
                                ],
                   "freshwater":  [
                                      "non-saltwater"
                                  ],
                   "friction":  [
                                    "resistance"
                                ],
                   "frictional":  [
                                      "resistance-related"
                                  ],
                   "frontier":  [
                                    "borderland"
                                ],
                   "frustrate":  [
                                     "discourage"
                                 ],
                   "frustration":  [
                                       "annoyance"
                                   ],
                   "fulfill":  [
                                   "satisfy"
                               ],
                   "fulfillment":  [
                                       "satisfaction"
                                   ],
                   "function":  [
                                    "operate"
                                ],
                   "functional":  [
                                      "practical"
                                  ],
                   "fund":  [
                                "finance"
                            ],
                   "fundament":  [
                                     "basis"
                                 ],
                   "fundamental":  [
                                       "basic"
                                   ],
                   "fundamentalism":  [
                                          "literalism"
                                      ],
                   "funeral":  [
                                   "burial"
                               ],
                   "fungal":  [
                                  "fungus-related"
                              ],
                   "fuse":  [
                                "merge"
                            ],
                   "galactic":  [
                                    "galaxy-related"
                                ],
                   "galaxy":  [
                                  "starsystem"
                              ],
                   "gale":  [
                                "storm"
                            ],
                   "galleon":  [
                                   "largesailingship"
                               ],
                   "gallery":  [
                                   "exhibitionspace"
                               ],
                   "garden":  [
                                  "cultivatedspace"
                              ],
                   "gas":  [
                               "vapour"
                           ],
                   "gauge":  [
                                 "measure"
                             ],
                   "gemstone":  [
                                    "jewel"
                                ],
                   "gender":  [
                                  "sexcategory"
                              ],
                   "genderless":  [
                                      "ungendered"
                                  ],
                   "general":  [
                                   "broad"
                               ],
                   "generalization":  [
                                          "broadconclusion"
                                      ],
                   "generalize":  [
                                      "broaden"
                                  ],
                   "generate":  [
                                    "produce"
                                ],
                   "generation":  [
                                      "cohort"
                                  ],
                   "generational":  [
                                        "age-group"
                                    ],
                   "generator":  [
                                     "producer"
                                 ],
                   "generic":  [
                                   "general"
                               ],
                   "generous":  [
                                    "liberal"
                                ],
                   "genesis":  [
                                   "origin"
                               ],
                   "genetic":  [
                                   "hereditary"
                               ],
                   "genius":  [
                                  "brilliance"
                              ],
                   "geniusloci":  [
                                      "genie"
                                  ],
                   "genocide":  [
                                    "masskilling"
                                ],
                   "genome":  [
                                  "geneticcode"
                              ],
                   "genomic":  [
                                   "genome-related"
                               ],
                   "genre":  [
                                 "type"
                             ],
                   "gentle":  [
                                  "mild"
                              ],
                   "gentrification":  [
                                          "urbanupgrading"
                                      ],
                   "gentrify":  [
                                    "upgradeurbanareas"
                                ],
                   "gentry":  [
                                  "landedelite"
                              ],
                   "genuine":  [
                                   "authentic"
                               ],
                   "genuineness":  [
                                       "authenticity"
                                   ],
                   "geographical":  [
                                        "spatial"
                                    ],
                   "geography":  [
                                     "earthstudy"
                                 ],
                   "geological":  [
                                      "earth-related"
                                  ],
                   "geomancy":  [
                                    "earthdivination"
                                ],
                   "geometry":  [
                                    "shapemathematics"
                                ],
                   "geothermal":  [
                                      "earth-heat"
                                  ],
                   "gesture":  [
                                   "signal"
                               ],
                   "geyser":  [
                                  "hotspring"
                              ],
                   "giant":  [
                                 "huge"
                             ],
                   "giraffe":  [
                                   "long-neckedanimal"
                               ],
                   "glacial":  [
                                   "ice-related"
                               ],
                   "glaciation":  [
                                      "icecoverage"
                                  ],
                   "glacier":  [
                                   "icemass"
                               ],
                   "glass":  [
                                 "transparentmaterial"
                             ],
                   "glider":  [
                                  "sailplane"
                              ],
                   "global":  [
                                  "worldwide"
                              ],
                   "globalisation":  [
                                         "worldintegration"
                                     ],
                   "globalization":  [
                                         "worldintegration"
                                     ],
                   "globalize":  [
                                     "internationalise"
                                 ],
                   "glucose":  [
                                   "sugar"
                               ],
                   "glyph":  [
                                 "symbol"
                             ],
                   "golden":  [
                                  "valuable"
                              ],
                   "gorilla":  [
                                   "ape"
                               ],
                   "gospel":  [
                                  "doctrine"
                              ],
                   "govern":  [
                                  "rule"
                              ],
                   "governance":  [
                                      "management"
                                  ],
                   "government":  [
                                      "state"
                                  ],
                   "gradation":  [
                                     "scale"
                                 ],
                   "grade":  [
                                 "level"
                             ],
                   "gradient":  [
                                    "slope"
                                ],
                   "gradual":  [
                                   "slow"
                               ],
                   "gradualness":  [
                                       "slowness"
                                   ],
                   "graduate":  [
                                    "completestudy"
                                ],
                   "graduation":  [
                                      "completion"
                                  ],
                   "graffiti":  [
                                    "wallwriting"
                                ],
                   "grammar":  [
                                   "syntax"
                               ],
                   "grant":  [
                                 "give"
                             ],
                   "graph":  [
                                 "chart"
                             ],
                   "grasp":  [
                                 "understand"
                             ],
                   "grassland":  [
                                     "prairie"
                                 ],
                   "grave":  [
                                 "serious"
                             ],
                   "gravel":  [
                                  "smallstones"
                              ],
                   "graveness":  [
                                     "seriousness"
                                 ],
                   "gravitational":  [
                                         "gravity-related"
                                     ],
                   "gravity":  [
                                   "pull"
                               ],
                   "great":  [
                                 "large"
                             ],
                   "greenhouse":  [
                                      "glasshouse"
                                  ],
                   "gregarious":  [
                                      "sociable"
                                  ],
                   "grey":  [
                                "gray"
                            ],
                   "grievance":  [
                                     "complaint"
                                 ],
                   "grip":  [
                                "hold"
                            ],
                   "gross":  [
                                 "total"
                             ],
                   "grossness":  [
                                     "crudeness"
                                 ],
                   "ground":  [
                                  "basis"
                              ],
                   "group":  [
                                 "category"
                             ],
                   "guarantee":  [
                                     "assurance"
                                 ],
                   "guarantor":  [
                                     "surety"
                                 ],
                   "guard":  [
                                 "protect"
                             ],
                   "guardian":  [
                                    "protector"
                                ],
                   "guillotine":  [
                                      "executiondevice"
                                  ],
                   "gun":  [
                               "firearm"
                           ],
                   "gunpowder":  [
                                     "explosivepowder"
                                 ],
                   "habit":  [
                                 "routine"
                             ],
                   "habitable":  [
                                     "livable"
                                 ],
                   "habitat":  [
                                   "environment"
                               ],
                   "habitation":  [
                                      "dwelling"
                                  ],
                   "haemoglobin":  [
                                       "bloodprotein"
                                   ],
                   "hailstorm":  [
                                     "icestorm"
                                 ],
                   "halt":  [
                                "stop"
                            ],
                   "hamper":  [
                                  "hinder"
                              ],
                   "haphazard":  [
                                     "random"
                                 ],
                   "haphazardness":  [
                                         "randomness"
                                     ],
                   "happen":  [
                                  "occur"
                              ],
                   "happenstance":  [
                                        "chance"
                                    ],
                   "harassment":  [
                                      "bullying"
                                  ],
                   "harem":  [
                                 "womensquarters"
                             ],
                   "harm":  [
                                "damage"
                            ],
                   "harmful":  [
                                   "damaging"
                               ],
                   "harmless":  [
                                    "safe"
                                ],
                   "harmonic":  [
                                    "musical"
                                ],
                   "harmonious":  [
                                      "balanced"
                                  ],
                   "harmonize":  [
                                     "coordinate"
                                 ],
                   "harmony":  [
                                   "agreement"
                               ],
                   "harness":  [
                                   "use"
                               ],
                   "harpoon":  [
                                   "spear"
                               ],
                   "harvest":  [
                                   "cropyield"
                               ],
                   "hazard":  [
                                  "risk"
                              ],
                   "hazardous":  [
                                     "dangerous"
                                 ],
                   "hazardousness":  [
                                         "dangerousness"
                                     ],
                   "hazardouswaste":  [
                                          "dangerouswaste"
                                      ],
                   "healer":  [
                                  "curer"
                              ],
                   "health":  [
                                  "well-being"
                              ],
                   "healthcare":  [
                                      "medicalcare"
                                  ],
                   "healthy":  [
                                   "well"
                               ],
                   "heat":  [
                                "warmth"
                            ],
                   "heattransfer":  [
                                        "thermalmovement"
                                    ],
                   "heir":  [
                                "successor"
                            ],
                   "helicopter":  [
                                      "rotorcraft"
                                  ],
                   "helium":  [
                                  "lightgas"
                              ],
                   "helix":  [
                                 "spiral"
                             ],
                   "hemisphere":  [
                                      "half-sphere"
                                  ],
                   "hemispheric":  [
                                       "half-sphere-related"
                                   ],
                   "herb":  [
                                "plant"
                            ],
                   "herbicide":  [
                                     "weedkiller"
                                 ],
                   "herbivore":  [
                                     "plant-eater"
                                 ],
                   "hereditary":  [
                                      "inherited"
                                  ],
                   "heredity":  [
                                    "inheritance"
                                ],
                   "heresy":  [
                                  "dissent"
                              ],
                   "heretical":  [
                                     "dissenting"
                                 ],
                   "heritage":  [
                                    "legacy"
                                ],
                   "hesitate":  [
                                    "pause"
                                ],
                   "heuristic":  [
                                     "rule-of-thumb"
                                 ],
                   "hibernate":  [
                                     "sleepthroughwinter"
                                 ],
                   "hibernation":  [
                                       "wintersleep"
                                   ],
                   "hidden":  [
                                  "concealed"
                              ],
                   "hiddenness":  [
                                      "concealment"
                                  ],
                   "hide":  [
                                "conceal"
                            ],
                   "hideous":  [
                                   "ugly"
                               ],
                   "hideout":  [
                                   "shelter"
                               ],
                   "hierarchical":  [
                                        "ranked"
                                    ],
                   "hierarchy":  [
                                     "ranking"
                                 ],
                   "hieroglyph":  [
                                      "sacredsymbol"
                                  ],
                   "high":  [
                                "elevated"
                            ],
                   "highlight":  [
                                     "emphasize"
                                 ],
                   "highlighter":  [
                                       "marker"
                                   ],
                   "hinder":  [
                                  "impede"
                              ],
                   "hindrance":  [
                                     "obstacle"
                                 ],
                   "hindsight":  [
                                     "retrospect"
                                 ],
                   "hippocampal":  [
                                       "memory-related"
                                   ],
                   "hippocampus":  [
                                       "memorycenter"
                                   ],
                   "hippopotamus":  [
                                        "riverhorse"
                                    ],
                   "historian":  [
                                     "historyscholar"
                                 ],
                   "history":  [
                                   "pastrecord"
                               ],
                   "hoax":  [
                                "trick"
                            ],
                   "hole":  [
                                "opening"
                            ],
                   "home":  [
                                "dwelling"
                            ],
                   "homeland":  [
                                    "nativeland"
                                ],
                   "homeless":  [
                                    "unhoused"
                                ],
                   "homelessness":  [
                                        "unhousing"
                                    ],
                   "homeostasis":  [
                                       "internalbalance"
                                   ],
                   "homeostatic":  [
                                       "balance-maintaining"
                                   ],
                   "hominid":  [
                                   "humanancestor"
                               ],
                   "homosexuality":  [
                                         "same-sexorientation"
                                     ],
                   "honeybee":  [
                                    "bee"
                                ],
                   "honourable":  [
                                      "respectable"
                                  ],
                   "horizon":  [
                                   "skyline"
                               ],
                   "horizontal":  [
                                      "level"
                                  ],
                   "hormonal":  [
                                    "hormone-related"
                                ],
                   "hormone":  [
                                   "chemicalmessenger"
                               ],
                   "horn":  [
                                "projection"
                            ],
                   "hospitality":  [
                                       "welcome"
                                   ],
                   "host":  [
                                "organiser"
                            ],
                   "hostage":  [
                                   "captive"
                               ],
                   "hostile":  [
                                   "unfriendly"
                               ],
                   "hostility":  [
                                     "antagonism"
                                 ],
                   "housing":  [
                                   "accommodation"
                               ],
                   "huddle":  [
                                  "cluster"
                              ],
                   "huge":  [
                                "enormous"
                            ],
                   "hugeness":  [
                                    "enormity"
                                ],
                   "humanism":  [
                                    "human-centeredthought"
                                ],
                   "humanitarian":  [
                                        "welfare-oriented"
                                    ],
                   "humanorigin":  [
                                       "anthropogenesis"
                                   ],
                   "humid":  [
                                 "damp"
                             ],
                   "humidify":  [
                                    "moisten"
                                ],
                   "humidity":  [
                                    "moisture"
                                ],
                   "humiliation":  [
                                       "shame"
                                   ],
                   "humpback":  [
                                    "whale"
                                ],
                   "hurricane":  [
                                     "tropicalstorm"
                                 ],
                   "hurricanic":  [
                                      "storm-related"
                                  ],
                   "hurry":  [
                                 "rush"
                             ],
                   "hybrid":  [
                                  "crossbreed"
                              ],
                   "hybridize":  [
                                     "crossbreed"
                                 ],
                   "hydraulic":  [
                                     "water-powered"
                                 ],
                   "hydro":  [
                                 "water"
                             ],
                   "hydroelectric":  [
                                         "water-powered"
                                     ],
                   "hydrogen":  [
                                    "lightelement"
                                ],
                   "hydroponic":  [
                                      "water-grown"
                                  ],
                   "hydropower":  [
                                      "waterpower"
                                  ],
                   "hydrothermal":  [
                                        "hot-water"
                                    ],
                   "hyperinflation":  [
                                          "extremeinflation"
                                      ],
                   "hypothesis":  [
                                      "assumption"
                                  ],
                   "hypothesise":  [
                                       "suppose"
                                   ],
                   "hypothesize":  [
                                       "suppose"
                                   ],
                   "hypothetical":  [
                                        "imagined"
                                    ],
                   "identical":  [
                                     "same"
                                 ],
                   "identification":  [
                                          "recognition"
                                      ],
                   "identify":  [
                                    "recognise"
                                ],
                   "identity":  [
                                    "selfhood"
                                ],
                   "ideological":  [
                                       "belief-based"
                                   ],
                   "ideology":  [
                                    "beliefsystem"
                                ],
                   "idle":  [
                                "inactive"
                            ],
                   "idleness":  [
                                    "inactivity"
                                ],
                   "idly":  [
                                "inactively"
                            ],
                   "idol":  [
                                "icon"
                            ],
                   "idyll":  [
                                 "peacefulscene"
                             ],
                   "igloo":  [
                                 "snowhouse"
                             ],
                   "ignitable":  [
                                     "flammable"
                                 ],
                   "ignite":  [
                                  "kindle"
                              ],
                   "ignition":  [
                                    "kindling"
                                ],
                   "ignorance":  [
                                     "unawareness"
                                 ],
                   "ignorant":  [
                                    "uninformed"
                                ],
                   "ignore":  [
                                  "disregard"
                              ],
                   "illegible":  [
                                     "unreadable"
                                 ],
                   "illicit":  [
                                   "illegal"
                               ],
                   "illiteracy":  [
                                      "inabilitytoread"
                                  ],
                   "illogical":  [
                                     "irrational"
                                 ],
                   "illuminate":  [
                                      "clarify"
                                  ],
                   "illumination":  [
                                        "lighting"
                                    ],
                   "illusion":  [
                                    "falseimpression"
                                ],
                   "illustrate":  [
                                      "demonstrate"
                                  ],
                   "illustration":  [
                                        "example"
                                    ],
                   "illustrative":  [
                                        "explanatory"
                                    ],
                   "image":  [
                                 "picture"
                             ],
                   "imaginary":  [
                                     "fictional"
                                 ],
                   "imagination":  [
                                       "creativity"
                                   ],
                   "imaginative":  [
                                       "creative"
                                   ],
                   "imagine":  [
                                   "envision"
                               ],
                   "imitate":  [
                                   "mimic"
                               ],
                   "imitation":  [
                                     "mimicry"
                                 ],
                   "immaterial":  [
                                      "irrelevant"
                                  ],
                   "immediate":  [
                                     "instant"
                                 ],
                   "immense":  [
                                   "huge"
                               ],
                   "immensity":  [
                                     "vastness"
                                 ],
                   "immersion":  [
                                     "absorption"
                                 ],
                   "immersive":  [
                                     "absorbing"
                                 ],
                   "imminence":  [
                                     "nearness"
                                 ],
                   "imminent":  [
                                    "impending"
                                ],
                   "immoral":  [
                                   "unethical"
                               ],
                   "immortal":  [
                                    "deathless"
                                ],
                   "immortality":  [
                                       "deathlessness"
                                   ],
                   "immune":  [
                                  "resistant"
                              ],
                   "immunity":  [
                                    "resistance"
                                ],
                   "immunodeficiency":  [
                                            "immuneweakness"
                                        ],
                   "impact":  [
                                  "effect"
                              ],
                   "impactful":  [
                                     "influential"
                                 ],
                   "impartial":  [
                                     "neutral"
                                 ],
                   "impartiality":  [
                                        "neutrality"
                                    ],
                   "impede":  [
                                  "hinder"
                              ],
                   "impediment":  [
                                      "obstacle"
                                  ],
                   "impel":  [
                                 "drive"
                             ],
                   "impend":  [
                                  "loom"
                              ],
                   "impendingly":  [
                                       "ominously"
                                   ],
                   "imperative":  [
                                      "essential"
                                  ],
                   "imperial":  [
                                    "empire-related"
                                ],
                   "imperious":  [
                                     "domineering"
                                 ],
                   "impermeable":  [
                                       "impenetrable"
                                   ],
                   "impersonate":  [
                                       "imitate"
                                   ],
                   "implausible":  [
                                       "unlikely"
                                   ],
                   "implement":  [
                                     "carryout"
                                 ],
                   "implementation":  [
                                          "execution"
                                      ],
                   "implicate":  [
                                     "involve"
                                 ],
                   "implication":  [
                                       "suggestion"
                                   ],
                   "implicit":  [
                                    "unstated"
                                ],
                   "implicitness":  [
                                        "indirectness"
                                    ],
                   "imply":  [
                                 "suggest"
                             ],
                   "impose":  [
                                  "force"
                              ],
                   "imposition":  [
                                      "impose",
                                      "enforcement"
                                  ],
                   "impossible":  [
                                      "unachievable"
                                  ],
                   "impoverish":  [
                                      "makepoor"
                                  ],
                   "imprecise":  [
                                     "inexact"
                                 ],
                   "impression":  [
                                      "effect"
                                  ],
                   "impressive":  [
                                      "striking"
                                  ],
                   "imprison":  [
                                    "jailed"
                                ],
                   "imprisonment":  [
                                        "jailing"
                                    ],
                   "improbable":  [
                                      "unlikely"
                                  ],
                   "improve":  [
                                   "enhance"
                               ],
                   "improvement":  [
                                       "enhancement"
                                   ],
                   "imprudent":  [
                                     "unwise"
                                 ],
                   "impulse":  [
                                   "urge"
                               ],
                   "inaccessible":  [
                                        "unreachable"
                                    ],
                   "inactive":  [
                                    "dormant"
                                ],
                   "inactivity":  [
                                      "dormancy"
                                  ],
                   "inappropriate":  [
                                         "unsuitable"
                                     ],
                   "inapt":  [
                                 "unsuitable"
                             ],
                   "incandescent":  [
                                        "glowing"
                                    ],
                   "incarnation":  [
                                       "embodiment"
                                   ],
                   "incentive":  [
                                     "motivation"
                                 ],
                   "incentivize":  [
                                       "motivate"
                                   ],
                   "incidence":  [
                                     "occurrence"
                                 ],
                   "incident":  [
                                    "event"
                                ],
                   "incinerate":  [
                                      "burn"
                                  ],
                   "incineration":  [
                                        "burning"
                                    ],
                   "incision":  [
                                    "cut"
                                ],
                   "incite":  [
                                  "provoke"
                              ],
                   "inclination":  [
                                       "tendency"
                                   ],
                   "incline":  [
                                   "slope"
                               ],
                   "inclinedly":  [
                                      "disposed"
                                  ],
                   "include":  [
                                   "contain"
                               ],
                   "inclusion":  [
                                     "incorporation"
                                 ],
                   "inclusive":  [
                                     "comprehensive"
                                 ],
                   "incognito":  [
                                     "disguised"
                                 ],
                   "income":  [
                                  "earnings"
                              ],
                   "incomparable":  [
                                        "unequalled"
                                    ],
                   "incompatible":  [
                                        "conflicting"
                                    ],
                   "incompatibly":  [
                                        "conflictingly"
                                    ],
                   "incomprehensible":  [
                                            "unintelligible"
                                        ],
                   "inconceivable":  [
                                         "unimaginable"
                                     ],
                   "inconclusive":  [
                                        "uncertain"
                                    ],
                   "inconclusiveness":  [
                                            "uncertainty"
                                        ],
                   "incongruent":  [
                                       "inconsistent"
                                   ],
                   "inconsistency":  [
                                         "contradiction"
                                     ],
                   "inconsistent":  [
                                        "contradictory"
                                    ],
                   "inconspicuous":  [
                                         "unnoticeable"
                                     ],
                   "increase":  [
                                    "rise"
                                ],
                   "increasing":  [
                                      "increase"
                                  ],
                   "incredible":  [
                                      "unbelievable"
                                  ],
                   "incremental":  [
                                       "gradual"
                                   ],
                   "incrementalism":  [
                                          "gradualism"
                                      ],
                   "incubate":  [
                                    "hatch"
                                ],
                   "incurable":  [
                                     "untreatable"
                                 ],
                   "independence":  [
                                        "autonomy"
                                    ],
                   "independent":  [
                                       "autonomous"
                                   ],
                   "indicate":  [
                                    "show"
                                ],
                   "indication":  [
                                      "sign"
                                  ],
                   "indicator":  [
                                     "measure"
                                 ],
                   "indifference":  [
                                        "apathy"
                                    ],
                   "indifferent":  [
                                       "apathetic"
                                   ],
                   "indigene":  [
                                    "nativeperson"
                                ],
                   "indigeneity":  [
                                       "nativeness"
                                   ],
                   "indigenization":  [
                                          "localisation"
                                      ],
                   "indigenize":  [
                                      "localise"
                                  ],
                   "indigenous":  [
                                      "native"
                                  ],
                   "indignation":  [
                                       "outrage"
                                   ],
                   "indispensability":  [
                                            "necessity"
                                        ],
                   "indispensable":  [
                                         "essential"
                                     ],
                   "indispensably":  [
                                         "essentially"
                                     ],
                   "individual":  [
                                      "person"
                                  ],
                   "individualism":  [
                                         "self-reliance"
                                     ],
                   "individualist":  [
                                         "self-reliantperson"
                                     ],
                   "induce":  [
                                  "cause"
                              ],
                   "inducement":  [
                                      "incentive"
                                  ],
                   "indulgence":  [
                                      "self-gratification"
                                  ],
                   "industrial":  [
                                      "manufacturing"
                                  ],
                   "industry":  [
                                    "sector"
                                ],
                   "inefficient":  [
                                       "wasteful"
                                   ],
                   "ineligible":  [
                                      "unqualified"
                                  ],
                   "ineloquent":  [
                                      "inarticulate"
                                  ],
                   "inequality":  [
                                      "disparity"
                                  ],
                   "inequitable":  [
                                       "unfair"
                                   ],
                   "inertia":  [
                                   "resistance"
                               ],
                   "inertial":  [
                                    "motion-resistant"
                                ],
                   "inessential":  [
                                       "unnecessary"
                                   ],
                   "inevitability":  [
                                         "unavoidability"
                                     ],
                   "inevitable":  [
                                      "unavoidable"
                                  ],
                   "inevitably":  [
                                      "unavoidably"
                                  ],
                   "inexact":  [
                                   "imprecise"
                               ],
                   "infancy":  [
                                   "earlychildhood"
                               ],
                   "infect":  [
                                  "contaminate"
                              ],
                   "infection":  [
                                     "contagion"
                                 ],
                   "infectious":  [
                                      "contagious"
                                  ],
                   "infer":  [
                                 "deduce"
                             ],
                   "inference":  [
                                     "deduction"
                                 ],
                   "inferential":  [
                                       "deductive"
                                   ],
                   "inferior":  [
                                    "lower"
                                ],
                   "inferiority":  [
                                       "lowerness"
                                   ],
                   "infinite":  [
                                    "endless"
                                ],
                   "infirm":  [
                                  "weak"
                              ],
                   "inflate":  [
                                   "expand"
                               ],
                   "inflation":  [
                                     "pricerise"
                                 ],
                   "inflection":  [
                                      "variation"
                                  ],
                   "inflexible":  [
                                      "rigid"
                                  ],
                   "inflict":  [
                                   "impose"
                               ],
                   "influence":  [
                                     "affect"
                                 ],
                   "influential":  [
                                       "powerful"
                                   ],
                   "influx":  [
                                  "inflow"
                              ],
                   "informal":  [
                                    "casual"
                                ],
                   "information":  [
                                       "data"
                                   ],
                   "infrared":  [
                                    "heat-radiation"
                                ],
                   "infrasound":  [
                                      "low-frequencysound"
                                  ],
                   "infrastructural":  [
                                           "infrastructure-related"
                                       ],
                   "infrastructure":  [
                                          "basicfacilities"
                                      ],
                   "infrequent":  [
                                      "rare"
                                  ],
                   "infringe":  [
                                    "violate"
                                ],
                   "ingenious":  [
                                     "clever"
                                 ],
                   "ingeniousness":  [
                                         "cleverness"
                                     ],
                   "ingenuity":  [
                                     "creativity"
                                 ],
                   "ingoing":  [
                                   "incoming"
                               ],
                   "inhabit":  [
                                   "livein"
                               ],
                   "inhabitant":  [
                                      "resident"
                                  ],
                   "inhere":  [
                                  "belongnaturally"
                              ],
                   "inherence":  [
                                     "intrinsicpresence"
                                 ],
                   "inherent":  [
                                    "intrinsic"
                                ],
                   "inherit":  [
                                   "receive"
                               ],
                   "inheritance":  [
                                       "legacy"
                                   ],
                   "inhibit":  [
                                   "restrain"
                               ],
                   "inhibition":  [
                                      "restraint"
                                  ],
                   "initial":  [
                                   "first"
                               ],
                   "initiate":  [
                                    "start"
                                ],
                   "initiation":  [
                                      "beginning"
                                  ],
                   "initiative":  [
                                      "plan"
                                  ],
                   "inject":  [
                                  "insert"
                              ],
                   "injustice":  [
                                     "unfairness"
                                 ],
                   "inland":  [
                                  "interior"
                              ],
                   "inner":  [
                                 "internal"
                             ],
                   "innermost":  [
                                     "deepest"
                                 ],
                   "innerness":  [
                                     "interiority"
                                 ],
                   "innovate":  [
                                    "create"
                                ],
                   "innovation":  [
                                      "invention"
                                  ],
                   "innovative":  [
                                      "inventive"
                                  ],
                   "innovator":  [
                                     "inventor"
                                 ],
                   "innuendo":  [
                                    "insinuation"
                                ],
                   "input":  [
                                 "entry"
                             ],
                   "inquire":  [
                                   "ask"
                               ],
                   "inscribe":  [
                                    "engrave"
                                ],
                   "inscription":  [
                                       "engraving"
                                   ],
                   "insecticide":  [
                                       "pesticide"
                                   ],
                   "insecure":  [
                                    "unsafe"
                                ],
                   "insecurity":  [
                                      "uncertainty"
                                  ],
                   "insert":  [
                                  "placeinto"
                              ],
                   "insight":  [
                                   "understanding"
                               ],
                   "insightful":  [
                                      "perceptive"
                                  ],
                   "insightfulness":  [
                                          "perceptiveness"
                                      ],
                   "insignificant":  [
                                         "minor"
                                     ],
                   "insincere":  [
                                     "dishonest"
                                 ],
                   "inspect":  [
                                   "examine"
                               ],
                   "inspection":  [
                                      "examination"
                                  ],
                   "inspector":  [
                                     "examiner"
                                 ],
                   "instance":  [
                                    "example"
                                ],
                   "instinct":  [
                                    "impulse"
                                ],
                   "institute":  [
                                     "institution"
                                 ],
                   "institution":  [
                                       "organisation"
                                   ],
                   "instruct":  [
                                    "teach"
                                ],
                   "instruction":  [
                                       "guidance"
                                   ],
                   "instrument":  [
                                      "tool"
                                  ],
                   "insufficiency":  [
                                         "shortage"
                                     ],
                   "insufficient":  [
                                        "inadequate"
                                    ],
                   "insulate":  [
                                    "protect"
                                ],
                   "insulation":  [
                                      "protection"
                                  ],
                   "insult":  [
                                  "offence"
                              ],
                   "insurance":  [
                                     "protectionplan"
                                 ],
                   "intangible":  [
                                      "immaterial"
                                  ],
                   "integer":  [
                                   "wholenumber"
                               ],
                   "integral":  [
                                    "essential"
                                ],
                   "integrate":  [
                                     "combine"
                                 ],
                   "integration":  [
                                       "combination"
                                   ],
                   "integrative":  [
                                       "combining"
                                   ],
                   "integrity":  [
                                     "honesty"
                                 ],
                   "intellect":  [
                                     "mind"
                                 ],
                   "intellectual":  [
                                        "scholarly"
                                    ],
                   "intellectualproperty":  [
                                                "creativerights"
                                            ],
                   "intelligence":  [
                                        "intellect"
                                    ],
                   "intelligent":  [
                                       "smart"
                                   ],
                   "intelligibility":  [
                                           "understandability"
                                       ],
                   "intelligible":  [
                                        "understandable"
                                    ],
                   "intelligibly":  [
                                        "understandably"
                                    ],
                   "intend":  [
                                  "mean"
                              ],
                   "intense":  [
                                   "strong"
                               ],
                   "intensify":  [
                                     "strengthen"
                                 ],
                   "intensity":  [
                                     "strength"
                                 ],
                   "intensive":  [
                                     "concentrated"
                                 ],
                   "intention":  [
                                     "aim"
                                 ],
                   "interact":  [
                                    "communicate"
                                ],
                   "interaction":  [
                                       "communication"
                                   ],
                   "interactive":  [
                                       "responsive"
                                   ],
                   "intercede":  [
                                     "mediate"
                                 ],
                   "intercept":  [
                                     "stop"
                                 ],
                   "interdependence":  [
                                           "mutualdependence"
                                       ],
                   "interface":  [
                                     "connectionpoint"
                                 ],
                   "interfere":  [
                                     "meddle"
                                 ],
                   "interference":  [
                                        "disturbance"
                                    ],
                   "intergroup":  [
                                      "betweengroups"
                                  ],
                   "interior":  [
                                    "inside"
                                ],
                   "intermediate":  [
                                        "middle"
                                    ],
                   "internal":  [
                                    "inner"
                                ],
                   "internality":  [
                                       "interiority"
                                   ],
                   "internalize":  [
                                       "absorb"
                                   ],
                   "international":  [
                                         "global"
                                     ],
                   "interoperability":  [
                                            "compatibility"
                                        ],
                   "interoperate":  [
                                        "worktogether"
                                    ],
                   "interpret":  [
                                     "explain"
                                 ],
                   "interpretation":  [
                                          "explanation"
                                      ],
                   "interpreter":  [
                                       "translator"
                                   ],
                   "interstellar":  [
                                        "betweenstars"
                                    ],
                   "interstellarcloud":  [
                                             "star-cloud"
                                         ],
                   "interval":  [
                                    "gap"
                                ],
                   "intervene":  [
                                     "interfere"
                                 ],
                   "intervention":  [
                                        "involvement"
                                    ],
                   "interview":  [
                                     "conversation"
                                 ],
                   "intestine":  [
                                     "gut"
                                 ],
                   "intimate":  [
                                    "close"
                                ],
                   "intonation":  [
                                      "pitchpattern"
                                  ],
                   "intonational":  [
                                        "pitch-related"
                                    ],
                   "intricacy":  [
                                     "complexity"
                                 ],
                   "intricate":  [
                                     "complex"
                                 ],
                   "intrigue":  [
                                    "fascinate"
                                ],
                   "intrinsic":  [
                                     "inherent"
                                 ],
                   "intrinsicness":  [
                                         "inherence"
                                     ],
                   "introduce":  [
                                     "present"
                                 ],
                   "introduction":  [
                                        "introduce",
                                        "presentation"
                                    ],
                   "introductory":  [
                                        "basic"
                                    ],
                   "introvert":  [
                                     "reservedperson"
                                 ],
                   "intuition":  [
                                     "instinct"
                                 ],
                   "inundate":  [
                                    "flood"
                                ],
                   "inundation":  [
                                      "flooding"
                                  ],
                   "invalid":  [
                                   "false"
                               ],
                   "invalidate":  [
                                      "disprove"
                                  ],
                   "invalidation":  [
                                        "disproof"
                                    ],
                   "invariable":  [
                                      "constant"
                                  ],
                   "invariably":  [
                                      "always"
                                  ],
                   "invariant":  [
                                     "vary"
                                 ],
                   "invasion":  [
                                    "incursion"
                                ],
                   "invent":  [
                                  "create"
                              ],
                   "invention":  [
                                     "creation"
                                 ],
                   "inventive":  [
                                     "creative"
                                 ],
                   "inventor":  [
                                    "creator"
                                ],
                   "inventory":  [
                                     "stocklist"
                                 ],
                   "invert":  [
                                  "reverse"
                              ],
                   "invest":  [
                                  "fund"
                              ],
                   "investigate":  [
                                       "examine"
                                   ],
                   "investigation":  [
                                         "inquiry"
                                     ],
                   "investigative":  [
                                         "inquiry-based"
                                     ],
                   "investigator":  [
                                        "inquirer"
                                    ],
                   "investment":  [
                                      "funding"
                                  ],
                   "investor":  [
                                    "financier"
                                ],
                   "invisible":  [
                                     "unseen"
                                 ],
                   "invocable":  [
                                     "callable"
                                 ],
                   "invocation":  [
                                      "calling"
                                  ],
                   "invoke":  [
                                  "callupon"
                              ],
                   "involve":  [
                                   "include"
                               ],
                   "involvement":  [
                                       "participation"
                                   ],
                   "invulnerable":  [
                                        "immune"
                                    ],
                   "inward":  [
                                  "inner"
                              ],
                   "ion":  [
                               "chargedparticle"
                           ],
                   "irrational":  [
                                      "unreasonable"
                                  ],
                   "irregular":  [
                                     "uneven"
                                 ],
                   "irregularity":  [
                                        "abnormality"
                                    ],
                   "irreplaceable":  [
                                         "unique"
                                     ],
                   "irresponsible":  [
                                         "reckless"
                                     ],
                   "irrigate":  [
                                    "water"
                                ],
                   "irrigation":  [
                                      "watering"
                                  ],
                   "isolate":  [
                                   "separate"
                               ],
                   "isolation":  [
                                     "separation"
                                 ],
                   "iteration":  [
                                     "version"
                                 ],
                   "ivory":  [
                                 "tuskmaterial"
                             ],
                   "jar":  [
                               "container"
                           ],
                   "jargon":  [
                                  "technicallanguage"
                              ],
                   "jazz":  [
                                "improvisedmusic"
                            ],
                   "jeopardize":  [
                                      "endanger"
                                  ],
                   "jeopardy":  [
                                    "danger"
                                ],
                   "jewel":  [
                                 "gem"
                             ],
                   "join":  [
                                "connect"
                            ],
                   "joint":  [
                                 "shared"
                             ],
                   "journal":  [
                                   "periodical"
                               ],
                   "journalism":  [
                                      "newsreporting"
                                  ],
                   "journalist":  [
                                      "reporter"
                                  ],
                   "joust":  [
                                 "contest"
                             ],
                   "judge":  [
                                 "assess"
                             ],
                   "judgement":  [
                                     "assessment"
                                 ],
                   "judicial":  [
                                    "legal"
                                ],
                   "judiciary":  [
                                     "courtsystem"
                                 ],
                   "judicious":  [
                                     "wise"
                                 ],
                   "junction":  [
                                    "intersection"
                                ],
                   "jurisdiction":  [
                                        "authority"
                                    ],
                   "jurisdictional":  [
                                          "authority-related"
                                      ],
                   "jury":  [
                                "panel"
                            ],
                   "justice":  [
                                   "fairness"
                               ],
                   "justifiable":  [
                                       "defensible"
                                   ],
                   "justification":  [
                                         "reason"
                                     ],
                   "justify":  [
                                   "defend"
                               ],
                   "kaleidoscope":  [
                                        "patternviewer"
                                    ],
                   "kangaroo":  [
                                    "marsupial"
                                ],
                   "keen":  [
                                "eager"
                            ],
                   "keenness":  [
                                    "eagerness"
                                ],
                   "kernel":  [
                                  "core"
                              ],
                   "kiln":  [
                                "furnace"
                            ],
                   "kin":  [
                               "relative"
                           ],
                   "kind":  [
                                "type"
                            ],
                   "kindle":  [
                                  "ignite"
                              ],
                   "kinetic":  [
                                   "motion-related"
                               ],
                   "kingdom":  [
                                   "realm"
                               ],
                   "kinship":  [
                                   "familyrelation"
                               ],
                   "kite":  [
                                "glider"
                            ],
                   "knot":  [
                                "tie"
                            ],
                   "koala":  [
                                 "marsupial"
                             ],
                   "krill":  [
                                 "smallcrustacean"
                             ],
                   "labor":  [
                                 "work"
                             ],
                   "laboratory":  [
                                      "lab"
                                  ],
                   "labour":  [
                                  "work"
                              ],
                   "labourer":  [
                                    "worker"
                                ],
                   "lament":  [
                                  "mourn"
                              ],
                   "land":  [
                                "territory"
                            ],
                   "landfill":  [
                                    "wastesite"
                                ],
                   "landmark":  [
                                    "milestone"
                                ],
                   "landmass":  [
                                    "continent"
                                ],
                   "landscape":  [
                                     "scenery"
                                 ],
                   "language":  [
                                    "speech"
                                ],
                   "large":  [
                                 "big"
                             ],
                   "late":  [
                                "delayed"
                            ],
                   "latency":  [
                                   "delay"
                               ],
                   "latent":  [
                                  "hidden"
                              ],
                   "latentness":  [
                                      "hiddenness"
                                  ],
                   "lateral":  [
                                   "sideways"
                               ],
                   "lateralisation":  [
                                          "sidedominance"
                                      ],
                   "lateralization":  [
                                          "sidedominance"
                                      ],
                   "lateralized":  [
                                       "side-dominant"
                                   ],
                   "latitude":  [
                                    "north-southposition"
                                ],
                   "latitudinal":  [
                                       "latitude-related"
                                   ],
                   "launch":  [
                                  "start"
                              ],
                   "lava":  [
                                "moltenrock"
                            ],
                   "law":  [
                               "rule"
                           ],
                   "lawsuit":  [
                                   "legalcase"
                               ],
                   "lead":  [
                                "guide"
                            ],
                   "leader":  [
                                  "chief"
                              ],
                   "leaf":  [
                                "foliage"
                            ],
                   "legacy":  [
                                  "inheritance"
                              ],
                   "legal":  [
                                 "lawful"
                             ],
                   "legalise":  [
                                    "authorize"
                                ],
                   "legatee":  [
                                   "heir"
                               ],
                   "legible":  [
                                   "readable"
                               ],
                   "legislate":  [
                                     "makelaw"
                                 ],
                   "legislation":  [
                                       "law"
                                   ],
                   "legitimacy":  [
                                      "validity"
                                  ],
                   "legitimate":  [
                                      "valid"
                                  ],
                   "legitimize":  [
                                      "validate"
                                  ],
                   "lemma":  [
                                 "baseform"
                             ],
                   "lemur":  [
                                 "primate"
                             ],
                   "length":  [
                                  "extent"
                              ],
                   "lengthen":  [
                                    "extend"
                                ],
                   "lengthwise":  [
                                      "longitudinally"
                                  ],
                   "lengthy":  [
                                   "long"
                               ],
                   "lens":  [
                                "optic"
                            ],
                   "lesion":  [
                                  "damage"
                              ],
                   "lethal":  [
                                  "deadly"
                              ],
                   "leukaemia":  [
                                     "bloodcancer"
                                 ],
                   "lever":  [
                                 "handle"
                             ],
                   "leverage":  [
                                    "usestrategically"
                                ],
                   "lexical":  [
                                   "word-related"
                               ],
                   "lexicon":  [
                                   "vocabulary"
                               ],
                   "liability":  [
                                     "responsibility"
                                 ],
                   "liable":  [
                                  "responsible"
                              ],
                   "liably":  [
                                  "responsibly"
                              ],
                   "liberal":  [
                                   "progressive"
                               ],
                   "liberalism":  [
                                      "freedomdoctrine"
                                  ],
                   "liberate":  [
                                    "free"
                                ],
                   "liberation":  [
                                      "freedom"
                                  ],
                   "liberty":  [
                                   "freedom"
                               ],
                   "library":  [
                                   "archive"
                               ],
                   "license":  [
                                   "permit"
                               ],
                   "lifeline":  [
                                    "support"
                                ],
                   "light":  [
                                 "illumination"
                             ],
                   "lighthouse":  [
                                      "beacon"
                                  ],
                   "lightning":  [
                                     "flash"
                                 ],
                   "likelihood":  [
                                      "probability"
                                  ],
                   "limb":  [
                                "appendage"
                            ],
                   "liminal":  [
                                   "transitional"
                               ],
                   "limit":  [
                                 "boundary"
                             ],
                   "lineage":  [
                                   "ancestry"
                               ],
                   "linear":  [
                                  "straight-line"
                              ],
                   "linger":  [
                                  "remain"
                              ],
                   "lingeringly":  [
                                       "lasting"
                                   ],
                   "linguist":  [
                                    "languagescholar"
                                ],
                   "linguistic":  [
                                      "language-related"
                                  ],
                   "liquid":  [
                                  "fluid"
                              ],
                   "liquidity":  [
                                     "cashavailability"
                                 ],
                   "literacy":  [
                                    "readingability"
                                ],
                   "literal":  [
                                   "word-for-word"
                               ],
                   "literalness":  [
                                       "word-for-word"
                                   ],
                   "literary":  [
                                    "textual"
                                ],
                   "literate":  [
                                    "educated"
                                ],
                   "literature":  [
                                      "writing"
                                  ],
                   "litigate":  [
                                    "sue"
                                ],
                   "litigation":  [
                                      "lawsuit"
                                  ],
                   "livelihood":  [
                                      "incomesource"
                                  ],
                   "livestock":  [
                                     "farmanimals"
                                 ],
                   "load":  [
                                "burden"
                            ],
                   "loathe":  [
                                  "detest"
                              ],
                   "loathsome":  [
                                     "disgusting"
                                 ],
                   "local":  [
                                 "regional"
                             ],
                   "locate":  [
                                  "find"
                              ],
                   "location":  [
                                    "place"
                                ],
                   "locomotion":  [
                                      "movement"
                                  ],
                   "locomotive":  [
                                      "engine"
                                  ],
                   "logic":  [
                                 "reasoning"
                             ],
                   "logical":  [
                                   "rational"
                               ],
                   "logistical":  [
                                      "organizational"
                                  ],
                   "logistics":  [
                                     "organization"
                                 ],
                   "longitude":  [
                                     "east-westposition"
                                 ],
                   "longitudinal":  [
                                        "lengthwise"
                                    ],
                   "lubricant":  [
                                     "oil"
                                 ],
                   "lubricate":  [
                                     "oil"
                                 ],
                   "lubrication":  [
                                       "oiling"
                                   ],
                   "lucid":  [
                                 "clear"
                             ],
                   "luminosity":  [
                                      "brightness"
                                  ],
                   "luminous":  [
                                    "bright"
                                ],
                   "lunar":  [
                                 "moon-related"
                             ],
                   "luster":  [
                                  "shine"
                              ],
                   "lustrous":  [
                                    "shiny"
                                ],
                   "luxury":  [
                                  "extravagance"
                              ],
                   "macaque":  [
                                   "monkey"
                               ],
                   "machining":  [
                                     "manufacturing"
                                 ],
                   "magistrate":  [
                                      "judge"
                                  ],
                   "magnetic":  [
                                    "attractive"
                                ],
                   "magnitude":  [
                                     "scale"
                                 ],
                   "mainstream":  [
                                      "dominant"
                                  ],
                   "maintain":  [
                                    "preserve"
                                ],
                   "maintainer":  [
                                      "keeper"
                                  ],
                   "maintenance":  [
                                       "upkeep"
                                   ],
                   "major":  [
                                 "minor",
                                 "significant"
                             ],
                   "majority":  [
                                    "most"
                                ],
                   "makeshift":  [
                                     "temporary"
                                 ],
                   "malnourished":  [
                                        "undernourished"
                                    ],
                   "malnutrition":  [
                                        "undernutrition"
                                    ],
                   "mammal":  [
                                  "warm-bloodedanimal"
                              ],
                   "mammalian":  [
                                     "mammal-related"
                                 ],
                   "mandate":  [
                                   "order"
                               ],
                   "mandatory":  [
                                     "compulsory"
                                 ],
                   "manifest":  [
                                    "show"
                                ],
                   "manifestation":  [
                                         "expression"
                                     ],
                   "manifesto":  [
                                     "declaration"
                                 ],
                   "manipulate":  [
                                      "control"
                                  ],
                   "manipulation":  [
                                        "control"
                                    ],
                   "manoeuvre":  [
                                     "strategy"
                                 ],
                   "manual":  [
                                  "handbook"
                              ],
                   "manufacture":  [
                                       "produce"
                                   ],
                   "manufacturer":  [
                                        "producer"
                                    ],
                   "manuscript":  [
                                      "draft"
                                  ],
                   "margin":  [
                                  "edge"
                              ],
                   "marginal":  [
                                    "peripheral"
                                ],
                   "marginalisation":  [
                                           "exclusion"
                                       ],
                   "marginalised":  [
                                        "excluded"
                                    ],
                   "marginalization":  [
                                           "exclusion"
                                       ],
                   "marginalize":  [
                                       "exclude"
                                   ],
                   "marine":  [
                                  "sea-related"
                              ],
                   "marketable":  [
                                      "sellable"
                                  ],
                   "marketer":  [
                                    "promoter"
                                ],
                   "marriage":  [
                                    "union"
                                ],
                   "martial":  [
                                   "military"
                               ],
                   "mass":  [
                                "bulk"
                            ],
                   "massacre":  [
                                    "slaughter"
                                ],
                   "massive":  [
                                   "huge"
                               ],
                   "massiveness":  [
                                       "hugeness"
                                   ],
                   "material":  [
                                    "substance"
                                ],
                   "materialism":  [
                                       "physicalism"
                                   ],
                   "materialistic":  [
                                         "possessive"
                                     ],
                   "matriculate":  [
                                       "enrol"
                                   ],
                   "matrix":  [
                                  "grid"
                              ],
                   "maximise":  [
                                    "maximize"
                                ],
                   "maximization":  [
                                        "optimization"
                                    ],
                   "maximize":  [
                                    "optimise"
                                ],
                   "maximum":  [
                                   "limit"
                               ],
                   "maze":  [
                                "labyrinth"
                            ],
                   "mean":  [
                                "signify"
                            ],
                   "measurable":  [
                                      "quantifiable"
                                  ],
                   "measure":  [
                                   "assess"
                               ],
                   "measurement":  [
                                       "calculation"
                                   ],
                   "mechanical":  [
                                      "machine-related"
                                  ],
                   "mechanism":  [
                                     "process"
                                 ],
                   "mediate":  [
                                   "intervene"
                               ],
                   "mediation":  [
                                     "intervention"
                                 ],
                   "mediator":  [
                                    "intermediary"
                                ],
                   "medieval":  [
                                    "middle-age"
                                ],
                   "meditate":  [
                                    "reflect"
                                ],
                   "meditation":  [
                                      "reflection"
                                  ],
                   "meditative":  [
                                      "reflective"
                                  ],
                   "medium":  [
                                  "channel"
                              ],
                   "memorial":  [
                                    "monument"
                                ],
                   "memorise":  [
                                    "learnbyheart"
                                ],
                   "memorize":  [
                                    "learnbyheart"
                                ],
                   "memory":  [
                                  "recollection"
                              ],
                   "mental":  [
                                  "psychological"
                              ],
                   "merchant":  [
                                    "trader"
                                ],
                   "merge":  [
                                 "combine"
                             ],
                   "merger":  [
                                  "combination"
                              ],
                   "merit":  [
                                 "value"
                             ],
                   "meritocracy":  [
                                       "talentrule"
                                   ],
                   "meritocratic":  [
                                        "talent-based"
                                    ],
                   "meritorious":  [
                                       "deserving"
                                   ],
                   "metabolic":  [
                                     "metabolism-related"
                                 ],
                   "metabolism":  [
                                      "chemicalprocessing"
                                  ],
                   "metacognition":  [
                                         "thinkingaboutthinking"
                                     ],
                   "metacognitive":  [
                                         "self-monitoring"
                                     ],
                   "metamorphosis":  [
                                         "transformation"
                                     ],
                   "metaphor":  [
                                    "analogy"
                                ],
                   "metaphorical":  [
                                        "figurative"
                                    ],
                   "meteorology":  [
                                       "weatherscience"
                                   ],
                   "method":  [
                                  "approach"
                              ],
                   "methodological":  [
                                          "method-related"
                                      ],
                   "methodology":  [
                                       "methodsystem"
                                   ],
                   "meticulous":  [
                                      "careful"
                                  ],
                   "metropolis":  [
                                      "bigcity"
                                  ],
                   "metropolitan":  [
                                        "urban"
                                    ],
                   "microbial":  [
                                     "microbe-related"
                                 ],
                   "microcosm":  [
                                     "smallworld"
                                 ],
                   "micronutrient":  [
                                         "tracenutrient"
                                     ],
                   "microscope":  [
                                      "magnifier"
                                  ],
                   "migrate":  [
                                   "move"
                               ],
                   "migration":  [
                                     "movement"
                                 ],
                   "migratory":  [
                                     "migrate"
                                 ],
                   "military":  [
                                    "armedforces"
                                ],
                   "millennium":  [
                                      "thousandyears"
                                  ],
                   "mimic":  [
                                 "imitate"
                             ],
                   "mine":  [
                                "extract"
                            ],
                   "mineral":  [
                                   "inorganicsubstance"
                               ],
                   "miniature":  [
                                     "smallmodel"
                                 ],
                   "minimal":  [
                                   "smallest"
                               ],
                   "minimalism":  [
                                      "simplicity"
                                  ],
                   "minimalist":  [
                                      "simple-style"
                                  ],
                   "minimize":  [
                                    "reduce"
                                ],
                   "minimum":  [
                                   "least"
                               ],
                   "minister":  [
                                    "official"
                                ],
                   "ministry":  [
                                    "department"
                                ],
                   "minor":  [
                                 "small"
                             ],
                   "minority":  [
                                    "smallergroup"
                                ],
                   "minute":  [
                                  "tiny"
                              ],
                   "mislead":  [
                                   "deceive"
                               ],
                   "misleader":  [
                                     "deceiver"
                                 ],
                   "misrepresent":  [
                                        "distort"
                                    ],
                   "misrepresentation":  [
                                             "distortion"
                                         ],
                   "missile":  [
                                   "projectile"
                               ],
                   "mission":  [
                                   "task"
                               ],
                   "misunderstanding":  [
                                            "confusion"
                                        ],
                   "mitigate":  [
                                    "alleviate"
                                ],
                   "mitigation":  [
                                      "alleviation"
                                  ],
                   "mixed":  [
                                 "combined"
                             ],
                   "mobilise":  [
                                    "activate"
                                ],
                   "mobility":  [
                                    "movement"
                                ],
                   "modal":  [
                                 "mode-related"
                             ],
                   "mode":  [
                                "form"
                            ],
                   "model":  [
                                 "framework"
                             ],
                   "moderate":  [
                                    "restrained"
                                ],
                   "moderation":  [
                                      "restraint"
                                  ],
                   "moderator":  [
                                     "mediator"
                                 ],
                   "modern":  [
                                  "contemporary"
                              ],
                   "modernity":  [
                                     "contemporaneity"
                                 ],
                   "modernization":  [
                                         "updating"
                                     ],
                   "modernize":  [
                                     "update"
                                 ],
                   "modifiable":  [
                                      "adjustable"
                                  ],
                   "modification":  [
                                        "adjustment"
                                    ],
                   "modify":  [
                                  "adjust"
                              ],
                   "module":  [
                                  "unit"
                              ],
                   "moisture":  [
                                    "humidity"
                                ],
                   "molecular":  [
                                     "molecule-related"
                                 ],
                   "molecule":  [
                                    "chemicalunit"
                                ],
                   "moment":  [
                                  "instant"
                              ],
                   "momentous":  [
                                     "significant"
                                 ],
                   "momentum":  [
                                    "impetus"
                                ],
                   "monetary":  [
                                    "financial"
                                ],
                   "monetization":  [
                                        "commercialization"
                                    ],
                   "monetize":  [
                                    "commercialize"
                                ],
                   "monitor":  [
                                   "observe"
                               ],
                   "monopolize":  [
                                      "dominate"
                                  ],
                   "monopoly":  [
                                    "dominance"
                                ],
                   "monument":  [
                                    "memorial"
                                ],
                   "monumental":  [
                                      "massive"
                                  ],
                   "moral":  [
                                 "ethical"
                             ],
                   "morale":  [
                                  "confidence"
                              ],
                   "morality":  [
                                    "ethics"
                                ],
                   "morph":  [
                                 "transform"
                             ],
                   "morphological":  [
                                         "form-related"
                                     ],
                   "morphology":  [
                                      "formstudy"
                                  ],
                   "mortality":  [
                                     "deathrate"
                                 ],
                   "motif":  [
                                 "theme"
                             ],
                   "motivate":  [
                                    "inspire"
                                ],
                   "motivation":  [
                                      "incentive"
                                  ],
                   "motivational":  [
                                        "inspiring"
                                    ],
                   "motive":  [
                                  "reason"
                              ],
                   "movable":  [
                                   "mobile"
                               ],
                   "movement":  [
                                    "motion"
                                ],
                   "multilingual":  [
                                        "many-language"
                                    ],
                   "multilingualism":  [
                                           "many-languageability"
                                       ],
                   "multiplex":  [
                                     "multi-layered"
                                 ],
                   "mutation":  [
                                    "geneticchange"
                                ],
                   "mutualism":  [
                                     "reciprocity"
                                 ],
                   "myth":  [
                                "legend"
                            ],
                   "mythological":  [
                                        "legendary"
                                    ],
                   "mythology":  [
                                     "legendsystem"
                                 ],
                   "narcissism":  [
                                      "self-absorption"
                                  ],
                   "narcissistic":  [
                                        "self-absorbed"
                                    ],
                   "narrate":  [
                                   "recount"
                               ],
                   "narrative":  [
                                     "story"
                                 ],
                   "nascent":  [
                                   "emerging"
                               ],
                   "national":  [
                                    "state-level"
                                ],
                   "natural":  [
                                   "organic"
                               ],
                   "naturalist":  [
                                      "naturescholar"
                                  ],
                   "navigate":  [
                                    "steer"
                                ],
                   "navigation":  [
                                      "guidance"
                                  ],
                   "navigational":  [
                                        "guidance-related"
                                    ],
                   "navigator":  [
                                     "navigate"
                                 ],
                   "negate":  [
                                  "deny"
                              ],
                   "negation":  [
                                    "denial"
                                ],
                   "neglect":  [
                                   "ignore"
                               ],
                   "neglectful":  [
                                      "careless"
                                  ],
                   "negligence":  [
                                      "carelessness"
                                  ],
                   "negligible":  [
                                      "insignificant"
                                  ],
                   "negotiate":  [
                                     "bargain"
                                 ],
                   "negotiation":  [
                                       "bargaining"
                                   ],
                   "neighbor":  [
                                    "nearbyresident"
                                ],
                   "neighborhood":  [
                                        "localarea"
                                    ],
                   "neural":  [
                                  "nerve-related"
                              ],
                   "neuron":  [
                                  "nervecell"
                              ],
                   "neuronal":  [
                                    "neuron-related"
                                ],
                   "neuroscience":  [
                                        "brainscience"
                                    ],
                   "neutral":  [
                                   "impartial"
                               ],
                   "neutrality":  [
                                      "impartiality"
                                  ],
                   "neutralize":  [
                                      "cancelout"
                                  ],
                   "niche":  [
                                 "specializedposition"
                             ],
                   "nominal":  [
                                   "named"
                               ],
                   "nonfiction":  [
                                      "factualwriting"
                                  ],
                   "nonverbal":  [
                                     "wordless"
                                 ],
                   "nonviable":  [
                                     "unworkable"
                                 ],
                   "norm":  [
                                "standard"
                            ],
                   "normal":  [
                                  "ordinary"
                              ],
                   "normalization":  [
                                         "standardisation"
                                     ],
                   "normalize":  [
                                     "standardise"
                                 ],
                   "notability":  [
                                      "prominence"
                                  ],
                   "notable":  [
                                   "prominent"
                               ],
                   "notably":  [
                                   "especially"
                               ],
                   "notation":  [
                                    "symbolsystem"
                                ],
                   "note":  [
                                "record"
                            ],
                   "notice":  [
                                  "observe"
                              ],
                   "noticeability":  [
                                         "visibility"
                                     ],
                   "noticeable":  [
                                      "visible"
                                  ],
                   "noticeably":  [
                                      "visibly"
                                  ],
                   "notify":  [
                                  "inform"
                              ],
                   "notorious":  [
                                     "infamous"
                                 ],
                   "nourish":  [
                                   "feed"
                               ],
                   "novel":  [
                                 "fiction"
                             ],
                   "novelist":  [
                                    "fictionwriter"
                                ],
                   "novelistic":  [
                                      "fictional"
                                  ],
                   "novelty":  [
                                   "newness"
                               ],
                   "nuance":  [
                                  "subtlety"
                              ],
                   "nuclear":  [
                                   "atomic"
                               ],
                   "nucleus":  [
                                   "core"
                               ],
                   "number":  [
                                  "figure"
                              ],
                   "numeracy":  [
                                    "numberability"
                                ],
                   "numerical":  [
                                     "number-based"
                                 ],
                   "nurturance":  [
                                      "care"
                                  ],
                   "nurture":  [
                                   "cultivate"
                               ],
                   "nutrient":  [
                                    "nourishment"
                                ],
                   "nutrition":  [
                                     "nourishment"
                                 ],
                   "nutritious":  [
                                      "nourishing"
                                  ],
                   "oasis":  [
                                 "refuge"
                             ],
                   "oath":  [
                                "pledge"
                            ],
                   "obese":  [
                                 "overweight"
                             ],
                   "obesity":  [
                                   "overweightcondition"
                               ],
                   "object":  [
                                  "thing"
                              ],
                   "objective":  [
                                     "goal"
                                 ],
                   "objectivity":  [
                                       "impartiality"
                                   ],
                   "obligation":  [
                                      "duty"
                                  ],
                   "obligatory":  [
                                      "mandatory"
                                  ],
                   "oblige":  [
                                  "force"
                              ],
                   "obscure":  [
                                   "hide"
                               ],
                   "obscurity":  [
                                     "darkness"
                                 ],
                   "observation":  [
                                       "watching"
                                   ],
                   "observe":  [
                                   "watch"
                               ],
                   "observer":  [
                                    "watcher"
                                ],
                   "obsess":  [
                                  "fixate"
                              ],
                   "obsolescence":  [
                                        "outdatedness"
                                    ],
                   "obsolete":  [
                                    "outdated"
                                ],
                   "obtain":  [
                                  "acquire"
                              ],
                   "obtainable":  [
                                      "available"
                                  ],
                   "obvious":  [
                                   "clear"
                               ],
                   "obviousness":  [
                                       "clear"
                                   ],
                   "occasional":  [
                                      "infrequent"
                                  ],
                   "occupant":  [
                                    "resident"
                                ],
                   "occupation":  [
                                      "work"
                                  ],
                   "occupy":  [
                                  "inhabit"
                              ],
                   "occur":  [
                                 "happen"
                             ],
                   "occurrence":  [
                                      "event"
                                  ],
                   "oceanic":  [
                                   "sea-related"
                               ],
                   "office":  [
                                  "workplace"
                              ],
                   "official":  [
                                    "authority"
                                ],
                   "offset":  [
                                  "counterbalance"
                              ],
                   "offspring":  [
                                     "descendant"
                                 ],
                   "omission":  [
                                    "exclusion"
                                ],
                   "omit":  [
                                "exclude"
                            ],
                   "ongoing":  [
                                   "continuing"
                               ],
                   "ongoingness":  [
                                       "continuing"
                                   ],
                   "ontology":  [
                                    "theoryofbeing"
                                ],
                   "opacity":  [
                                   "obscurity"
                               ],
                   "opaque":  [
                                  "unclear"
                              ],
                   "operate":  [
                                   "function"
                               ],
                   "operation":  [
                                     "functioning"
                                 ],
                   "operational":  [
                                       "functional"
                                   ],
                   "operator":  [
                                    "controller"
                                ],
                   "opponent":  [
                                    "rival"
                                ],
                   "opportunity":  [
                                       "chance"
                                   ],
                   "oppose":  [
                                  "resist"
                              ],
                   "opposition":  [
                                      "resistance"
                                  ],
                   "oppress":  [
                                   "dominate"
                               ],
                   "oppression":  [
                                      "domination"
                                  ],
                   "optical":  [
                                   "visual"
                               ],
                   "optimal":  [
                                   "best"
                               ],
                   "optimization":  [
                                        "improvement"
                                    ],
                   "optimize":  [
                                    "improve"
                                ],
                   "option":  [
                                  "choice"
                              ],
                   "optional":  [
                                    "voluntary"
                                ],
                   "oral":  [
                                "spoken"
                            ],
                   "orbit":  [
                                 "path"
                             ],
                   "orbital":  [
                                   "circular"
                               ],
                   "order":  [
                                 "sequence"
                             ],
                   "ordinary":  [
                                    "common"
                                ],
                   "organic":  [
                                   "natural"
                               ],
                   "organise":  [
                                    "arrange"
                                ],
                   "organism":  [
                                    "livingthing"
                                ],
                   "organize":  [
                                    "arrange"
                                ],
                   "orientation":  [
                                       "direction"
                                   ],
                   "origin":  [
                                  "source"
                              ],
                   "original":  [
                                    "initial"
                                ],
                   "ornament":  [
                                    "decoration"
                                ],
                   "orphan":  [
                                  "parentlesschild"
                              ],
                   "orthodox":  [
                                    "traditional"
                                ],
                   "orthodoxy":  [
                                     "acceptedbelief"
                                 ],
                   "oscillate":  [
                                     "swing"
                                 ],
                   "oscillation":  [
                                       "swinging"
                                   ],
                   "outcome":  [
                                   "result"
                               ],
                   "outdate":  [
                                   "obsolete"
                               ],
                   "outdatedness":  [
                                        "obsolete"
                                    ],
                   "outgoing":  [
                                    "extroverted"
                                ],
                   "outline":  [
                                   "sketch"
                               ],
                   "outside":  [
                                   "external"
                               ],
                   "outsource":  [
                                     "contractout"
                                 ],
                   "outstanding":  [
                                       "excellent"
                                   ],
                   "outward":  [
                                   "external"
                               ],
                   "outweigh":  [
                                    "surpass"
                                ],
                   "overcome":  [
                                    "defeat"
                                ],
                   "overcrowded":  [
                                       "overfilled"
                                   ],
                   "overcrowding":  [
                                        "congestion"
                                    ],
                   "overestimate":  [
                                        "overvalue"
                                    ],
                   "overlap":  [
                                   "coincide"
                               ],
                   "override":  [
                                    "overrule"
                                ],
                   "overshadow":  [
                                      "eclipse"
                                  ],
                   "oversight":  [
                                     "supervision"
                                 ],
                   "overstate":  [
                                     "exaggerate"
                                 ],
                   "overstatement":  [
                                         "exaggeration"
                                     ],
                   "overweight":  [
                                      "obese"
                                  ],
                   "overwhelm":  [
                                     "overload"
                                 ],
                   "ownership":  [
                                     "possession"
                                 ],
                   "oxidation":  [
                                     "rusting"
                                 ],
                   "oxidize":  [
                                   "rust"
                               ],
                   "oxygenation":  [
                                       "oxygensupply"
                                   ],
                   "pack":  [
                                "bundle"
                            ],
                   "package":  [
                                   "bundle"
                               ],
                   "packet":  [
                                  "bundle"
                              ],
                   "pact":  [
                                "agreement"
                            ],
                   "page":  [
                                "sheet"
                            ],
                   "paint":  [
                                 "artwork"
                             ],
                   "paintings":  [
                                     "artwork"
                                 ],
                   "pandemic":  [
                                    "globaloutbreak"
                                ],
                   "papermaking":  [
                                       "paperproduction"
                                   ],
                   "paradigm":  [
                                    "model"
                                ],
                   "paradigmatic":  [
                                        "model-like"
                                    ],
                   "paradox":  [
                                   "contradiction"
                               ],
                   "paradoxical":  [
                                       "contradictory"
                                   ],
                   "paralyse":  [
                                    "disable"
                                ],
                   "paralysis":  [
                                     "immobility"
                                 ],
                   "parameter":  [
                                     "variable"
                                 ],
                   "parametric":  [
                                      "variable-based"
                                  ],
                   "parasite":  [
                                    "organism"
                                ],
                   "parasitic":  [
                                     "dependent"
                                 ],
                   "parasitise":  [
                                      "exploit"
                                  ],
                   "parent":  [
                                  "guardian"
                              ],
                   "parental":  [
                                    "family-related"
                                ],
                   "parity":  [
                                  "equality"
                              ],
                   "parliament":  [
                                      "legislature"
                                  ],
                   "part":  [
                                "component"
                            ],
                   "partial":  [
                                   "incomplete"
                               ],
                   "participant":  [
                                       "attendee"
                                   ],
                   "participate":  [
                                       "join"
                                   ],
                   "participation":  [
                                         "involvement"
                                     ],
                   "participatory":  [
                                         "involving"
                                     ],
                   "particle":  [
                                    "smallunit"
                                ],
                   "particular":  [
                                      "specific"
                                  ],
                   "partition":  [
                                     "division"
                                 ],
                   "partner":  [
                                   "collaborator"
                               ],
                   "pass":  [
                                "gothrough"
                            ],
                   "passage":  [
                                   "route"
                               ],
                   "passenger":  [
                                     "traveller"
                                 ],
                   "passion":  [
                                   "enthusiasm"
                               ],
                   "passive":  [
                                   "inactive"
                               ],
                   "passport":  [
                                    "traveldocument"
                                ],
                   "patent":  [
                                  "exclusiveright"
                              ],
                   "path":  [
                                "route"
                            ],
                   "pathogen":  [
                                    "diseaseagent"
                                ],
                   "pathogenic":  [
                                      "disease-causing"
                                  ],
                   "pathological":  [
                                        "disease-related"
                                    ],
                   "pathology":  [
                                     "diseasestudy"
                                 ],
                   "patience":  [
                                    "endurance"
                                ],
                   "patriarch":  [
                                     "maleleader"
                                 ],
                   "patriarchal":  [
                                       "male-dominated"
                                   ],
                   "patriarchy":  [
                                      "maledominance"
                                  ],
                   "pattern":  [
                                   "structure"
                               ],
                   "pavement":  [
                                    "sidewalk"
                                ],
                   "peak":  [
                                "summit"
                            ],
                   "pearl":  [
                                 "gem"
                             ],
                   "pedagogical":  [
                                       "teaching-related"
                                   ],
                   "pedagogy":  [
                                    "teachingmethod"
                                ],
                   "pedestrian":  [
                                      "walker"
                                  ],
                   "pedestrianization":  [
                                             "walkingconversion"
                                         ],
                   "pedestrianize":  [
                                         "makewalkable"
                                     ],
                   "peer":  [
                                "equal"
                            ],
                   "peerage":  [
                                   "nobility"
                               ],
                   "penal":  [
                                 "punitive"
                             ],
                   "penalty":  [
                                   "punishment"
                               ],
                   "pend":  [
                                "unresolved"
                            ],
                   "penetrate":  [
                                     "enter"
                                 ],
                   "pension":  [
                                   "retirementpayment"
                               ],
                   "perceive":  [
                                    "notice"
                                ],
                   "perceptible":  [
                                       "noticeable"
                                   ],
                   "perception":  [
                                      "view"
                                  ],
                   "perceptive":  [
                                      "insightful"
                                  ],
                   "perceptual":  [
                                      "sensory"
                                  ],
                   "percussion":  [
                                      "drumming"
                                  ],
                   "perish":  [
                                  "die"
                              ],
                   "permafrost":  [
                                      "frozenground"
                                  ],
                   "permeability":  [
                                        "porosity"
                                    ],
                   "permeable":  [
                                     "porous"
                                 ],
                   "permeate":  [
                                    "penetrate"
                                ],
                   "perpetrate":  [
                                      "commit"
                                  ],
                   "perplex":  [
                                   "confuse"
                               ],
                   "perplexity":  [
                                      "confusion"
                                  ],
                   "persecution":  [
                                       "oppression"
                                   ],
                   "perseverance":  [
                                        "persistence"
                                    ],
                   "persist":  [
                                   "continue"
                               ],
                   "persistence":  [
                                       "continuity"
                                   ],
                   "persistent":  [
                                      "continuing"
                                  ],
                   "perspective":  [
                                       "viewpoint"
                                   ],
                   "persuade":  [
                                    "convince"
                                ],
                   "persuasion":  [
                                      "convincing"
                                  ],
                   "pest":  [
                                "nuisance"
                            ],
                   "pesticide":  [
                                     "chemicalkiller"
                                 ],
                   "petition":  [
                                    "appeal"
                                ],
                   "petrochemical":  [
                                         "oil-chemical"
                                     ],
                   "petroleum":  [
                                     "oil"
                                 ],
                   "phase":  [
                                 "stage"
                             ],
                   "philanthropy":  [
                                        "charity"
                                    ],
                   "philosopher":  [
                                       "thinker"
                                   ],
                   "phobia":  [
                                  "fear"
                              ],
                   "phobic":  [
                                  "fearful"
                              ],
                   "phonetic":  [
                                    "sound-related"
                                ],
                   "phonograph":  [
                                      "soundrecorder"
                                  ],
                   "phonological":  [
                                        "sound-system"
                                    ],
                   "phonology":  [
                                     "soundsystem"
                                 ],
                   "photo":  [
                                 "picture"
                             ],
                   "photograph":  [
                                      "picture"
                                  ],
                   "photography":  [
                                       "picture-taking"
                                   ],
                   "photon":  [
                                  "lightparticle"
                              ],
                   "photosynthesis":  [
                                          "light-to-energyprocess"
                                      ],
                   "photosynthetic":  [
                                          "light-converting"
                                      ],
                   "photovoltaic":  [
                                        "solar-electric"
                                    ],
                   "physicist":  [
                                     "physicsscientist"
                                 ],
                   "phytoplankton":  [
                                         "plantplankton"
                                     ],
                   "pictograph":  [
                                      "picturesymbol"
                                  ],
                   "pigment":  [
                                   "colorant"
                               ],
                   "pigmentation":  [
                                        "colouring"
                                    ],
                   "pile":  [
                                "heap"
                            ],
                   "pilot":  [
                                 "aviator"
                             ],
                   "pilotless":  [
                                     "unmanned"
                                 ],
                   "pinpoint":  [
                                    "locateprecisely"
                                ],
                   "pivot":  [
                                 "turningpoint"
                             ],
                   "pivotal":  [
                                   "crucial"
                               ],
                   "pivotality":  [
                                      "importance"
                                  ],
                   "place":  [
                                 "location"
                             ],
                   "placement":  [
                                     "positioning"
                                 ],
                   "plague":  [
                                  "epidemic"
                              ],
                   "plaintiff":  [
                                     "claimant"
                                 ],
                   "plaintive":  [
                                     "mournful"
                                 ],
                   "planet":  [
                                  "world"
                              ],
                   "planetary":  [
                                     "planet-related"
                                 ],
                   "plankton":  [
                                    "driftingorganism"
                                ],
                   "planktonic":  [
                                      "drifting"
                                  ],
                   "plantation":  [
                                      "estate"
                                  ],
                   "plastic":  [
                                   "syntheticmaterial"
                               ],
                   "plasticity":  [
                                      "flexibility"
                                  ],
                   "plateau":  [
                                   "highplain"
                               ],
                   "platform":  [
                                    "system"
                                ],
                   "plausibility":  [
                                        "believability"
                                    ],
                   "plausible":  [
                                     "believable"
                                 ],
                   "plausibly":  [
                                     "believably"
                                 ],
                   "playground":  [
                                      "recreationarea"
                                  ],
                   "plume":  [
                                 "cloud"
                             ],
                   "pneumonia":  [
                                     "lunginfection"
                                 ],
                   "point":  [
                                 "idea"
                             ],
                   "poison":  [
                                  "toxin"
                              ],
                   "poisonous":  [
                                     "toxic"
                                 ],
                   "polar":  [
                                 "pole-related"
                             ],
                   "policy":  [
                                  "plan"
                              ],
                   "polish":  [
                                  "refine"
                              ],
                   "political":  [
                                     "governmental"
                                 ],
                   "pollutant":  [
                                     "contaminant"
                                 ],
                   "pollute":  [
                                   "contaminate"
                               ],
                   "polymer":  [
                                   "largemolecule"
                               ],
                   "polymeric":  [
                                     "polymer-related"
                                 ],
                   "porosity":  [
                                    "permeability"
                                ],
                   "porous":  [
                                  "permeable"
                              ],
                   "portable":  [
                                    "movable"
                                ],
                   "portrait":  [
                                    "likeness"
                                ],
                   "portray":  [
                                   "depict"
                               ],
                   "pose":  [
                                "present"
                            ],
                   "position":  [
                                    "place"
                                ],
                   "positive":  [
                                    "beneficial"
                                ],
                   "possess":  [
                                   "own"
                               ],
                   "possible":  [
                                    "feasible"
                                ],
                   "postgraduate":  [
                                        "graduatestudent"
                                    ],
                   "postulate":  [
                                     "assume"
                                 ],
                   "posture":  [
                                   "stance"
                               ],
                   "potential":  [
                                     "possibility"
                                 ],
                   "poverty":  [
                                   "deprivation"
                               ],
                   "power":  [
                                 "authority"
                             ],
                   "powerful":  [
                                    "influential"
                                ],
                   "pragmatic":  [
                                     "practical"
                                 ],
                   "pragmatism":  [
                                      "practicality"
                                  ],
                   "praise":  [
                                  "commendation"
                              ],
                   "praiseworthy":  [
                                        "commendable"
                                    ],
                   "precaution":  [
                                      "safeguard"
                                  ],
                   "precede":  [
                                   "comebefore"
                               ],
                   "precedence":  [
                                      "priority"
                                  ],
                   "precedent":  [
                                     "example"
                                 ],
                   "precious":  [
                                    "valuable"
                                ],
                   "precipitate":  [
                                       "trigger"
                                   ],
                   "precipitation":  [
                                         "rainfall"
                                     ],
                   "precise":  [
                                   "exact"
                               ],
                   "precision":  [
                                     "accuracy"
                                 ],
                   "predate":  [
                                   "comebefore"
                               ],
                   "predation":  [
                                     "hunting"
                                 ],
                   "predator":  [
                                    "hunter"
                                ],
                   "predatory":  [
                                     "exploitative"
                                 ],
                   "predict":  [
                                   "forecast"
                               ],
                   "predictable":  [
                                       "foreseeable"
                                   ],
                   "prediction":  [
                                      "forecast"
                                  ],
                   "predominantly":  [
                                         "mainly"
                                     ],
                   "preeminent":  [
                                      "leading"
                                  ],
                   "preference":  [
                                      "choice"
                                  ],
                   "prefigure":  [
                                     "foreshadow"
                                 ],
                   "prefrontal":  [
                                      "front-brain"
                                  ],
                   "prehistoric":  [
                                       "ancient"
                                   ],
                   "prehistory":  [
                                      "ancientpast"
                                  ],
                   "prejudge":  [
                                    "bias"
                                ],
                   "prejudice":  [
                                     "bias"
                                 ],
                   "prejudicial":  [
                                       "prejudice",
                                       "harmful"
                                   ],
                   "preliminary":  [
                                       "initial"
                                   ],
                   "premise":  [
                                   "assumption"
                               ],
                   "preparation":  [
                                       "readiness"
                                   ],
                   "prepare":  [
                                   "ready"
                               ],
                   "preponderance":  [
                                         "dominance"
                                     ],
                   "present":  [
                                   "current"
                               ],
                   "presentation":  [
                                        "display"
                                    ],
                   "preservation":  [
                                        "protection"
                                    ],
                   "preservative":  [
                                        "protectivesubstance"
                                    ],
                   "preserve":  [
                                    "protect"
                                ],
                   "presidency":  [
                                      "administration"
                                  ],
                   "presidential":  [
                                        "president-related"
                                    ],
                   "press":  [
                                 "media"
                             ],
                   "pressure":  [
                                    "strain"
                                ],
                   "presume":  [
                                   "assume"
                               ],
                   "prevail":  [
                                   "dominate"
                               ],
                   "prevalence":  [
                                      "commonness"
                                  ],
                   "prevalent":  [
                                     "common"
                                 ],
                   "prevent":  [
                                   "stop"
                               ],
                   "preventable":  [
                                       "avoidable"
                                   ],
                   "prevention":  [
                                      "avoidance"
                                  ],
                   "preventive":  [
                                      "protective"
                                  ],
                   "prey":  [
                                "victim"
                            ],
                   "pricing":  [
                                   "price-setting"
                               ],
                   "pride":  [
                                 "self-respect"
                             ],
                   "primary":  [
                                   "main"
                               ],
                   "primate":  [
                                   "ape-likemammal"
                               ],
                   "primitive":  [
                                     "early"
                                 ],
                   "primordial":  [
                                      "original"
                                  ],
                   "principal":  [
                                     "main"
                                 ],
                   "prior":  [
                                 "previous"
                             ],
                   "prioritize":  [
                                      "rankfirst"
                                  ],
                   "priority":  [
                                    "precedence"
                                ],
                   "pristine":  [
                                    "unspoiled"
                                ],
                   "pristineness":  [
                                        "purity"
                                    ],
                   "privacy":  [
                                   "personalsecrecy"
                               ],
                   "private":  [
                                   "personal"
                               ],
                   "privatization":  [
                                         "privateownershiptransfer"
                                     ],
                   "privatize":  [
                                     "makeprivate"
                                 ],
                   "probability":  [
                                       "likelihood"
                                   ],
                   "probable":  [
                                    "likely"
                                ],
                   "probe":  [
                                 "investigate"
                             ],
                   "proboscis":  [
                                     "trunk"
                                 ],
                   "procedural":  [
                                      "process-based"
                                  ],
                   "proceed":  [
                                   "continue"
                               ],
                   "process":  [
                                   "procedure"
                               ],
                   "proclaim":  [
                                    "announce"
                                ],
                   "procure":  [
                                   "obtain"
                               ],
                   "procurement":  [
                                       "purchasing"
                                   ],
                   "produce":  [
                                   "create"
                               ],
                   "producer":  [
                                    "maker"
                                ],
                   "product":  [
                                   "goods"
                               ],
                   "production":  [
                                      "manufacturing"
                                  ],
                   "productive":  [
                                      "efficient"
                                  ],
                   "productivity":  [
                                        "efficiency"
                                    ],
                   "proficiency":  [
                                       "skill"
                                   ],
                   "proficient":  [
                                      "skilled"
                                  ],
                   "profit":  [
                                  "gain"
                              ],
                   "profitability":  [
                                         "gainfulness"
                                     ],
                   "profitable":  [
                                      "gainful"
                                  ],
                   "profound":  [
                                    "deep"
                                ],
                   "profundity":  [
                                      "depth"
                                  ],
                   "program":  [
                                   "plan"
                               ],
                   "progressive":  [
                                       "reformist"
                                   ],
                   "prohibit":  [
                                    "ban"
                                ],
                   "prohibition":  [
                                       "ban"
                                   ],
                   "project":  [
                                   "plan"
                               ],
                   "prominence":  [
                                      "notability"
                                  ],
                   "prominent":  [
                                     "notable"
                                 ],
                   "promise":  [
                                   "pledge"
                               ],
                   "promote":  [
                                   "encourage"
                               ],
                   "promotion":  [
                                     "advancement"
                                 ],
                   "promotional":  [
                                       "advertising"
                                   ],
                   "prompt":  [
                                  "trigger"
                              ],
                   "pronunciation":  [
                                         "speechsound"
                                     ],
                   "proof":  [
                                 "evidence"
                             ],
                   "propaganda":  [
                                      "persuasioncampaign"
                                  ],
                   "propagandistic":  [
                                          "persuasive-political"
                                      ],
                   "propagate":  [
                                     "spread"
                                 ],
                   "proper":  [
                                  "appropriate"
                              ],
                   "property":  [
                                    "possession"
                                ],
                   "prophetic":  [
                                     "predictive"
                                 ],
                   "proportion":  [
                                      "ratio"
                                  ],
                   "proposal":  [
                                    "suggestion"
                                ],
                   "propose":  [
                                   "suggest"
                               ],
                   "proposer":  [
                                    "suggester"
                                ],
                   "proprietor":  [
                                      "owner"
                                  ],
                   "prosecute":  [
                                     "charge"
                                 ],
                   "prosecution":  [
                                       "legalaction"
                                   ],
                   "prospect":  [
                                    "possibility"
                                ],
                   "prospector":  [
                                      "explorer"
                                  ],
                   "prosperity":  [
                                      "wealth"
                                  ],
                   "protagonist":  [
                                       "maincharacter"
                                   ],
                   "protection":  [
                                      "safeguard"
                                  ],
                   "protective":  [
                                      "defensive"
                                  ],
                   "protein":  [
                                   "bodymolecule"
                               ],
                   "protest":  [
                                   "demonstration"
                               ],
                   "protocol":  [
                                    "procedure"
                                ],
                   "prototype":  [
                                     "model"
                                 ],
                   "prove":  [
                                 "demonstrate"
                             ],
                   "provenance":  [
                                      "origin"
                                  ],
                   "provincial":  [
                                      "regional"
                                  ],
                   "provocation":  [
                                       "incitement"
                                   ],
                   "provocative":  [
                                       "stimulating"
                                   ],
                   "provoke":  [
                                   "trigger"
                               ],
                   "proximity":  [
                                     "nearness"
                                 ],
                   "proxy":  [
                                 "substitute"
                             ],
                   "prudence":  [
                                    "caution"
                                ],
                   "prudent":  [
                                   "careful"
                               ],
                   "psyche":  [
                                  "mind"
                              ],
                   "psychological":  [
                                         "mental"
                                     ],
                   "psychologist":  [
                                        "mindscientist"
                                    ],
                   "psychology":  [
                                      "mindscience"
                                  ],
                   "public":  [
                                  "social"
                              ],
                   "pulse":  [
                                 "beat"
                             ],
                   "punctuate":  [
                                     "interrupt"
                                 ],
                   "punish":  [
                                  "penalize"
                              ],
                   "punishable":  [
                                      "penalizable"
                                  ],
                   "punishment":  [
                                      "penalty"
                                  ],
                   "punitive":  [
                                    "penal"
                                ],
                   "purchase":  [
                                    "buy"
                                ],
                   "purchaser":  [
                                     "buyer"
                                 ],
                   "purgatory":  [
                                     "limbo"
                                 ],
                   "pursue":  [
                                  "seek"
                              ],
                   "qualification":  [
                                         "credential"
                                     ],
                   "qualifier":  [
                                     "modifier"
                                 ],
                   "qualify":  [
                                   "beeligible"
                               ],
                   "qualitative":  [
                                       "quality-based"
                                   ],
                   "quality":  [
                                   "standard"
                               ],
                   "quandary":  [
                                    "dilemma"
                                ],
                   "quantifier":  [
                                      "amountword"
                                  ],
                   "quantify":  [
                                    "measure"
                                ],
                   "quantitative":  [
                                        "number-based"
                                    ],
                   "quantity":  [
                                    "amount"
                                ],
                   "quarantine":  [
                                      "isolation"
                                  ],
                   "quest":  [
                                 "search"
                             ],
                   "question":  [
                                    "inquiry"
                                ],
                   "quotable":  [
                                    "citable"
                                ],
                   "rabies":  [
                                  "viraldisease"
                              ],
                   "radiance":  [
                                    "brightness"
                                ],
                   "radiate":  [
                                   "emit"
                               ],
                   "radiation":  [
                                     "emission"
                                 ],
                   "radical":  [
                                   "extreme"
                               ],
                   "radicalism":  [
                                      "extremism"
                                  ],
                   "radicalize":  [
                                      "makeextreme"
                                  ],
                   "radioactive":  [
                                       "nuclear"
                                   ],
                   "radius":  [
                                  "distancefromcenter"
                              ],
                   "raid":  [
                                "attack"
                            ],
                   "rainfall":  [
                                    "precipitation"
                                ],
                   "rainforest":  [
                                      "tropicalforest"
                                  ],
                   "raise":  [
                                 "increase"
                             ],
                   "raiser":  [
                                  "collector"
                              ],
                   "randomize":  [
                                     "shuffle"
                                 ],
                   "ransom":  [
                                  "payment"
                              ],
                   "ratification":  [
                                        "approval"
                                    ],
                   "ratify":  [
                                  "approve"
                              ],
                   "ratio":  [
                                 "proportion"
                             ],
                   "rational":  [
                                    "reasonable"
                                ],
                   "rationale":  [
                                     "reason"
                                 ],
                   "rationalism":  [
                                       "reason-basedthought"
                                   ],
                   "rationalist":  [
                                       "reasoner"
                                   ],
                   "rationality":  [
                                       "reasonableness"
                                   ],
                   "rawness":  [
                                   "raw"
                               ],
                   "reaction":  [
                                    "response"
                                ],
                   "realism":  [
                                   "pragmatism"
                               ],
                   "realist":  [
                                   "pragmatist"
                               ],
                   "reality":  [
                                   "actuality"
                               ],
                   "reason":  [
                                  "cause"
                              ],
                   "reasonable":  [
                                      "rational"
                                  ],
                   "reassure":  [
                                    "comfort"
                                ],
                   "rebel":  [
                                 "revolutionary"
                             ],
                   "rebut":  [
                                 "refute"
                             ],
                   "rebuttal":  [
                                    "refutation"
                                ],
                   "recall":  [
                                  "remember"
                              ],
                   "recant":  [
                                  "withdraw"
                              ],
                   "recede":  [
                                  "retreat"
                              ],
                   "receive":  [
                                   "obtain"
                               ],
                   "reception":  [
                                     "welcome"
                                 ],
                   "receptive":  [
                                     "open"
                                 ],
                   "receptor":  [
                                    "receiver"
                                ],
                   "recession":  [
                                     "downturn"
                                 ],
                   "recessive":  [
                                     "hidden"
                                 ],
                   "rechargeable":  [
                                        "battery-powered"
                                    ],
                   "recitation":  [
                                      "recounting"
                                  ],
                   "recite":  [
                                  "repeataloud"
                              ],
                   "reclaim":  [
                                   "recover"
                               ],
                   "recognisable":  [
                                        "identifiable"
                                    ],
                   "recognise":  [
                                     "identify"
                                 ],
                   "recognition":  [
                                       "identification"
                                   ],
                   "recognize":  [
                                     "identify"
                                 ],
                   "recollect":  [
                                     "remember"
                                 ],
                   "recommend":  [
                                     "suggest"
                                 ],
                   "reconciliation":  [
                                          "settlement"
                                      ],
                   "reconnect":  [
                                     "linkagain"
                                 ],
                   "reconstruct":  [
                                       "rebuild"
                                   ],
                   "record":  [
                                  "document"
                              ],
                   "recover":  [
                                   "regain"
                               ],
                   "recreate":  [
                                    "reproduce"
                                ],
                   "recruit":  [
                                   "enlist"
                               ],
                   "rectory":  [
                                   "parsonage"
                               ],
                   "recur":  [
                                 "repeat"
                             ],
                   "recurrent":  [
                                     "repeated"
                                 ],
                   "recursion":  [
                                     "self-reference"
                                 ],
                   "recursive":  [
                                     "self-referential"
                                 ],
                   "recyclable":  [
                                      "reusable"
                                  ],
                   "recycle":  [
                                   "reuse"
                               ],
                   "redeem":  [
                                  "recovervalue"
                              ],
                   "redevelop":  [
                                     "renovate"
                                 ],
                   "redevelopment":  [
                                         "renovation"
                                     ],
                   "redirect":  [
                                    "divert"
                                ],
                   "redirection":  [
                                       "diversion"
                                   ],
                   "redistribute":  [
                                        "reallocate"
                                    ],
                   "redistribution":  [
                                          "reallocation"
                                      ],
                   "reduce":  [
                                  "decrease"
                              ],
                   "reducible":  [
                                     "simplifiable"
                                 ],
                   "reduction":  [
                                     "decrease"
                                 ],
                   "redundancy":  [
                                      "unnecessariness"
                                  ],
                   "refer":  [
                                 "mention"
                             ],
                   "reference":  [
                                     "citation"
                                 ],
                   "referral":  [
                                    "recommendation"
                                ],
                   "refill":  [
                                  "replenish"
                              ],
                   "refine":  [
                                  "improve"
                              ],
                   "refinement":  [
                                      "improvement"
                                  ],
                   "refinery":  [
                                    "processingplant"
                                ],
                   "reflection":  [
                                      "consideration"
                                  ],
                   "reflex":  [
                                  "automaticresponse"
                              ],
                   "reflexive":  [
                                     "self-referential"
                                 ],
                   "reforest":  [
                                    "planttreesagain"
                                ],
                   "reforestation":  [
                                         "treereplanting"
                                     ],
                   "reform":  [
                                  "change"
                              ],
                   "refuge":  [
                                  "shelter"
                              ],
                   "refugee":  [
                                   "displacedperson"
                               ],
                   "refusal":  [
                                   "rejection"
                               ],
                   "refuse":  [
                                  "reject"
                              ],
                   "refutable":  [
                                     "disprovable"
                                 ],
                   "refutation":  [
                                      "disproof"
                                  ],
                   "refute":  [
                                  "disprove"
                              ],
                   "regard":  [
                                  "consider"
                              ],
                   "regenerate":  [
                                      "renew"
                                  ],
                   "regime":  [
                                  "system"
                              ],
                   "regimen":  [
                                   "routine"
                               ],
                   "register":  [
                                    "record"
                                ],
                   "registrar":  [
                                     "recordofficer"
                                 ],
                   "registration":  [
                                        "enrolment"
                                    ],
                   "registry":  [
                                    "recordsystem"
                                ],
                   "regress":  [
                                   "decline"
                               ],
                   "regression":  [
                                      "decline"
                                  ],
                   "regroup":  [
                                   "reorganize"
                               ],
                   "regular":  [
                                   "routine"
                               ],
                   "regularity":  [
                                      "consistency"
                                  ],
                   "regulate":  [
                                    "control"
                                ],
                   "regulation":  [
                                      "rule"
                                  ],
                   "rehabilitate":  [
                                        "restore"
                                    ],
                   "rehabilitation":  [
                                          "restoration"
                                      ],
                   "rehabilitative":  [
                                          "restorative"
                                      ],
                   "reimburse":  [
                                     "repay"
                                 ],
                   "reimbursement":  [
                                         "repayment"
                                     ],
                   "reinforce":  [
                                     "strengthen"
                                 ],
                   "reinforcement":  [
                                         "strengthening"
                                     ],
                   "reintroduce":  [
                                       "bringback"
                                   ],
                   "reinvent":  [
                                    "recreate"
                                ],
                   "reject":  [
                                  "refuse"
                              ],
                   "rekindle":  [
                                    "revive"
                                ],
                   "relation":  [
                                    "connection"
                                ],
                   "relative":  [
                                    "comparative"
                                ],
                   "relativity":  [
                                      "comparativeness"
                                  ],
                   "relay":  [
                                 "transmit"
                             ],
                   "release":  [
                                   "free"
                               ],
                   "relegate":  [
                                    "downgrade"
                                ],
                   "relevant":  [
                                    "related"
                                ],
                   "reliability":  [
                                       "dependability"
                                   ],
                   "reliable":  [
                                    "dependable"
                                ],
                   "reliably":  [
                                    "dependably"
                                ],
                   "relic":  [
                                 "remnant"
                             ],
                   "relict":  [
                                  "survivor"
                              ],
                   "relief":  [
                                  "alleviation"
                              ],
                   "religion":  [
                                    "faith"
                                ],
                   "religious":  [
                                     "faith-based"
                                 ],
                   "relocate":  [
                                    "move"
                                ],
                   "rely":  [
                                "depend"
                            ],
                   "remand":  [
                                  "detain"
                              ],
                   "remark":  [
                                  "comment"
                              ],
                   "remarkable":  [
                                      "notable"
                                  ],
                   "remarkably":  [
                                      "notably"
                                  ],
                   "remonstrate":  [
                                       "protest"
                                   ],
                   "remote":  [
                                  "distant"
                              ],
                   "remoteness":  [
                                      "distance"
                                  ],
                   "remove":  [
                                  "eliminate"
                              ],
                   "renaissance":  [
                                       "revival"
                                   ],
                   "render":  [
                                  "make"
                              ],
                   "renew":  [
                                 "restore"
                             ],
                   "renewable":  [
                                     "sustainable"
                                 ],
                   "renewal":  [
                                   "restoration"
                               ],
                   "renounce":  [
                                    "giveup"
                                ],
                   "renovate":  [
                                    "restore"
                                ],
                   "renovation":  [
                                      "restoration"
                                  ],
                   "repackage":  [
                                     "reframe"
                                 ],
                   "repeat":  [
                                  "recur"
                              ],
                   "repeatedly":  [
                                      "againandagain"
                                  ],
                   "repetition":  [
                                      "recurrence"
                                  ],
                   "replace":  [
                                   "substitute"
                               ],
                   "replaceable":  [
                                       "substitutable"
                                   ],
                   "replacement":  [
                                       "substitute"
                                   ],
                   "replay":  [
                                  "playagain"
                              ],
                   "replenish":  [
                                     "refill"
                                 ],
                   "replicable":  [
                                      "repeatable"
                                  ],
                   "replicate":  [
                                     "reproduce"
                                 ],
                   "replication":  [
                                       "reproduction"
                                   ],
                   "reply":  [
                                 "respond"
                             ],
                   "reportage":  [
                                     "journalism"
                                 ],
                   "reporting":  [
                                     "coverage"
                                 ],
                   "represent":  [
                                     "standfor"
                                 ],
                   "representation":  [
                                          "portrayal"
                                      ],
                   "representational":  [
                                            "depictive"
                                        ],
                   "representative":  [
                                          "delegate"
                                      ],
                   "reprieve":  [
                                    "postponement"
                                ],
                   "reproduce":  [
                                     "copy"
                                 ],
                   "reproduction":  [
                                        "copying"
                                    ],
                   "reproductive":  [
                                        "breeding"
                                    ],
                   "reptile":  [
                                   "cold-bloodedanimal"
                               ],
                   "repulsive":  [
                                     "disgusting"
                                 ],
                   "request":  [
                                   "askfor"
                               ],
                   "require":  [
                                   "need"
                               ],
                   "reschedule":  [
                                      "rearrange"
                                  ],
                   "researcher":  [
                                      "scholar"
                                  ],
                   "resemblance":  [
                                       "similarity"
                                   ],
                   "resemble":  [
                                    "looklike"
                                ],
                   "resentment":  [
                                      "bitterness"
                                  ],
                   "reservation":  [
                                       "booking"
                                   ],
                   "reserve":  [
                                   "keep"
                               ],
                   "reservoir":  [
                                     "waterstore"
                                 ],
                   "reshape":  [
                                   "transform"
                               ],
                   "reside":  [
                                  "live"
                              ],
                   "residence":  [
                                     "dwelling"
                                 ],
                   "residential":  [
                                       "housing-related"
                                   ],
                   "residual":  [
                                    "remaining"
                                ],
                   "residue":  [
                                   "remainder"
                               ],
                   "resilience":  [
                                      "toughness"
                                  ],
                   "resilient":  [
                                     "tough"
                                 ],
                   "resist":  [
                                  "oppose"
                              ],
                   "resistance":  [
                                      "opposition"
                                  ],
                   "resolution":  [
                                      "settlement"
                                  ],
                   "resonance":  [
                                     "echo"
                                 ],
                   "resource":  [
                                    "asset"
                                ],
                   "resourceful":  [
                                       "inventive"
                                   ],
                   "respiration":  [
                                       "breathing"
                                   ],
                   "respire":  [
                                   "breathe"
                               ],
                   "respond":  [
                                   "reply"
                               ],
                   "response":  [
                                    "reaction"
                                ],
                   "responsibility":  [
                                          "duty"
                                      ],
                   "responsible":  [
                                       "accountable"
                                   ],
                   "responsibly":  [
                                       "accountably"
                                   ],
                   "restoration":  [
                                       "recovery"
                                   ],
                   "restorative":  [
                                       "healing"
                                   ],
                   "restore":  [
                                   "recover"
                               ],
                   "restrain":  [
                                    "limit"
                                ],
                   "restraint":  [
                                     "control"
                                 ],
                   "restrict":  [
                                    "limit"
                                ],
                   "restriction":  [
                                       "limitation"
                                   ],
                   "restrictive":  [
                                       "limiting"
                                   ],
                   "restructure":  [
                                       "reorganise"
                                   ],
                   "retail":  [
                                  "selling"
                              ],
                   "retain":  [
                                  "keep"
                              ],
                   "retention":  [
                                     "keeping"
                                 ],
                   "retirement":  [
                                      "withdrawal"
                                  ],
                   "retranslate":  [
                                       "translateagain"
                                   ],
                   "retreat":  [
                                   "withdraw"
                               ],
                   "retrieval":  [
                                     "recovery"
                                 ],
                   "retrieve":  [
                                    "recover"
                                ],
                   "return":  [
                                  "comeback"
                              ],
                   "reveal":  [
                                  "disclose"
                              ],
                   "revelation":  [
                                      "disclosure"
                                  ],
                   "revenue":  [
                                   "income"
                               ],
                   "reverse":  [
                                   "invert"
                               ],
                   "revision":  [
                                    "modification"
                                ],
                   "revival":  [
                                   "renewal"
                               ],
                   "revive":  [
                                  "renew"
                              ],
                   "revolution":  [
                                      "upheaval"
                                  ],
                   "revolutionary":  [
                                         "radical"
                                     ],
                   "rewrite":  [
                                   "revise"
                               ],
                   "ridge":  [
                                 "crest"
                             ],
                   "rift":  [
                                "split"
                            ],
                   "ring":  [
                                "circle"
                            ],
                   "ritual":  [
                                  "ceremony"
                              ],
                   "ritualise":  [
                                     "formalise"
                                 ],
                   "rival":  [
                                 "competitor"
                             ],
                   "rivalrous":  [
                                     "competitive"
                                 ],
                   "river":  [
                                 "waterway"
                             ],
                   "road":  [
                                "route"
                            ],
                   "rodent":  [
                                  "gnawingmammal"
                              ],
                   "roll":  [
                                "list"
                            ],
                   "romance":  [
                                   "lovestory"
                               ],
                   "romantic":  [
                                    "idealistic"
                                ],
                   "rotary":  [
                                  "rotation"
                              ],
                   "rotation":  [
                                    "turning"
                                ],
                   "royal":  [
                                 "monarchical"
                             ],
                   "rule":  [
                                "regulation"
                            ],
                   "safety":  [
                                  "security"
                              ],
                   "sail":  [
                                "navigate"
                            ],
                   "salinity":  [
                                    "saltiness"
                                ],
                   "sample":  [
                                  "specimen"
                              ],
                   "sand":  [
                                "grit"
                            ],
                   "satellite":  [
                                     "orbiter"
                                 ],
                   "satirise":  [
                                    "mock"
                                ],
                   "satirist":  [
                                    "mockingwriter"
                                ],
                   "scapegoat":  [
                                     "fallguy"
                                 ],
                   "scarcity":  [
                                    "shortage"
                                ],
                   "schedule":  [
                                    "timetable"
                                ],
                   "scholar":  [
                                   "academic"
                               ],
                   "school":  [
                                  "institution"
                              ],
                   "science":  [
                                   "knowledgesystem"
                               ],
                   "scientific":  [
                                      "evidence-based"
                                  ],
                   "scientist":  [
                                     "researcher"
                                 ],
                   "scourge":  [
                                   "affliction"
                               ],
                   "screen":  [
                                  "display"
                              ],
                   "scrutiny":  [
                                    "examination"
                                ],
                   "search":  [
                                  "lookfor"
                              ],
                   "seasonal":  [
                                    "periodic"
                                ],
                   "sediment":  [
                                    "deposit"
                                ],
                   "sedimentary":  [
                                       "deposit-based"
                                   ],
                   "seed":  [
                                "origin"
                            ],
                   "segment":  [
                                   "section"
                               ],
                   "selection":  [
                                     "choice"
                                 ],
                   "selective":  [
                                     "choosy"
                                 ],
                   "semantic":  [
                                    "meaning-related"
                                ],
                   "sense":  [
                                 "meaning"
                             ],
                   "sensitivity":  [
                                       "responsiveness"
                                   ],
                   "separation":  [
                                      "division"
                                  ],
                   "sequence":  [
                                    "order"
                                ],
                   "series":  [
                                  "sequence"
                              ],
                   "serious":  [
                                   "grave"
                               ],
                   "seriousness":  [
                                       "grave"
                                   ],
                   "settlement":  [
                                      "resolution"
                                  ],
                   "seventysecond":  [
                                         "twenty"
                                     ],
                   "sever":  [
                                 "serious"
                             ],
                   "severe":  [
                                  "serious"
                              ],
                   "severeness":  [
                                      "serious"
                                  ],
                   "severity":  [
                                    "seriousness"
                                ],
                   "shift":  [
                                 "change"
                             ],
                   "significance":  [
                                        "importance"
                                    ],
                   "significant":  [
                                       "important"
                                   ],
                   "simulate":  [
                                    "imitate"
                                ],
                   "simulation":  [
                                      "model"
                                  ],
                   "simultaneous":  [
                                        "concurrent"
                                    ],
                   "skeleton":  [
                                    "bonestructure"
                                ],
                   "smash":  [
                                 "break"
                             ],
                   "social":  [
                                  "communal"
                              ],
                   "society":  [
                                   "community"
                               ],
                   "sociologist":  [
                                       "socialscientist"
                                   ],
                   "solar":  [
                                 "sun-related"
                             ],
                   "solution":  [
                                    "answer"
                                ],
                   "sort":  [
                                "classify"
                            ],
                   "source":  [
                                  "origin"
                              ],
                   "species":  [
                                   "kind"
                               ],
                   "specimen":  [
                                    "sample"
                                ],
                   "spectrum":  [
                                    "range"
                                ],
                   "sphere":  [
                                  "domain"
                              ],
                   "spherical":  [
                                     "round"
                                 ],
                   "spiral":  [
                                  "coil"
                              ],
                   "spur":  [
                                "stimulus"
                            ],
                   "stable":  [
                                  "steady"
                              ],
                   "standard":  [
                                    "criterion"
                                ],
                   "starvation":  [
                                      "famine"
                                  ],
                   "statistical":  [
                                       "quantitative"
                                   ],
                   "stimulus":  [
                                    "trigger"
                                ],
                   "strategy":  [
                                    "plan"
                                ],
                   "stretch":  [
                                   "extend"
                               ],
                   "strip":  [
                                 "remove"
                             ],
                   "structuralism":  [
                                         "systemtheory"
                                     ],
                   "structuralist":  [
                                         "systemicthinker"
                                     ],
                   "structure":  [
                                     "framework"
                                 ],
                   "study":  [
                                 "research"
                             ],
                   "stuff":  [
                                 "material"
                             ],
                   "subjectivity":  [
                                        "subjective"
                                    ],
                   "substance":  [
                                     "material"
                                 ],
                   "substantial":  [
                                       "considerable"
                                   ],
                   "sufficient":  [
                                      "adequate"
                                  ],
                   "superstructure":  [
                                          "upperstructure"
                                      ],
                   "surgical":  [
                                    "clinical"
                                ],
                   "sustainable":  [
                                       "renewable"
                                   ],
                   "switch":  [
                                  "change"
                              ],
                   "symbol":  [
                                  "sign"
                              ],
                   "synchronise":  [
                                       "coordinate"
                                   ],
                   "synthesise":  [
                                      "combine"
                                  ],
                   "system":  [
                                  "structure"
                              ],
                   "tactile":  [
                                   "touch-related"
                               ],
                   "tangibility":  [
                                       "concreteness"
                                   ],
                   "tangible":  [
                                    "concrete"
                                ],
                   "tangibly":  [
                                    "concretely"
                                ],
                   "targeting":  [
                                     "aiming"
                                 ],
                   "tautological":  [
                                        "circular"
                                    ],
                   "tautology":  [
                                     "circularity"
                                 ],
                   "tax":  [
                               "levy"
                           ],
                   "taxation":  [
                                    "levying"
                                ],
                   "taxonomic":  [
                                     "classification-related"
                                 ],
                   "taxonomy":  [
                                    "classification"
                                ],
                   "teaching":  [
                                    "instruction"
                                ],
                   "technician":  [
                                      "specialist"
                                  ],
                   "technological":  [
                                         "technical"
                                     ],
                   "tectonic":  [
                                    "crustal"
                                ],
                   "telecommunication":  [
                                             "long-distancecommunication"
                                         ],
                   "television":  [
                                      "broadcasting"
                                  ],
                   "temperament":  [
                                       "disposition"
                                   ],
                   "temperamental":  [
                                         "moody"
                                     ],
                   "temperate":  [
                                     "mild"
                                 ],
                   "temperature":  [
                                       "heatlevel"
                                   ],
                   "template":  [
                                    "model"
                                ],
                   "temporal":  [
                                    "time-related"
                                ],
                   "temporality":  [
                                       "timequality"
                                   ],
                   "temporariness":  [
                                         "short-termnature"
                                     ],
                   "temporary":  [
                                     "short-term"
                                 ],
                   "tendency":  [
                                    "inclination"
                                ],
                   "tensile":  [
                                   "stretching"
                               ],
                   "tension":  [
                                   "strain"
                               ],
                   "tenuity":  [
                                   "thinness"
                               ],
                   "tenuous":  [
                                   "weak"
                               ],
                   "term":  [
                                "expression"
                            ],
                   "terminable":  [
                                      "endable"
                                  ],
                   "terminal":  [
                                    "final"
                                ],
                   "terminate":  [
                                     "end"
                                 ],
                   "termination":  [
                                       "ending"
                                   ],
                   "terminology":  [
                                       "vocabulary"
                                   ],
                   "terrain":  [
                                   "landscape"
                               ],
                   "terrestrial":  [
                                       "land-based"
                                   ],
                   "territorial":  [
                                       "land-related"
                                   ],
                   "territoriality":  [
                                          "territorybehaviour"
                                      ],
                   "territory":  [
                                     "land"
                                 ],
                   "terror":  [
                                  "fear"
                              ],
                   "tertiary":  [
                                    "third-level"
                                ],
                   "testify":  [
                                   "witness"
                               ],
                   "testimony":  [
                                     "evidence"
                                 ],
                   "textile":  [
                                   "fabric"
                               ],
                   "textual":  [
                                   "text-related"
                               ],
                   "textural":  [
                                    "texture-related"
                                ],
                   "texture":  [
                                   "surfacequality"
                               ],
                   "theatre":  [
                                   "stage"
                               ],
                   "theological":  [
                                       "religious"
                                   ],
                   "theology":  [
                                    "religiousstudy"
                                ],
                   "theorem":  [
                                   "principle"
                               ],
                   "theoretical":  [
                                       "conceptual"
                                   ],
                   "theorist":  [
                                    "thinker"
                                ],
                   "theory":  [
                                  "framework"
                              ],
                   "therapeutic":  [
                                       "healing"
                                   ],
                   "therapy":  [
                                   "treatment"
                               ],
                   "thermal":  [
                                   "heat-related"
                               ],
                   "thermodynamic":  [
                                         "heat-energy"
                                     ],
                   "thermometer":  [
                                       "temperaturegauge"
                                   ],
                   "thermostat":  [
                                      "temperaturecontroller"
                                  ],
                   "thesis":  [
                                  "argument"
                              ],
                   "thin":  [
                                "slight"
                            ],
                   "thorough":  [
                                    "complete"
                                ],
                   "thread":  [
                                  "strand"
                              ],
                   "threshold":  [
                                     "limit"
                                 ],
                   "throughput":  [
                                      "processingrate"
                                  ],
                   "tilt":  [
                                "slant"
                            ],
                   "timeline":  [
                                    "chronology"
                                ],
                   "title":  [
                                 "heading"
                             ],
                   "tolerance":  [
                                     "acceptance"
                                 ],
                   "tolerate":  [
                                    "endure"
                                ],
                   "topographic":  [
                                       "terrain-related"
                                   ],
                   "topography":  [
                                      "terrainform"
                                  ],
                   "topology":  [
                                    "spatialstructure"
                                ],
                   "torture":  [
                                   "torment"
                               ],
                   "totem":  [
                                 "symbol"
                             ],
                   "totemic":  [
                                   "symbolic"
                               ],
                   "tract":  [
                                 "region"
                             ],
                   "trade":  [
                                 "commerce"
                             ],
                   "tradition":  [
                                     "custom"
                                 ],
                   "traditional":  [
                                       "conventional"
                                   ],
                   "traffic":  [
                                   "flow"
                               ],
                   "train":  [
                                 "teach"
                             ],
                   "trait":  [
                                 "feature"
                             ],
                   "trajectory":  [
                                      "path"
                                  ],
                   "transaction":  [
                                       "exchange"
                                   ],
                   "transcend":  [
                                     "gobeyond"
                                 ],
                   "transcontinental":  [
                                            "cross-continental"
                                        ],
                   "transcribe":  [
                                      "writedown"
                                  ],
                   "transcription":  [
                                         "writtenrecord"
                                     ],
                   "transfer":  [
                                    "move"
                                ],
                   "transform":  [
                                     "change"
                                 ],
                   "transformation":  [
                                          "change"
                                      ],
                   "transformative":  [
                                          "change-making"
                                      ],
                   "transgender":  [
                                       "gender-diverse"
                                   ],
                   "transistor":  [
                                      "electronicswitch"
                                  ],
                   "transit":  [
                                   "transport"
                               ],
                   "transition":  [
                                      "shift"
                                  ],
                   "transitory":  [
                                      "temporary"
                                  ],
                   "translation":  [
                                       "rendering"
                                   ],
                   "transliterate":  [
                                         "transcribe"
                                     ],
                   "translucence":  [
                                        "semi-transparency"
                                    ],
                   "translucent":  [
                                       "semi-transparent"
                                   ],
                   "transmission":  [
                                        "transfer"
                                    ],
                   "transmit":  [
                                    "send"
                                ],
                   "transmitter":  [
                                       "sender"
                                   ],
                   "transparency":  [
                                        "openness"
                                    ],
                   "transparent":  [
                                       "clear"
                                   ],
                   "transport":  [
                                     "conveyance"
                                 ],
                   "transportable":  [
                                         "movable"
                                     ],
                   "transportation":  [
                                          "conveyance"
                                      ],
                   "travel":  [
                                  "journey"
                              ],
                   "traveller":  [
                                     "passenger"
                                 ],
                   "traverse":  [
                                    "cross"
                                ],
                   "treacherous":  [
                                       "dangerous"
                                   ],
                   "treacherousness":  [
                                           "dangerousness"
                                       ],
                   "treachery":  [
                                     "betrayal"
                                 ],
                   "treason":  [
                                   "betrayal"
                               ],
                   "treatise":  [
                                    "essay"
                                ],
                   "treatment":  [
                                     "therapy"
                                 ],
                   "treaty":  [
                                  "agreement"
                              ],
                   "trench":  [
                                  "ditch"
                              ],
                   "trial":  [
                                 "test"
                             ],
                   "triangular":  [
                                      "three-sided"
                                  ],
                   "tribal":  [
                                  "clan-based"
                              ],
                   "tribe":  [
                                 "clan"
                             ],
                   "tribunal":  [
                                    "court"
                                ],
                   "tributary":  [
                                     "branchriver"
                                 ],
                   "tribute":  [
                                   "honour"
                               ],
                   "trick":  [
                                 "deception"
                             ],
                   "trickle":  [
                                   "drip"
                               ],
                   "trigger":  [
                                   "cause"
                               ],
                   "triumph":  [
                                   "victory"
                               ],
                   "triumphal":  [
                                     "victorious"
                                 ],
                   "triumphant":  [
                                      "victorious"
                                  ],
                   "trivial":  [
                                   "minor"
                               ],
                   "trivialize":  [
                                      "downplay"
                                  ],
                   "trophic":  [
                                   "nutrition-related"
                               ],
                   "tropical":  [
                                    "equatorial"
                                ],
                   "troposphere":  [
                                       "loweratmosphere"
                                   ],
                   "tropospheric":  [
                                        "lower-atmosphere"
                                    ],
                   "trunk":  [
                                 "mainstem"
                             ],
                   "tsunami":  [
                                   "tidalwave"
                               ],
                   "tuber":  [
                                 "rootvegetables"
                             ],
                   "tuberculosis":  [
                                        "tb"
                                    ],
                   "tundra":  [
                                  "coldplain"
                              ],
                   "turbine":  [
                                   "rotaryengine"
                               ],
                   "turbulence":  [
                                      "instability"
                                  ],
                   "type":  [
                                "category"
                            ],
                   "typography":  [
                                      "typedesign"
                                  ],
                   "ultimacy":  [
                                    "finality"
                                ],
                   "ultimate":  [
                                    "final"
                                ],
                   "ultimatum":  [
                                     "finaldemand"
                                 ],
                   "ultraviolet":  [
                                       "violet-adjacent"
                                   ],
                   "umbrella":  [
                                    "cover"
                                ],
                   "unable":  [
                                  "incapable"
                              ],
                   "unaided":  [
                                   "unsupported"
                               ],
                   "unambiguous":  [
                                       "clear"
                                   ],
                   "unanimous":  [
                                     "fullyagreed"
                                 ],
                   "unannounced":  [
                                       "unexpected"
                                   ],
                   "unarmed":  [
                                   "defenceless"
                               ],
                   "unavoidable":  [
                                       "inevitable"
                                   ],
                   "unavoidably":  [
                                       "inevitably"
                                   ],
                   "unbiased":  [
                                    "impartial"
                                ],
                   "uncertain":  [
                                     "unsure"
                                 ],
                   "uncertainty":  [
                                       "doubt"
                                   ],
                   "unchecked":  [
                                     "unrestrained"
                                 ],
                   "unclear":  [
                                   "ambiguous"
                               ],
                   "uncomfortable":  [
                                         "uneasy"
                                     ],
                   "unconscious":  [
                                       "unaware"
                                   ],
                   "unconstrained":  [
                                         "unrestricted"
                                     ],
                   "unconventional":  [
                                          "unorthodox"
                                      ],
                   "unconventionality":  [
                                             "unorthodoxy"
                                         ],
                   "undamaged":  [
                                     "intact"
                                 ],
                   "underestimate":  [
                                         "undervalue"
                                     ],
                   "undergo":  [
                                   "experience"
                               ],
                   "undergraduate":  [
                                         "collegestudent"
                                     ],
                   "underground":  [
                                       "subterranean"
                                   ],
                   "underlie":  [
                                    "support"
                                ],
                   "underlying":  [
                                      "basic"
                                  ],
                   "undermine":  [
                                     "weaken"
                                 ],
                   "underminer":  [
                                      "weakener"
                                  ],
                   "underrepresented":  [
                                            "marginalised"
                                        ],
                   "understand":  [
                                      "comprehend"
                                  ],
                   "understandable":  [
                                          "comprehensible"
                                      ],
                   "unemployed":  [
                                      "jobless"
                                  ],
                   "unemployment":  [
                                        "joblessness"
                                    ],
                   "unequal":  [
                                   "inequitable"
                               ],
                   "unethical":  [
                                     "immoral"
                                 ],
                   "unexceptional":  [
                                         "ordinary"
                                     ],
                   "unfair":  [
                                  "unjust"
                              ],
                   "unfairness":  [
                                      "injustice"
                                  ],
                   "unfashionable":  [
                                         "outdated"
                                     ],
                   "unfeasible":  [
                                      "impractical"
                                  ],
                   "unhealthy":  [
                                     "harmful"
                                 ],
                   "unification":  [
                                       "integration"
                                   ],
                   "uniform":  [
                                   "consistent"
                               ],
                   "unify":  [
                                 "integrate"
                             ],
                   "unimaginable":  [
                                        "inconceivable"
                                    ],
                   "uninhabitable":  [
                                         "unlivable"
                                     ],
                   "unintelligible":  [
                                          "incomprehensible"
                                      ],
                   "unique":  [
                                  "distinctive"
                              ],
                   "uniqueness":  [
                                      "distinctiveness"
                                  ],
                   "universal":  [
                                     "general"
                                 ],
                   "universe":  [
                                    "cosmos"
                                ],
                   "unorthodox":  [
                                      "unconventional"
                                  ],
                   "unprecedented":  [
                                         "unmatched"
                                     ],
                   "unpredictable":  [
                                         "uncertain"
                                     ],
                   "unprocessed":  [
                                       "raw"
                                   ],
                   "unqualified":  [
                                       "ineligible"
                                   ],
                   "unremarkable":  [
                                        "ordinary"
                                    ],
                   "unstable":  [
                                    "unsteady"
                                ],
                   "unsteady":  [
                                    "unstable"
                                ],
                   "untouched":  [
                                     "pristine"
                                 ],
                   "unwieldiness":  [
                                        "cumbersomeness"
                                    ],
                   "unwieldy":  [
                                    "cumbersome"
                                ],
                   "update":  [
                                  "revise"
                              ],
                   "upgrade":  [
                                   "improve"
                               ],
                   "upheaval":  [
                                    "disruption"
                                ],
                   "uprising":  [
                                    "revolt"
                                ],
                   "upwell":  [
                                  "upwardflow"
                              ],
                   "urban":  [
                                 "city-based"
                             ],
                   "urbanisation":  [
                                        "citygrowth"
                                    ],
                   "urbanism":  [
                                    "citylife"
                                ],
                   "urbanization":  [
                                        "citygrowth"
                                    ],
                   "urbanize":  [
                                    "makeurban"
                                ],
                   "urge":  [
                                "impulse"
                            ],
                   "urgency":  [
                                   "pressingneed"
                               ],
                   "urgent":  [
                                  "pressing"
                              ],
                   "useful":  [
                                  "helpful"
                              ],
                   "utilisation":  [
                                       "use"
                                   ],
                   "utilise":  [
                                   "use"
                               ],
                   "utilitarian":  [
                                       "usefulness-based"
                                   ],
                   "utilitarianism":  [
                                          "usefulnessdoctrine"
                                      ],
                   "utility":  [
                                   "usefulness"
                               ],
                   "utilization":  [
                                       "use"
                                   ],
                   "utilize":  [
                                   "use"
                               ],
                   "utterly":  [
                                   "completely"
                               ],
                   "vaccinate":  [
                                     "immunize"
                                 ],
                   "vaccination":  [
                                       "immunization"
                                   ],
                   "vaccine":  [
                                   "immunizationagent"
                               ],
                   "vague":  [
                                 "unclear"
                             ],
                   "valid":  [
                                 "legitimate"
                             ],
                   "validate":  [
                                    "confirm"
                                ],
                   "validation":  [
                                      "confirmation"
                                  ],
                   "validity":  [
                                    "soundness"
                                ],
                   "valuable":  [
                                    "precious"
                                ],
                   "valuation":  [
                                     "assessment"
                                 ],
                   "value":  [
                                 "worth"
                             ],
                   "vanguard":  [
                                    "frontline"
                                ],
                   "vanity":  [
                                  "conceit"
                              ],
                   "vapourize":  [
                                     "evaporate"
                                 ],
                   "variable":  [
                                    "factor"
                                ],
                   "variance":  [
                                    "variation"
                                ],
                   "variation":  [
                                     "difference"
                                 ],
                   "variety":  [
                                   "diversity"
                               ],
                   "vary":  [
                                "differ"
                            ],
                   "vascular":  [
                                    "blood-vessel"
                                ],
                   "vegetation":  [
                                      "plantlife"
                                  ],
                   "vegetative":  [
                                      "plant-related"
                                  ],
                   "vehicle":  [
                                   "transport"
                               ],
                   "velocity":  [
                                    "speed"
                                ],
                   "venom":  [
                                 "poison"
                             ],
                   "venomous":  [
                                    "poisonous"
                                ],
                   "ventilate":  [
                                     "air"
                                 ],
                   "ventilation":  [
                                       "airflow"
                                   ],
                   "ventilator":  [
                                      "ventilate"
                                  ],
                   "verb":  [
                                "actionword"
                            ],
                   "verbal":  [
                                  "spoken"
                              ],
                   "verdict":  [
                                   "judgement"
                               ],
                   "verge":  [
                                 "edge"
                             ],
                   "verification":  [
                                        "confirmation"
                                    ],
                   "verify":  [
                                  "confirm"
                              ],
                   "verity":  [
                                  "truth"
                              ],
                   "vernacular":  [
                                      "colloquial"
                                  ],
                   "versatile":  [
                                     "adaptable"
                                 ],
                   "versatility":  [
                                       "adaptability"
                                   ],
                   "version":  [
                                   "variant"
                               ],
                   "vertebrate":  [
                                      "backbonedanimal"
                                  ],
                   "vertex":  [
                                  "peak"
                              ],
                   "vertical":  [
                                    "upright"
                                ],
                   "verticality":  [
                                       "uprightness"
                                   ],
                   "vessel":  [
                                  "container"
                              ],
                   "vestige":  [
                                   "trace"
                               ],
                   "viability":  [
                                     "feasibility"
                                 ],
                   "viable":  [
                                  "feasible"
                              ],
                   "viably":  [
                                  "feasibly"
                              ],
                   "vibration":  [
                                     "oscillation"
                                 ],
                   "victory":  [
                                   "triumph"
                               ],
                   "viewpoint":  [
                                     "perspective"
                                 ],
                   "vigil":  [
                                 "watch"
                             ],
                   "violate":  [
                                   "infringe"
                               ],
                   "violation":  [
                                     "breach"
                                 ],
                   "violator":  [
                                    "offender"
                                ],
                   "violence":  [
                                    "force"
                                ],
                   "violent":  [
                                   "aggressive"
                               ],
                   "virtual":  [
                                   "digital"
                               ],
                   "virtualisation":  [
                                          "digitalization"
                                      ],
                   "virtuality":  [
                                      "digitalexistence"
                                  ],
                   "virtualization":  [
                                          "digitalization"
                                      ],
                   "virtualize":  [
                                      "makedigital"
                                  ],
                   "virtue":  [
                                  "moralexcellence"
                              ],
                   "virtuosity":  [
                                      "mastery"
                                  ],
                   "virtuous":  [
                                    "moral"
                                ],
                   "viscosity":  [
                                     "thickness"
                                 ],
                   "viscous":  [
                                   "thick"
                               ],
                   "visible":  [
                                   "noticeable"
                               ],
                   "vision":  [
                                  "sight"
                              ],
                   "visionary":  [
                                     "imaginative"
                                 ],
                   "visual":  [
                                  "sight-related"
                              ],
                   "vital":  [
                                 "essential"
                             ],
                   "vitality":  [
                                    "energy"
                                ],
                   "vocabulary":  [
                                      "lexicon"
                                  ],
                   "vocal":  [
                                 "voice-related"
                             ],
                   "vocation":  [
                                    "calling"
                                ],
                   "void":  [
                                "emptiness"
                            ],
                   "volcanic":  [
                                    "volcano-related"
                                ],
                   "volcanism":  [
                                     "volcanicactivity"
                                 ],
                   "volcano":  [
                                   "firemountain"
                               ],
                   "voltage":  [
                                   "electricpressure"
                               ],
                   "volunteer":  [
                                     "helper"
                                 ],
                   "voracious":  [
                                     "ravenous"
                                 ],
                   "voyage":  [
                                  "journey"
                              ],
                   "voyager":  [
                                   "traveller"
                               ],
                   "vulnerability":  [
                                         "fragility"
                                     ],
                   "vulnerable":  [
                                      "fragile"
                                  ],
                   "vulnerably":  [
                                      "fragilely"
                                  ],
                   "wade":  [
                                "trudge"
                            ],
                   "wage":  [
                                "salary"
                            ],
                   "warn":  [
                                "alert"
                            ],
                   "warnings":  [
                                    "caution"
                                ],
                   "warp":  [
                                "distort"
                            ],
                   "warrant":  [
                                   "justify"
                               ],
                   "wastewater":  [
                                      "effluent"
                                  ],
                   "watershed":  [
                                     "turningpoint"
                                 ],
                   "wave":  [
                                "ripple"
                            ],
                   "wavelength":  [
                                      "wavedistance"
                                  ],
                   "waver":  [
                                 "hesitate"
                             ],
                   "way":  [
                               "method"
                           ],
                   "weak":  [
                                "fragile"
                            ],
                   "weapon":  [
                                  "arm"
                              ],
                   "weather":  [
                                   "erosion"
                               ],
                   "weight":  [
                                  "mass"
                              ],
                   "weighty":  [
                                   "important"
                               ],
                   "welfare":  [
                                   "well-being"
                               ],
                   "wellness":  [
                                    "health"
                                ],
                   "whimsical":  [
                                     "playful"
                                 ],
                   "whole":  [
                                 "entirety"
                             ],
                   "wholehearted":  [
                                        "sincere"
                                    ],
                   "wholeness":  [
                                     "integrity"
                                 ],
                   "wholesale":  [
                                     "large-scale"
                                 ],
                   "wholesome":  [
                                     "healthy"
                                 ],
                   "wholly":  [
                                  "entirely"
                              ],
                   "widespread":  [
                                      "prevalent"
                                  ],
                   "width":  [
                                 "breadth"
                             ],
                   "wield":  [
                                 "use"
                             ],
                   "wild":  [
                                "untamed"
                            ],
                   "wilderness":  [
                                      "wildland"
                                  ],
                   "wildfire":  [
                                    "forestfire"
                                ],
                   "wisdom":  [
                                  "insight"
                              ],
                   "withdraw":  [
                                    "retreat"
                                ],
                   "withstand":  [
                                     "endure"
                                 ],
                   "withstandable":  [
                                         "bearable"
                                     ],
                   "withstood":  [
                                     "endured"
                                 ],
                   "witness":  [
                                   "observer"
                               ],
                   "workplace":  [
                                     "workenvironment"
                                 ],
                   "workshop":  [
                                    "studio"
                                ],
                   "worthy":  [
                                  "deserving"
                              ],
                   "wound":  [
                                 "injury"
                             ],
                   "wrongful":  [
                                    "unjust"
                                ],
                   "xenophobia":  [
                                      "foreignnessfear"
                                  ],
                   "xenophobic":  [
                                      "anti-foreign"
                                  ],
                   "x-ray":  [
                                 "scan"
                             ],
                   "yearn":  [
                                 "long"
                             ],
                   "yield":  [
                                 "produce"
                             ],
                   "zen":  [
                               "meditative"
                           ],
                   "zone":  [
                                "area"
                            ]
               }
};