window.VOCAB_PROPER_SMALL_CARDS_FINAL = {
    "metadata":  {
                     "name":  "PROPER_PLACE_SPECIAL_SMALL_CARD_FINAL_V15_POS",
                     "purpose":  "Small cards for proper/place/culture/special words that should answer reading clicks but do not need family/kin.",
                     "note":  "Person names are not included here; they are removed.",
                     "added_from_v14_small_only":  26,
                     "pos_added":  true,
                     "zh":  "词族关联项；用于连接阅读词和学习词网"
                 },
    "small_cards":  [
                        {
                            "word":  "bering",
                            "zh":  "白令的",
                            "phrases":  [
                                            {
                                                "phrase":  "Bering land bridge",
                                                "phrase_zh":  "白令陆桥"
                                            },
                                            {
                                                "phrase":  "Bering Strait",
                                                "phrase_zh":  "白令海峡"
                                            },
                                            {
                                                "phrase":  "Bering region",
                                                "phrase_zh":  "白令地区"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "crimean",
                            "zh":  "克里米亚的",
                            "phrases":  [
                                            {
                                                "phrase":  "high-value academic context",
                                                "phrase_zh":  "高价值学术语境"
                                            },
                                            {
                                                "phrase":  "Crimean War",
                                                "phrase_zh":  "克里米亚战争"
                                            },
                                            {
                                                "phrase":  "Crimean Peninsula",
                                                "phrase_zh":  "克里米亚半岛"
                                            },
                                            {
                                                "phrase":  "Crimean history",
                                                "phrase_zh":  "克里米亚历史"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "adj."
                        },
                        {
                            "word":  "fallingwater",
                            "zh":  "n./v.",
                            "phrases":  [
                                            {
                                                "phrase":  "fallingwater pattern",
                                                "phrase_zh":  "fallingwater 模式"
                                            },
                                            {
                                                "phrase":  "Fallingwater house",
                                                "phrase_zh":  "流水别墅"
                                            },
                                            {
                                                "phrase":  "Fallingwater design",
                                                "phrase_zh":  "流水别墅设计"
                                            },
                                            {
                                                "phrase":  "Fallingwater architecture",
                                                "phrase_zh":  "流水别墅建筑"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "moai",
                            "zh":  "摩艾石像",
                            "phrases":  [
                                            {
                                                "phrase":  "Easter Island moai",
                                                "phrase_zh":  "复活节岛摩艾石像"
                                            },
                                            {
                                                "phrase":  "carve a moai",
                                                "phrase_zh":  "雕刻摩艾石像"
                                            },
                                            {
                                                "phrase":  "move the moai",
                                                "phrase_zh":  "搬运摩艾石像"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "quipu",
                            "zh":  "奇普；结绳记事",
                            "phrases":  [
                                            {
                                                "phrase":  "Inca quipu",
                                                "phrase_zh":  "印加奇普"
                                            },
                                            {
                                                "phrase":  "quipu knot",
                                                "phrase_zh":  "奇普绳结"
                                            },
                                            {
                                                "phrase":  "record information with quipu",
                                                "phrase_zh":  "用奇普记录信息"
                                            },
                                            {
                                                "phrase":  "ancient quipu",
                                                "phrase_zh":  "古代结绳记事"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "rafflesia",
                            "zh":  "大王花",
                            "phrases":  [
                                            {
                                                "phrase":  "giant rafflesia",
                                                "phrase_zh":  "巨型大王花"
                                            },
                                            {
                                                "phrase":  "rafflesia bloom",
                                                "phrase_zh":  "大王花开花"
                                            },
                                            {
                                                "phrase":  "rafflesia smells like carrion",
                                                "phrase_zh":  "大王花闻起来像腐肉"
                                            },
                                            {
                                                "phrase":  "rafflesia flower",
                                                "phrase_zh":  "大王花"
                                            }
                                        ],
                            "examples":  [
                                             {
                                                 "example":  "A rafflesia flower attracts attention because of its size and unusual biology.",
                                                 "example_zh":  "大王花因其体型和异常生物特性而吸引注意。"
                                             }
                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "samurai",
                            "zh":  "武士",
                            "phrases":  [
                                            {
                                                "phrase":  "Japanese samurai",
                                                "phrase_zh":  "日本武士"
                                            },
                                            {
                                                "phrase":  "samurai code",
                                                "phrase_zh":  "武士准则"
                                            },
                                            {
                                                "phrase":  "samurai sword",
                                                "phrase_zh":  "武士刀"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "turkey",
                            "zh":  "火鸡；土耳其",
                            "phrases":  [
                                            {
                                                "phrase":  "wild turkey",
                                                "phrase_zh":  "野生火鸡"
                                            },
                                            {
                                                "phrase":  "turkey meat",
                                                "phrase_zh":  "火鸡肉"
                                            },
                                            {
                                                "phrase":  "Turkey as a country",
                                                "phrase_zh":  "土耳其国家"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "yang",
                            "zh":  "阳",
                            "phrases":  [
                                            {
                                                "phrase":  "yin and yang",
                                                "phrase_zh":  "阴阳"
                                            },
                                            {
                                                "phrase":  "yang energy",
                                                "phrase_zh":  "阳性能量"
                                            },
                                            {
                                                "phrase":  "yang principle",
                                                "phrase_zh":  "阳的原则"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "yin",
                            "zh":  "阴",
                            "phrases":  [
                                            {
                                                "phrase":  "yin and yang",
                                                "phrase_zh":  "阴阳"
                                            },
                                            {
                                                "phrase":  "yin energy",
                                                "phrase_zh":  "阴性能量"
                                            },
                                            {
                                                "phrase":  "yin principle",
                                                "phrase_zh":  "阴的原则"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "zen",
                            "zh":  "禅；禅宗的；平静专注的",
                            "phrases":  [
                                            {
                                                "phrase":  "Zen practice",
                                                "phrase_zh":  "禅修"
                                            },
                                            {
                                                "phrase":  "Zen garden",
                                                "phrase_zh":  "禅意庭院"
                                            },
                                            {
                                                "phrase":  "Zen calm",
                                                "phrase_zh":  "禅式平静"
                                            }
                                        ],
                            "examples":  [
                                             {
                                                 "example":  "Zen practice values attention not as speed but as presence.",
                                                 "example_zh":  "禅修把注意力看作在场，而不是速度。"
                                             }
                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n./adj."
                        },
                        {
                            "word":  "altiplano",
                            "zh":  "高原；南美高原",
                            "phrases":  [
                                            {
                                                "phrase":  "Bolivian altiplano",
                                                "phrase_zh":  "玻利维亚高原"
                                            },
                                            {
                                                "phrase":  "high altiplano",
                                                "phrase_zh":  "高海拔高原"
                                            },
                                            {
                                                "phrase":  "altiplano climate",
                                                "phrase_zh":  "高原气候"
                                            },
                                            {
                                                "phrase":  "Andean Altiplano",
                                                "phrase_zh":  "安第斯高原"
                                            }
                                        ],
                            "examples":  [
                                             {
                                                 "example":  "The Altiplano climate shapes agriculture, settlement, and transport.",
                                                 "example_zh":  "高原气候会塑造农业、定居和交通。"
                                             }
                                         ],
                            "category":  "proper_place_culture_special",
                            "note":  "Small card only; no family/kin required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "ape",
                            "zh":  "n. 猿",
                            "phrases":  [
                                            {
                                                "phrase":  "ape cognition experiment",
                                                "phrase_zh":  "ape cognition experiment 的语境用法"
                                            },
                                            {
                                                "phrase":  "猿类认知实验",
                                                "phrase_zh":  "猿类认知实验 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word ape appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "blade",
                            "zh":  "刀刃；叶片",
                            "phrases":  [
                                            {
                                                "phrase":  "turbine blade fatigue",
                                                "phrase_zh":  "turbine blade fatigue 的语境用法"
                                            },
                                            {
                                                "phrase":  "涡轮叶片疲劳",
                                                "phrase_zh":  "涡轮叶片疲劳 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word blade appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n./v."
                        },
                        {
                            "word":  "blood",
                            "zh":  "n. 血液",
                            "phrases":  [
                                            {
                                                "phrase":  "blood in academic context",
                                                "phrase_zh":  "blood in academic context 的语境用法"
                                            },
                                            {
                                                "phrase":  "学术语境中的 blood",
                                                "phrase_zh":  "学术语境中的 blood 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word blood appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "dawn",
                            "zh":  "黎明；开端",
                            "phrases":  [
                                            {
                                                "phrase":  "dawn temperature inversion",
                                                "phrase_zh":  "dawn temperature inversion 的语境用法"
                                            },
                                            {
                                                "phrase":  "黎明温度逆温",
                                                "phrase_zh":  "黎明温度逆温 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word dawn appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n./v."
                        },
                        {
                            "word":  "ddt",
                            "zh":  "Dichlorodiphenyltrichloroethane｜二氯二苯三氯乙烷；早期合成杀虫剂",
                            "phrases":  [
                                            {
                                                "phrase":  "Dichlorodiphenyltrichloroethane",
                                                "phrase_zh":  "二氯二苯三氯乙烷；早期合成杀虫剂"
                                            },
                                            {
                                                "phrase":  "DDT pesticide",
                                                "phrase_zh":  "DDT杀虫剂"
                                            },
                                            {
                                                "phrase":  "DDT residue",
                                                "phrase_zh":  "DDT残留"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "dive",
                            "zh":  "v./n. 俯冲；跳水",
                            "phrases":  [
                                            {
                                                "phrase":  "dive in academic context",
                                                "phrase_zh":  "dive in academic context 的语境用法"
                                            },
                                            {
                                                "phrase":  "学术语境中的 dive",
                                                "phrase_zh":  "学术语境中的 dive 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word dive appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "v."
                        },
                        {
                            "word":  "dna",
                            "zh":  "Deoxyribonucleic Acid｜脱氧核糖核酸；遗传物质",
                            "phrases":  [
                                            {
                                                "phrase":  "Deoxyribonucleic Acid",
                                                "phrase_zh":  "脱氧核糖核酸；遗传物质"
                                            },
                                            {
                                                "phrase":  "DNA sequence",
                                                "phrase_zh":  "DNA序列"
                                            },
                                            {
                                                "phrase":  "DNA evidence",
                                                "phrase_zh":  "DNA证据"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "doctor",
                            "zh":  "n. 医生；博士",
                            "phrases":  [
                                            {
                                                "phrase":  "doctor in academic context",
                                                "phrase_zh":  "doctor in academic context 的语境用法"
                                            },
                                            {
                                                "phrase":  "学术语境中的 doctor",
                                                "phrase_zh":  "学术语境中的 doctor 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word doctor appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "go",
                            "zh":  "去；移动",
                            "phrases":  [
                                            {
                                                "phrase":  "go abroad",
                                                "phrase_zh":  "go abroad 的语境用法"
                                            },
                                            {
                                                "phrase":  "出国",
                                                "phrase_zh":  "出国 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word go appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "v."
                        },
                        {
                            "word":  "grey",
                            "zh":  "灰色的",
                            "phrases":  [
                                            {
                                                "phrase":  "grey wolf",
                                                "phrase_zh":  "灰狼"
                                            },
                                            {
                                                "phrase":  "grey area",
                                                "phrase_zh":  "灰色地带"
                                            },
                                            {
                                                "phrase":  "grey sky",
                                                "phrase_zh":  "灰色天空"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "hiv",
                            "zh":  "Human Immunodeficiency Virus｜人类免疫缺陷病毒",
                            "phrases":  [
                                            {
                                                "phrase":  "Human Immunodeficiency Virus",
                                                "phrase_zh":  "人类免疫缺陷病毒"
                                            },
                                            {
                                                "phrase":  "HIV infection",
                                                "phrase_zh":  "HIV感染"
                                            },
                                            {
                                                "phrase":  "HIV transmission",
                                                "phrase_zh":  "HIV传播"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "lithium-ion",
                            "zh":  "adj. 锂离子的",
                            "phrases":  [
                                            {
                                                "phrase":  "lithium-ion in academic context",
                                                "phrase_zh":  "lithium-ion in academic context 的语境用法"
                                            },
                                            {
                                                "phrase":  "学术语境中的 lithium-ion",
                                                "phrase_zh":  "学术语境中的 lithium-ion 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word lithium-ion appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "adj."
                        },
                        {
                            "word":  "map",
                            "zh":  "地图；绘制",
                            "phrases":  [
                                            {
                                                "phrase":  "map genetic variation",
                                                "phrase_zh":  "map genetic variation 的语境用法"
                                            },
                                            {
                                                "phrase":  "绘制遗传变异图",
                                                "phrase_zh":  "绘制遗传变异图 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word map appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n./v."
                        },
                        {
                            "word":  "night",
                            "zh":  "夜晚",
                            "phrases":  [
                                            {
                                                "phrase":  "polar night",
                                                "phrase_zh":  "极夜"
                                            },
                                            {
                                                "phrase":  "long night",
                                                "phrase_zh":  "长夜"
                                            },
                                            {
                                                "phrase":  "night sky",
                                                "phrase_zh":  "夜空"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "poor",
                            "zh":  "adj. 贫穷的",
                            "phrases":  [
                                            {
                                                "phrase":  "poor residents",
                                                "phrase_zh":  "贫困居民"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "adj."
                        },
                        {
                            "word":  "same",
                            "zh":  "相同的",
                            "phrases":  [
                                            {
                                                "phrase":  "same-sex marriage",
                                                "phrase_zh":  "同性婚姻"
                                            },
                                            {
                                                "phrase":  "same rule",
                                                "phrase_zh":  "相同规则"
                                            },
                                            {
                                                "phrase":  "same origin",
                                                "phrase_zh":  "同一来源"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "star",
                            "zh":  "恒星；明星",
                            "phrases":  [
                                            {
                                                "phrase":  "parent star",
                                                "phrase_zh":  "母恒星"
                                            },
                                            {
                                                "phrase":  "bright star",
                                                "phrase_zh":  "明亮恒星"
                                            },
                                            {
                                                "phrase":  "movie star",
                                                "phrase_zh":  "电影明星"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "tube",
                            "zh":  "n. 管；管状物",
                            "phrases":  [
                                            {
                                                "phrase":  "vacuum tube",
                                                "phrase_zh":  "真空管"
                                            },
                                            {
                                                "phrase":  "test tube",
                                                "phrase_zh":  "试管"
                                            },
                                            {
                                                "phrase":  "tube station",
                                                "phrase_zh":  "地铁站"
                                            }
                                        ],
                            "examples":  [

                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n."
                        },
                        {
                            "word":  "van",
                            "zh":  "货车；厢式车",
                            "phrases":  [
                                            {
                                                "phrase":  "van dwelling regulation",
                                                "phrase_zh":  "van dwelling regulation 的语境用法"
                                            },
                                            {
                                                "phrase":  "车居生活监管",
                                                "phrase_zh":  "车居生活监管 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word van appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n./v."
                        },
                        {
                            "word":  "web",
                            "zh":  "网；网络",
                            "phrases":  [
                                            {
                                                "phrase":  "web of social relations",
                                                "phrase_zh":  "web of social relations 的语境用法"
                                            },
                                            {
                                                "phrase":  "社会关系网",
                                                "phrase_zh":  "社会关系网 的语境用法"
                                            }
                                        ],
                            "examples":  [
                                             "The word web appears in reading contexts where a learner needs both meaning and usage."
                                         ],
                            "category":  "small_only_no_family_kin",
                            "note":  "Small card only; no big family/kin card required.",
                            "pos":  "n./v."
                        }
                    ]
};