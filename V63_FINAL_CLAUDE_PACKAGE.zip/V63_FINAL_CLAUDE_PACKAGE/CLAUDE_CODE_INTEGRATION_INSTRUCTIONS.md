# Claude Code Integration Instructions

Use these files as independent browser globals. Load them before the vocabulary UI code.

## Files

1. VOCAB_READING_WORD_CARDS_SIMPLE.js
   - Reading directly clickable internal word cards.
   - Use for the first popup/small card.
   - Content: word, pos, zh, phrases, examples.
   - Also use VOCAB_READING_TO_LEARNING_HEAD.js to show/open the learning head.

2. VOCAB_READING_TO_LEARNING_HEAD.js
   - Maps every reading-clickable word to its learning head.
   - Head means the core word after prefix/suffix reduction, for example unimaginable -> imagine, subduction -> subduct, defies -> defy.

3. VOCAB_LEARNING_HEAD_CARDS_SIMPLE.js
   - External/internal learning head cards.
   - Content: head word, pos, zh, phrases, examples, family, kin, group.
   - Every learning head has at least one example.
   - When a user clicks the highlighted head in a small card, open this card.

4. VOCAB_FAMILY_CLEAN_SIMPLE.js
   - Family clusters for internal and external words.
   - Family means suffix/POS/form family: same core word, suffix changes.
   - Family words have their own phrase translations.
   - Words from file 1 and file 3 may share these family clusters.

5. VOCAB_KIN_CLEAN_SIMPLE.js
   - Kin clusters for internal and external words.
   - Kin means visible DNA/prefix/root relation, not synonym.
   - Use this to show learning-increment relatives.
   - Words from file 1 and file 3 may share these kin clusters.

6. VOCAB_PROPER_SMALL_CARDS_FINAL.js
   - Small-only cards for proper nouns/place names/no-family no-kin items.
   - These should answer reading meaning directly but should not open a big family/kin card.

7. VOCAB_GROUP_CLEAN_SIMPLE.js
   - Group is the semantic recycle bin: synonyms/near-synonyms with no visible DNA relation.
   - Do not mix group with family or kin.
   - Show group after family and kin.

8. VOCAB_KIN_HEAD_BRIDGE.js
   - Bridge from learning heads to kin clusters.
   - Use when a head card needs to find its kin clusters.

9. VOCAB_RUNTIME_HELPERS.js
   - Existing helper file. Keep it loaded if the current website already depends on it.

## UI Flow

1. User clicks a word in reading.
2. Open small card from VOCAB_READING_WORD_CARDS_SIMPLE, or from VOCAB_PROPER_SMALL_CARDS_FINAL if it is proper/small-only.
3. Small card shows word, pos, zh, phrases, examples, and the learning head from VOCAB_READING_TO_LEARNING_HEAD.
4. If user clicks the learning head, open the big card from VOCAB_LEARNING_HEAD_CARDS_SIMPLE.
5. Big card shows:
   - the head word's own phrases/examples,
   - family from VOCAB_FAMILY_CLEAN_SIMPLE,
   - kin from VOCAB_KIN_CLEAN_SIMPLE / VOCAB_KIN_HEAD_BRIDGE,
   - group from VOCAB_GROUP_CLEAN_SIMPLE.
6. Any family/kin/group word that exists in reading cards or head cards should be clickable and open its own card.

## Relationship Rules

- Family = suffix/POS/form change of the same core word.
- Kin = visible DNA/prefix/root relation; prefix change is the main learning value, suffix variation is allowed when useful.
- Group = semantic synonym/near-synonym only, with no family/kin DNA.
- Proper names/place names/no-family no-kin items stay small-only.
- Do not display old machine anchors to users.
- Do not treat family as kin or kin as group.

## Final Audit

FINAL_TRANSLATION_AND_PACKAGE_AUDIT_V63_FINAL_CLAUDE_PACKAGE.json reports counts and missing visible translations.