# KIN COVERAGE AUDIT AFTER V14B POLICY FINAL

- total_cards: **5862**
- small_only_cards: **26**
- reworked_67_added: **67**
- family_merged_count: **208**
- standalone_uncovered_after_policy: **0**

## policy
208 family words are merged into family/head and are not standalone kin gaps. 26 words are small-only. 67 rework words received curated kin clusters.

## final surface fixes
- ancestrally -> ancestral
- apes -> ape
- ornamental -> ornament