# POS COVERAGE AUDIT V15

- pos_registry_words: **14147**
- website_cards: **5862**
- kin_clusters: **3381**
- family_groups: **4852**
- small_cards: **32**
- missing_pos_count: **0**

## sample
```json
{
  "abandon": "v.",
  "incremental": "adj.",
  "academic": "adj.",
  "kin_external_sample": {
    "word": "maladapted",
    "zh": "适应不良的",
    "phrase_1": "maladapted policy",
    "phrase_1_zh": "适应不良的政策",
    "phrase_2": "maladapted species",
    "phrase_2_zh": "适应不良的物种",
    "pos": "adj."
  },
  "family_member_sample": {
    "word": "abandoned",
    "zh": "adj. 被遗弃的；废弃的",
    "phrases": [
      {
        "phrase": "abandoned building",
        "phrase_zh": "废弃建筑"
      },
      {
        "phrase": "abandoned settlements",
        "phrase_zh": "被废弃的聚落"
      },
      {
        "phrase": "abandoned industrial site",
        "phrase_zh": "废弃工业场地"
      },
      {
        "phrase": "abandoned children in wartime",
        "phrase_zh": "战时被遗弃儿童"
      }
    ],
    "examples": [],
    "sources": [
      "original_card_family_field",
      "moved_from_kin_external_family_like"
    ],
    "pos": "adj."
  }
}
```