# Normalized Lite Vocabulary Package

This package removes repeated phrase/example payloads.

Load order:
1. VOCAB_WORD_CONTENT_REGISTRY_LITE.js
2. VOCAB_READING_WORDS_LITE.js
3. VOCAB_EXTERNAL_WORDS_LITE.js
4. VOCAB_FAMILY_SHARED_CLUSTERS_LITE.js
5. VOCAB_KIN_CLEAN_LITE.js
6. VOCAB_GROUP_CLEAN_LITE.js
7. VOCAB_KIN_HEAD_BRIDGE_LITE.js

Rule:
- Content lives only in `VOCAB_WORD_CONTENT_REGISTRY_LITE.cards[word]`.
- Family/kin/group files only store word ids and relationship metadata.
- When displaying a family/kin/group item, look up its word content from the registry.
- This preserves the network while avoiding duplicated phrases/examples.

Flow:
- Reading click -> word id in `VOCAB_READING_WORDS_LITE.words` -> content registry small card.
- Big card -> use `reading_to_learning_head`, family cluster, kin bridge, group map.
- Any clicked related word -> open that word using the same registry lookup.